# PRD39 Mandatory Fault Matrix

| Fault | Expected | Forbidden |
|---|---|---|
| No eligible Procurement Coworker | UNROUTABLE/BLOCKED + reason | guessed/default assignee |
| Duplicate DELEGATE_WORK retry | one Child WorkItem | duplicate child |
| Child worker crash/lease expiry | reclaim + stale completion reject | business replay just because lease expired |
| Child auth revoked | BLOCK/ESCALATE | protected execution |
| Invalid Child WorkResult | parent continuation blocked | aggregate success |
| Duplicate WORK_RESULT_SUBMITTED | exactly one parent resume | duplicate continuation |
| Event before wait | inbox buffers; later match | lost wake-up |
| Parent authority revoked while waiting | historical child result kept; resume denied/replan | old EAC reuse |
| Skill/capability suspended | current preflight blocks | stale certified status bypass |
| WA projection down/lag | core flow continues; rebuild projection | business flow blocked |
| CX unavailable when not needed | core flow continues | unnecessary hard failure |
