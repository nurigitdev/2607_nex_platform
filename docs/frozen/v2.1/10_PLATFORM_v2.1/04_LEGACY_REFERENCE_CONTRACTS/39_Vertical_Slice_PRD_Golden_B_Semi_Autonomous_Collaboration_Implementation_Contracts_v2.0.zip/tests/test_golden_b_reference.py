def test_duplicate_result_event_resumes_parent_once(runtime):
    event = runtime.fixture_result_event()
    runtime.deliver(event)
    runtime.deliver(event)
    assert runtime.resume_job_count(event.parent_execution_id) == 1

def test_event_before_wait_is_not_lost(runtime):
    event = runtime.fixture_result_event()
    runtime.deliver(event)
    runtime.create_expected_wait(event.parent_execution_id, event.child_work_item_id)
    runtime.run_recovery_matcher()
    assert runtime.resume_job_count(event.parent_execution_id) == 1

def test_parent_role_revoked_blocks_resume(runtime):
    ctx = runtime.fixture_waiting_parent()
    runtime.revoke_parent_role(ctx.parent_execution_id)
    runtime.submit_child_result(ctx.child_work_item_id)
    runtime.run_resume()
    assert runtime.protected_downstream_calls(ctx.parent_execution_id) == 0
