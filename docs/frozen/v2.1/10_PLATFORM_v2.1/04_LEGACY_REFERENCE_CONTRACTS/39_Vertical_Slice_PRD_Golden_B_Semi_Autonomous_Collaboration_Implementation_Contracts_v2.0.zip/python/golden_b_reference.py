from dataclasses import dataclass

@dataclass(frozen=True)
class ResultEvent:
    event_id: str
    child_work_item_id: str
    result_ref: str
    result_version: int
    parent_execution_id: str

def handle_result_event(event, inbox, waits, jobs, result_validator):
    if not inbox.insert_once(event.event_id, event):
        return "DUPLICATE_IGNORED"
    wait = waits.find_active(parent_execution_id=event.parent_execution_id, child_work_item_id=event.child_work_item_id)
    if wait is None:
        return "BUFFERED_FOR_LATER_MATCH"
    result = result_validator.load_and_validate(event.result_ref, event.result_version, wait.required_result_contract)
    waits.satisfy_once(wait.id, event.event_id)
    jobs.enqueue_resume_once(wait.execution_id, wait.checkpoint_id, dedup_key=f"resume:{wait.id}")
    return "RESUME_ENQUEUED"

def resume_parent(ctx, oa, plan_repo, result_loader):
    authority = oa.rebuild_current_authority(ctx.parent_execution_id)
    if not authority.allowed:
        return {"decision":"BLOCK", "reason":"CURRENT_AUTHORITY_DENIED"}
    plan = plan_repo.load_exact(ctx.plan_ref, ctx.plan_version)
    result = result_loader.load_validated(ctx.result_ref, ctx.result_version)
    return {"decision":"CONTINUE", "plan":plan, "child_result":result}
