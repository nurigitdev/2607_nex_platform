-- WorkResult submission + dependency satisfaction + AE resume event contract

-- A. Submit one WorkResult revision and publish canonical event atomically.
BEGIN;

SELECT *
  FROM nex_wc.work_item
 WHERE work_item_id=:work_item_id
 FOR UPDATE;

-- Application:
-- 1) authorize submitted_by
-- 2) validate current state and expected version
-- 3) validate result contract/schema
-- 4) check idempotency record before write

INSERT INTO nex_wc.work_result(
    result_id, work_item_id, revision_no, result_type, summary,
    schema_ref, payload_json, technical_outcome, business_outcome,
    artifact_refs, evidence_refs, business_object_refs,
    source_execution_ref, source_plan_ref,
    submitted_by_type, submitted_by_ref,
    correlation_id, causation_id, idempotency_key
) VALUES (
    :result_id, :work_item_id, :revision_no, :result_type, :summary,
    :schema_ref, :payload_json::jsonb, :technical_outcome, :business_outcome,
    :artifact_refs::jsonb, :evidence_refs::jsonb, :business_object_refs::jsonb,
    :source_execution_ref, :source_plan_ref,
    :submitted_by_type, :submitted_by_ref,
    :correlation_id, :causation_id, :idempotency_key
);

UPDATE nex_wc.work_item
   SET state='RESULT_SUBMITTED',
       version=version+1,
       updated_at=now()
 WHERE work_item_id=:work_item_id
   AND version=:expected_version;

UPDATE nex_wc.work_dependency
   SET state='SATISFIED',
       satisfied_result_id=:result_id,
       satisfied_at=now()
 WHERE depends_on_work_item_id=:work_item_id
   AND state='WAITING'
   AND (
       result_schema_ref IS NULL
       OR result_schema_ref=:validated_schema_ref
   );

INSERT INTO nex_wc.work_timeline_event(
    timeline_event_id, work_item_id, event_name, actor_type, actor_ref,
    detail_json, correlation_id, causation_id
) VALUES (
    :timeline_event_id, :work_item_id, 'WORK_RESULT_SUBMITTED',
    :submitted_by_type, :submitted_by_ref,
    jsonb_build_object('result_id', :result_id, 'revision_no', :revision_no),
    :correlation_id, :causation_id
);

INSERT INTO nex_wc.event_outbox(
    outbox_id, event_id, event_name, aggregate_ref,
    payload_json, correlation_id, causation_id
) VALUES (
    :outbox_id, :event_id, 'WORK_RESULT_SUBMITTED',
    'WORKITEM:' || :work_item_id,
    jsonb_build_object(
        'work_item_id', :work_item_id,
        'result_id', :result_id,
        'revision_no', :revision_no,
        'technical_outcome', :technical_outcome,
        'business_outcome', :business_outcome,
        'source_execution_ref', :source_execution_ref
    ),
    :correlation_id, :causation_id
);

COMMIT;

-- B. AE consumes WORK_RESULT_SUBMITTED using its own event inbox/event_id dedup.
-- It matches checkpoint wait_condition.external_ref == work_item_id,
-- validates result_schema_ref, and enqueues exactly one RESUME_EXECUTION job.
-- WC does not directly update AE agent_execution state.

-- C. Closure transaction (after Completion/Closure policy passes).
BEGIN;

SELECT *
  FROM nex_wc.work_item
 WHERE work_item_id=:work_item_id
 FOR UPDATE;

-- Application evaluates:
-- completion_policy satisfied?
-- required reviews/acks satisfied?
-- closure authority allowed?
-- current state == RESULT_SUBMITTED?

UPDATE nex_wc.work_item
   SET state='CLOSED',
       version=version+1,
       closed_at=now(),
       updated_at=now()
 WHERE work_item_id=:work_item_id
   AND state='RESULT_SUBMITTED'
   AND version=:expected_version;

INSERT INTO nex_wc.work_timeline_event(...)
VALUES (... 'WORKITEM_CLOSED' ...);

INSERT INTO nex_wc.event_outbox(...)
VALUES (... 'WORKITEM_CLOSED' ...);

COMMIT;
