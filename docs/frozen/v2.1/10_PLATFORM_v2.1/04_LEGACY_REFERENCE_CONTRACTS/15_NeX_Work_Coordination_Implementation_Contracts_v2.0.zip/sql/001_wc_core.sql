-- NeX-WC v2.0 reference physical design

CREATE SCHEMA IF NOT EXISTS nex_wc;

CREATE TABLE IF NOT EXISTS nex_wc.capability_ownership (
    ownership_id             uuid PRIMARY KEY,
    capability_id            varchar(160) NOT NULL,
    organization_scope_ref   varchar(160),
    owner_org_ref            varchar(160) NOT NULL,
    owner_pool_ref           varchar(160),
    priority                 integer NOT NULL DEFAULT 100,
    active                   boolean NOT NULL DEFAULT true,
    effective_from           timestamptz,
    effective_to             timestamptz,
    policy_version           varchar(64) NOT NULL,
    created_at               timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_wc_capability_owner
    ON nex_wc.capability_ownership(capability_id, organization_scope_ref, active, priority);

CREATE TABLE IF NOT EXISTS nex_wc.work_item (
    work_item_id             uuid PRIMARY KEY,
    display_no               varchar(80),
    title                    varchar(300) NOT NULL,
    goal                     text NOT NULL,
    description              text,
    work_class               varchar(48) NOT NULL,
    priority                 varchar(16) NOT NULL DEFAULT 'NORMAL',
    state                    varchar(32) NOT NULL,
    source_type              varchar(40) NOT NULL,
    source_ref               varchar(256),
    parent_work_item_id      uuid,
    parent_execution_id      uuid,
    parent_plan_step_id      varchar(64),
    requester_type           varchar(40) NOT NULL,
    requester_ref            varchar(160) NOT NULL,
    accountable_owner_type   varchar(40) NOT NULL,
    accountable_owner_ref    varchar(160) NOT NULL,
    routing_target_type      varchar(40) NOT NULL,
    routing_target_ref       varchar(160),
    required_capability      varchar(160),
    organization_scope_ref   varchar(160),
    project_ref              varchar(160),
    completion_policy        varchar(48) NOT NULL,
    closure_authority_type   varchar(48) NOT NULL,
    closure_authority_ref    varchar(160),
    required_review          boolean NOT NULL DEFAULT false,
    allow_agent_auto_close   boolean NOT NULL DEFAULT false,
    due_at                   timestamptz,
    correlation_id           varchar(128) NOT NULL,
    causation_id             varchar(128),
    version                  bigint NOT NULL DEFAULT 0,
    created_at               timestamptz NOT NULL DEFAULT now(),
    updated_at               timestamptz NOT NULL DEFAULT now(),
    closed_at                timestamptz,
    cancelled_at             timestamptz,
    CONSTRAINT ck_wc_work_state CHECK (
        state IN ('CREATED','ROUTED','ASSIGNED','ACKNOWLEDGED','IN_PROGRESS',
                  'BLOCKED','WAITING_INPUT','RESULT_SUBMITTED',
                  'REVISION_REQUESTED','CLOSED','CANCELLED')
    )
);
CREATE INDEX IF NOT EXISTS ix_wc_work_inbox
    ON nex_wc.work_item(state, priority, due_at, created_at);
CREATE INDEX IF NOT EXISTS ix_wc_work_capability
    ON nex_wc.work_item(required_capability, state);
CREATE INDEX IF NOT EXISTS ix_wc_work_project
    ON nex_wc.work_item(project_ref, state);
CREATE INDEX IF NOT EXISTS ix_wc_work_parent
    ON nex_wc.work_item(parent_work_item_id);
CREATE INDEX IF NOT EXISTS ix_wc_work_corr
    ON nex_wc.work_item(correlation_id);

CREATE TABLE IF NOT EXISTS nex_wc.work_assignment (
    assignment_id            uuid PRIMARY KEY,
    work_item_id             uuid NOT NULL REFERENCES nex_wc.work_item(work_item_id),
    assignment_mode          varchar(40) NOT NULL,
    participant_role         varchar(40) NOT NULL,
    assignee_type            varchar(40) NOT NULL,
    assignee_ref             varchar(160) NOT NULL,
    expected_role            varchar(160),
    required                 boolean NOT NULL DEFAULT true,
    status                   varchar(32) NOT NULL DEFAULT 'ASSIGNED',
    acknowledged_at          timestamptz,
    started_at               timestamptz,
    completed_at             timestamptz,
    created_at               timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_wc_assignment_assignee
    ON nex_wc.work_assignment(assignee_type, assignee_ref, status, work_item_id);
CREATE INDEX IF NOT EXISTS ix_wc_assignment_work
    ON nex_wc.work_assignment(work_item_id, participant_role, required);

CREATE TABLE IF NOT EXISTS nex_wc.work_claim (
    claim_id                 uuid PRIMARY KEY,
    work_item_id             uuid NOT NULL REFERENCES nex_wc.work_item(work_item_id),
    claimant_type            varchar(40) NOT NULL,
    claimant_ref             varchar(160) NOT NULL,
    worker_ref               varchar(160),
    state                    varchar(24) NOT NULL DEFAULT 'ACTIVE',
    lease_token              uuid NOT NULL,
    lease_until              timestamptz NOT NULL,
    heartbeat_at             timestamptz NOT NULL DEFAULT now(),
    claimed_at               timestamptz NOT NULL DEFAULT now(),
    released_at              timestamptz,
    release_reason           varchar(160)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_wc_active_claim
    ON nex_wc.work_claim(work_item_id)
    WHERE state='ACTIVE';
CREATE INDEX IF NOT EXISTS ix_wc_claim_lease
    ON nex_wc.work_claim(state, lease_until);

CREATE TABLE IF NOT EXISTS nex_wc.routing_decision (
    routing_decision_id      uuid PRIMARY KEY,
    work_item_id             uuid NOT NULL REFERENCES nex_wc.work_item(work_item_id),
    required_capability      varchar(160),
    target_type              varchar(40),
    target_ref               varchar(160),
    decision                 varchar(32) NOT NULL,
    decision_json            jsonb NOT NULL,
    policy_version           varchar(64) NOT NULL,
    decided_at               timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_wc.work_relation (
    relation_id              uuid PRIMARY KEY,
    source_work_item_id      uuid NOT NULL REFERENCES nex_wc.work_item(work_item_id),
    target_work_item_id      uuid NOT NULL REFERENCES nex_wc.work_item(work_item_id),
    relation_type            varchar(40) NOT NULL,
    created_at               timestamptz NOT NULL DEFAULT now(),
    UNIQUE(source_work_item_id, target_work_item_id, relation_type),
    CONSTRAINT ck_wc_relation_type CHECK (
        relation_type IN ('PARENT_CHILD','FOLLOW_UP_OF','RELATED_TO')
    )
);

CREATE TABLE IF NOT EXISTS nex_wc.work_dependency (
    dependency_id            uuid PRIMARY KEY,
    work_item_id             uuid NOT NULL REFERENCES nex_wc.work_item(work_item_id),
    depends_on_work_item_id  uuid NOT NULL REFERENCES nex_wc.work_item(work_item_id),
    required                 boolean NOT NULL DEFAULT true,
    result_schema_ref        varchar(512),
    state                    varchar(24) NOT NULL DEFAULT 'WAITING',
    satisfied_result_id      uuid,
    created_at               timestamptz NOT NULL DEFAULT now(),
    satisfied_at             timestamptz,
    UNIQUE(work_item_id, depends_on_work_item_id)
);
CREATE INDEX IF NOT EXISTS ix_wc_dependency_wait
    ON nex_wc.work_dependency(state, depends_on_work_item_id);

CREATE TABLE IF NOT EXISTS nex_wc.work_result (
    result_id                uuid PRIMARY KEY,
    work_item_id             uuid NOT NULL REFERENCES nex_wc.work_item(work_item_id),
    revision_no              integer NOT NULL,
    result_type              varchar(120) NOT NULL,
    summary                  text,
    schema_ref               varchar(512),
    payload_json             jsonb,
    technical_outcome        varchar(32) NOT NULL,
    business_outcome         varchar(40) NOT NULL,
    artifact_refs            jsonb,
    evidence_refs            jsonb,
    business_object_refs     jsonb,
    source_execution_ref     varchar(128),
    source_plan_ref          varchar(128),
    submitted_by_type        varchar(40) NOT NULL,
    submitted_by_ref         varchar(160) NOT NULL,
    correlation_id           varchar(128) NOT NULL,
    causation_id             varchar(128),
    idempotency_key          varchar(256) NOT NULL,
    submitted_at             timestamptz NOT NULL DEFAULT now(),
    UNIQUE(work_item_id, revision_no),
    UNIQUE(idempotency_key)
);

CREATE TABLE IF NOT EXISTS nex_wc.work_revision_request (
    revision_request_id      uuid PRIMARY KEY,
    work_item_id             uuid NOT NULL REFERENCES nex_wc.work_item(work_item_id),
    target_result_id         uuid NOT NULL REFERENCES nex_wc.work_result(result_id),
    requested_by_type        varchar(40) NOT NULL,
    requested_by_ref         varchar(160) NOT NULL,
    reason                   text NOT NULL,
    requested_changes_json   jsonb,
    status                   varchar(24) NOT NULL DEFAULT 'OPEN',
    created_at               timestamptz NOT NULL DEFAULT now(),
    resolved_at              timestamptz
);

CREATE TABLE IF NOT EXISTS nex_wc.work_report_recipient (
    recipient_id             uuid PRIMARY KEY,
    work_item_id             uuid NOT NULL REFERENCES nex_wc.work_item(work_item_id),
    recipient_type           varchar(40) NOT NULL,
    recipient_ref            varchar(160) NOT NULL,
    recipient_mode           varchar(32) NOT NULL,
    status                   varchar(24) NOT NULL DEFAULT 'PENDING',
    acknowledged_at          timestamptz,
    reviewed_at              timestamptz,
    review_json              jsonb,
    created_at               timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_wc_recipient_mode CHECK (
        recipient_mode IN ('FYI','ACK_REQUIRED','REVIEW_REQUIRED')
    )
);

CREATE TABLE IF NOT EXISTS nex_wc.work_timeline_event (
    timeline_event_id        uuid PRIMARY KEY,
    work_item_id             uuid NOT NULL REFERENCES nex_wc.work_item(work_item_id),
    event_name               varchar(128) NOT NULL,
    actor_type               varchar(40),
    actor_ref                varchar(160),
    detail_json              jsonb,
    correlation_id           varchar(128),
    causation_id             varchar(128),
    occurred_at              timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_wc_timeline
    ON nex_wc.work_timeline_event(work_item_id, occurred_at);

CREATE TABLE IF NOT EXISTS nex_wc.command_idempotency (
    idempotency_key          varchar(256) PRIMARY KEY,
    capability               varchar(160) NOT NULL,
    semantic_payload_hash    char(64) NOT NULL,
    result_json              jsonb,
    commit_state             varchar(40) NOT NULL,
    created_at               timestamptz NOT NULL DEFAULT now(),
    updated_at               timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_wc.event_inbox (
    event_id                 varchar(128) PRIMARY KEY,
    event_name               varchar(128) NOT NULL,
    payload_json             jsonb NOT NULL,
    correlation_id           varchar(128),
    received_at              timestamptz NOT NULL DEFAULT now(),
    handled_at               timestamptz
);

CREATE TABLE IF NOT EXISTS nex_wc.event_outbox (
    outbox_id                uuid PRIMARY KEY,
    event_id                 varchar(128) NOT NULL UNIQUE,
    event_name               varchar(128) NOT NULL,
    aggregate_ref            varchar(256) NOT NULL,
    payload_json             jsonb NOT NULL,
    correlation_id           varchar(128),
    causation_id             varchar(128),
    state                    varchar(24) NOT NULL DEFAULT 'PENDING',
    attempts                 integer NOT NULL DEFAULT 0,
    available_at             timestamptz NOT NULL DEFAULT now(),
    published_at             timestamptz,
    created_at               timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_wc_outbox_publish
    ON nex_wc.event_outbox(state, available_at, created_at);
