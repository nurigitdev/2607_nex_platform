from __future__ import annotations
from typing import Any, Mapping

Json = Mapping[str, Any]

class CompletionPolicyService:
    async def evaluate(self, work_item: Json, repository) -> dict:
        policy = work_item["completion_policy"]

        if policy == "OWNER_SUBMITS":
            return {"complete": await repository.owner_has_result(work_item["work_item_id"])}

        if policy == "ALL_ASSIGNEES_SUBMIT":
            return {"complete": await repository.all_required_assignees_have_results(
                work_item["work_item_id"]
            )}

        if policy == "ANY_ASSIGNEE_SUBMITS":
            return {"complete": await repository.any_required_assignee_has_result(
                work_item["work_item_id"]
            )}

        if policy == "ALL_REQUIRED_CHILDREN":
            children = await repository.required_children(work_item["work_item_id"])
            complete = bool(children) and all(
                c["state"] in {"RESULT_SUBMITTED", "CLOSED"}
                and c.get("result_contract_valid", False)
                for c in children
            )
            return {"complete": complete, "children": children}

        if policy == "MANUAL":
            return {"complete": False, "manual": True}

        raise ValueError(f"UNKNOWN_COMPLETION_POLICY:{policy}")

class ClosurePolicyService:
    async def can_close(self, work_item: Json, actor: Json, repository, pdp) -> dict:
        completion = await CompletionPolicyService().evaluate(work_item, repository)
        if not completion.get("complete"):
            return {"allowed": False, "reason": "COMPLETION_POLICY_NOT_SATISFIED"}

        allowed = await pdp.can_close(work_item=work_item, actor=actor)
        if not allowed:
            return {"allowed": False, "reason": "CLOSURE_AUTHORITY_DENIED"}

        if work_item["closure_policy"].get("required_review"):
            if not await repository.required_review_satisfied(work_item["work_item_id"]):
                return {"allowed": False, "reason": "REVIEW_REQUIRED"}

        return {"allowed": True}
