from __future__ import annotations

ALLOWED_TRANSITIONS: dict[str, set[str]] = {
    "CREATED": {"ROUTED", "ASSIGNED", "CANCELLED"},
    "ROUTED": {"ASSIGNED", "CANCELLED"},
    "ASSIGNED": {"ACKNOWLEDGED", "IN_PROGRESS", "CANCELLED"},
    "ACKNOWLEDGED": {"IN_PROGRESS", "CANCELLED"},
    "IN_PROGRESS": {"BLOCKED", "WAITING_INPUT", "RESULT_SUBMITTED", "CANCELLED"},
    "BLOCKED": {"IN_PROGRESS", "CANCELLED"},
    "WAITING_INPUT": {"IN_PROGRESS", "CANCELLED"},
    "RESULT_SUBMITTED": {"REVISION_REQUESTED", "CLOSED"},
    "REVISION_REQUESTED": {"IN_PROGRESS", "CANCELLED"},
    "CLOSED": set(),
    "CANCELLED": set(),
}

def assert_transition(current: str, target: str) -> None:
    if target not in ALLOWED_TRANSITIONS.get(current, set()):
        raise ValueError(f"INVALID_WORKITEM_TRANSITION:{current}->{target}")

def is_terminal(state: str) -> bool:
    return state in {"CLOSED", "CANCELLED"}
