from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping, Protocol, Sequence

Json = Mapping[str, Any]

@dataclass(frozen=True)
class RoutingContext:
    work_item_id: str
    required_capability: str
    organization_scope_ref: str | None
    project_scope_ref: str | None
    risk_level: str
    explicit_target_type: str | None = None
    explicit_target_ref: str | None = None

@dataclass(frozen=True)
class Candidate:
    candidate_type: str
    candidate_ref: str
    eligible: bool
    reason_codes: tuple[str, ...]
    load_score: float | None = None
    availability: str | None = None

@dataclass(frozen=True)
class RoutingDecision:
    decision: str
    target_type: str | None
    target_ref: str | None
    candidates: tuple[Candidate, ...]
    reason_codes: tuple[str, ...]
    policy_version: str

class CapabilityOwnershipRegistry(Protocol):
    async def resolve_owners(
        self, capability_id: str, organization_scope_ref: str | None
    ) -> Sequence[Json]: ...

class EligibilityProvider(Protocol):
    async def list_candidates(
        self, *, capability_id: str, owner_scope: Json, context: RoutingContext
    ) -> Sequence[Json]: ...

class AuthorizationPDP(Protocol):
    async def can_assign(
        self, *, candidate: Json, context: RoutingContext
    ) -> tuple[bool, Sequence[str]]: ...

class WorkRepository(Protocol):
    async def get_work_item(self, work_item_id: str) -> Json: ...
    async def save_routing_decision(self, decision: Json) -> None: ...
    async def create_assignment(self, assignment: Json) -> None: ...
    async def update_state(
        self, work_item_id: str, expected_version: int, new_state: str, patch: Json
    ) -> int: ...

class ClaimRepository(Protocol):
    async def claim(
        self, work_item_id: str, claimant_ref: str,
        worker_ref: str | None, lease_seconds: int
    ) -> Json | None: ...
    async def heartbeat(
        self, claim_id: str, lease_token: str, lease_seconds: int
    ) -> bool: ...
    async def release(self, claim_id: str, lease_token: str, reason: str) -> bool: ...

class ResultRepository(Protocol):
    async def submit_result(self, result: Json, idempotency_key: str) -> Json: ...
    async def request_revision(self, request: Json) -> Json: ...
    async def close(self, command: Json, idempotency_key: str) -> Json: ...

class CompletionPolicyEvaluator(Protocol):
    async def evaluate(self, work_item: Json) -> Json: ...

class ClosurePolicyEvaluator(Protocol):
    async def evaluate(self, work_item: Json, actor_context: Json) -> Json: ...

class EventOutbox(Protocol):
    async def append(self, event: Json) -> None: ...
