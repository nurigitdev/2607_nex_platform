from __future__ import annotations
from dataclasses import asdict
from typing import Any, Mapping

from .protocols import Candidate, RoutingContext, RoutingDecision

Json = Mapping[str, Any]

class RoutingResolver:
    """Deterministic routing. LLM is not a candidate eligibility authority."""

    def __init__(
        self, ownership_registry, eligibility_provider, authorization_pdp,
        load_policy, routing_policy
    ):
        self.ownership_registry = ownership_registry
        self.eligibility_provider = eligibility_provider
        self.authorization_pdp = authorization_pdp
        self.load_policy = load_policy
        self.routing_policy = routing_policy

    async def resolve(self, ctx: RoutingContext) -> RoutingDecision:
        # Explicit target is honored only after eligibility/security validation.
        if ctx.explicit_target_ref:
            ok, reasons = await self.authorization_pdp.can_assign(
                candidate={
                    "candidate_type": ctx.explicit_target_type,
                    "candidate_ref": ctx.explicit_target_ref,
                },
                context=ctx,
            )
            if not ok:
                return RoutingDecision(
                    decision="UNROUTABLE",
                    target_type=None,
                    target_ref=None,
                    candidates=(),
                    reason_codes=tuple(reasons),
                    policy_version=self.routing_policy.version,
                )
            return RoutingDecision(
                decision="ROUTED",
                target_type=ctx.explicit_target_type,
                target_ref=ctx.explicit_target_ref,
                candidates=(),
                reason_codes=("EXPLICIT_TARGET_ALLOWED",),
                policy_version=self.routing_policy.version,
            )

        owners = await self.ownership_registry.resolve_owners(
            ctx.required_capability, ctx.organization_scope_ref
        )
        if not owners:
            return RoutingDecision(
                decision="UNROUTABLE", target_type=None, target_ref=None,
                candidates=(), reason_codes=("NO_CAPABILITY_OWNER",),
                policy_version=self.routing_policy.version
            )

        eligible: list[Candidate] = []
        for owner in owners:
            raw_candidates = await self.eligibility_provider.list_candidates(
                capability_id=ctx.required_capability,
                owner_scope=owner,
                context=ctx,
            )
            for raw in raw_candidates:
                ok, reasons = await self.authorization_pdp.can_assign(
                    candidate=raw, context=ctx
                )
                if not ok:
                    eligible.append(Candidate(
                        raw["candidate_type"], raw["candidate_ref"], False,
                        tuple(reasons), raw.get("load_score"), raw.get("availability")
                    ))
                    continue

                load_ok, load_reasons = self.load_policy.accept(raw, ctx)
                eligible.append(Candidate(
                    raw["candidate_type"], raw["candidate_ref"], load_ok,
                    tuple(load_reasons), raw.get("load_score"), raw.get("availability")
                ))

        accepted = [c for c in eligible if c.eligible]
        if not accepted:
            return RoutingDecision(
                decision="UNROUTABLE",
                target_type="CAPABILITY_POOL",
                target_ref=ctx.required_capability,
                candidates=tuple(eligible),
                reason_codes=("NO_ELIGIBLE_CANDIDATE",),
                policy_version=self.routing_policy.version,
            )

        # Default v2 policy routes to a pool; individual claim determines actual assignee.
        return RoutingDecision(
            decision="ROUTED",
            target_type="CAPABILITY_POOL",
            target_ref=ctx.required_capability,
            candidates=tuple(eligible),
            reason_codes=("CAPABILITY_POOL_ROUTED",),
            policy_version=self.routing_policy.version,
        )
