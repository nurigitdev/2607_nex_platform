# NeX-WC v2.0 Detailed Design Reference Package

Accompanies `15_NeX_Work_Coordination_Detailed_Design_v2.0`.

Contents
- schemas/
  - work-item-v2.schema.json
  - routing-decision-v2.schema.json
  - work-result-v2.schema.json
- python/nex_wc/
  - protocols.py
  - routing.py
  - state_machine.py
  - policies.py
- sql/
  - 001_wc_core.sql
  - 002_claim_lease.sql
  - 003_result_dependency_resume.sql

Key implementation rules
1. WorkItem is Enterprise Work Source of Truth.
2. Routing Target, Actual Assignment, Active Claim and Accountable Owner are distinct.
3. Capability + organization scope is the default unnamed routing method.
4. Planner does not choose actual assignee.
5. Claim/lease coordinates workers only; business idempotency is separate.
6. Child Work result emits canonical event; AE resumes from its own event inbox/checkpoint.
7. WorkResult is versioned; Revision never overwrites prior result.
8. Runtime/A2A completion never automatically closes a WorkItem.
9. Cross-service writes use canonical API/event contracts, never direct DB writes.

All JSON Schemas were checked against JSON Schema Draft 2020-12.
Python reference modules are syntax-compiled during artifact generation.
