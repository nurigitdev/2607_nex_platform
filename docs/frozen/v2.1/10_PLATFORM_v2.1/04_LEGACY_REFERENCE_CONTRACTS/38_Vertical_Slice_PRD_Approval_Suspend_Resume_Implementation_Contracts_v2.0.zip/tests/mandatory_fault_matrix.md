# PRD38 Mandatory Fault Matrix

- approval reject => write count 0
- approval cancel => write count 0
- approval expire => write count 0
- approved proof invalidated => write count 0
- approver role expired before decision => deny
- requester role revoked during wait => approved but resume blocks
- duplicate APPROVAL_APPROVED => one resume / one write
- approval event arrives before wait row => eventual match, no lost wake-up
- worker crash after checkpoint => durable wait
- payload/operation mutation => old proof rejected / new gate required
- proof expired/revoked/mismatch => NSL provider write count 0
- unknown commit => RECONCILIATION_REQUIRED, blind retry 0
