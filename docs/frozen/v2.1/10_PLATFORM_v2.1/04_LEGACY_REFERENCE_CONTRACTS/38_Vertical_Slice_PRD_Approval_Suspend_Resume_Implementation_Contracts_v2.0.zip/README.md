# PRD38 Implementation Contracts

This package defines only the AE↔EOS Approval↔OA↔NSL integration slice. It does **not** duplicate the internal Approval Engine or NSL implementation defined by frozen baselines.

Repository/API/schema names are logical placeholders until INC-0 repository evidence is inspected.
