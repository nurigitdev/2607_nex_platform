from enum import Enum

class ApprovalEvent(str, Enum):
    APPROVED="APPROVAL_APPROVED"
    REJECTED="APPROVAL_REJECTED"
    CANCELLED="APPROVAL_CANCELLED"
    EXPIRED="APPROVAL_EXPIRED"
    INVALIDATED="APPROVAL_INVALIDATED"

def map_event(event: ApprovalEvent) -> str:
    if event is ApprovalEvent.APPROVED:
        return "RESUME_PRECHECK"
    if event is ApprovalEvent.REJECTED:
        return "BLOCKED_REJECTED"
    if event is ApprovalEvent.CANCELLED:
        return "CANCELLED_OR_ESCALATED"
    if event is ApprovalEvent.EXPIRED:
        return "REREQUEST_OR_ESCALATE"
    return "REPLAN_OR_ESCALATE"
