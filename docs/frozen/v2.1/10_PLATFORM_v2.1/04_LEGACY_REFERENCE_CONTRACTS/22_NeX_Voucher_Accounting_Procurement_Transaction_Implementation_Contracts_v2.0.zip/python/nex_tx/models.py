from __future__ import annotations
from decimal import Decimal
from enum import StrEnum
from typing import Any
from pydantic import BaseModel, ConfigDict

class EntrySide(StrEnum):
    DEBIT="DEBIT"; CREDIT="CREDIT"

class TransactionType(StrEnum):
    EXPENSE="EXPENSE"; REVENUE="REVENUE"; PURCHASE_INVOICE="PURCHASE_INVOICE"
    PAYMENT="PAYMENT"; REVERSAL="REVERSAL"; ADJUSTMENT="ADJUSTMENT"

class EconomicCategory(StrEnum):
    REVENUE="REVENUE"; LABOR="LABOR"; MATERIAL="MATERIAL"
    DIRECT_EXPENSE="DIRECT_EXPENSE"; COMMON_COST="COMMON_COST"
    ADJUSTMENT="ADJUSTMENT"; NONE="NONE"

class Money(BaseModel):
    model_config=ConfigDict(extra="forbid",frozen=True)
    amount: Decimal
    currency: str

class EntityRef(BaseModel):
    model_config=ConfigDict(extra="forbid",frozen=True)
    entity_type: str
    entity_id: str
    version: str|int|None=None
    status: str|None=None
