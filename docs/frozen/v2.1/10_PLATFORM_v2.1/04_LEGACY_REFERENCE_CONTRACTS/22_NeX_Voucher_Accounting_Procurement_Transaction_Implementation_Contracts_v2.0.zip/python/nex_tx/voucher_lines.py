from __future__ import annotations
from decimal import Decimal
from typing import Any, Mapping, Sequence

class VoucherLineGenerator:
    """Deterministic balanced Voucher line templates."""

    def generate(self, source:Mapping[str,Any], mapping:Mapping[str,Any]) -> list[dict[str,Any]]:
        tx=source["transaction_type"]
        currency=source["currency"]
        base=Decimal(str(source["base_amount"]))
        tax=Decimal(str(source.get("tax_amount","0")))
        total=base+tax
        m=mapping["selected_mapping"]
        lines=[]

        if tx in {"EXPENSE","PURCHASE_INVOICE"}:
            lines.append(self._line(1,m["debit_account_ref"],"DEBIT",base,currency,m["economic_category"],"BASE"))
            if tax:
                tax_ref=m.get("tax_account_ref")
                if not tax_ref:
                    raise ValueError("TAX_ACCOUNT_REQUIRED")
                lines.append(self._line(2,tax_ref,"DEBIT",tax,currency,m.get("tax_economic_category","NONE"),"TAX"))
            lines.append(self._line(len(lines)+1,m["credit_account_ref"],"CREDIT",total,currency,m["offset_economic_category"],"OFFSET"))

        elif tx=="REVENUE":
            # Customer receivable/cash debit is offset; revenue credit is economic fact.
            lines.append(self._line(1,m["debit_account_ref"],"DEBIT",total,currency,m["offset_economic_category"],"OFFSET"))
            lines.append(self._line(2,m["credit_account_ref"],"CREDIT",base,currency,m["economic_category"],"BASE"))
            if tax:
                tax_ref=m.get("tax_account_ref")
                if not tax_ref:
                    raise ValueError("TAX_ACCOUNT_REQUIRED")
                lines.append(self._line(3,tax_ref,"CREDIT",tax,currency,m.get("tax_economic_category","NONE"),"TAX"))

        elif tx=="PAYMENT":
            # Settlement only; no project P/L effect.
            lines.append(self._line(1,m["debit_account_ref"],"DEBIT",total,currency,"NONE","OFFSET"))
            lines.append(self._line(2,m["credit_account_ref"],"CREDIT",total,currency,"NONE","OFFSET"))

        else:
            raise ValueError("UNSUPPORTED_TRANSACTION_TYPE_FOR_TEMPLATE")

        debit=sum(Decimal(x["amount"]["amount"]) for x in lines if x["side"]=="DEBIT")
        credit=sum(Decimal(x["amount"]["amount"]) for x in lines if x["side"]=="CREDIT")
        if debit!=credit:
            raise ValueError("GENERATED_VOUCHER_NOT_BALANCED")
        return lines

    def _line(self,no,account,side,amount,currency,category,component):
        if amount<=0:
            raise ValueError("LINE_AMOUNT_MUST_BE_POSITIVE")
        return {"line_no":no,"account_ref":account,"side":side,
                "amount":{"amount":str(amount),"currency":currency},
                "economic_category":category,"source_component":component}
