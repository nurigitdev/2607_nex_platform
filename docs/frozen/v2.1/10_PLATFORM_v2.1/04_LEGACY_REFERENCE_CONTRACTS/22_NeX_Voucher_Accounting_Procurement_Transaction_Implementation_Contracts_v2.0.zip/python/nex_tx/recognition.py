from __future__ import annotations
from typing import Any, Mapping

class CostRecognitionService:
    """Eligibility is not actual recognition. Actual cost exists only after ledger posting."""

    def __init__(self, procurement, voucher_gateway, ledger_gateway, mapping_service,
                 line_generator, approval_resolver, human_gate, outbox, id_generator, clock):
        self.procurement=procurement; self.voucher_gateway=voucher_gateway
        self.ledger_gateway=ledger_gateway; self.mapping_service=mapping_service
        self.line_generator=line_generator; self.approval_resolver=approval_resolver
        self.human_gate=human_gate; self.outbox=outbox; self.id_generator=id_generator; self.clock=clock

    async def create_purchase_voucher(self, invoice_id:str, *, context:Mapping[str,Any]) -> Mapping[str,Any]:
        invoice=await self.procurement.get_invoice(invoice_id)
        if invoice["state"] not in {"MATCHED","APPROVED"}:
            raise ValueError("INVOICE_NOT_ELIGIBLE")
        match=await self.procurement.get_match_result(invoice["match_result_ref"]["entity_id"])
        if match["status"] not in {"MATCHED","OVERRIDE_APPROVED"}:
            raise ValueError("INVOICE_MATCH_NOT_ACCEPTED")

        # v2 baseline: one-project invoice, aggregate economic base across mapped lines.
        source={"transaction_type":"PURCHASE_INVOICE","source_ref":{"entity_type":"SUPPLIER_INVOICE","entity_id":invoice_id},
                "project_ref":invoice["project_ref"],"currency":invoice["currency"],
                "base_amount":invoice["net_total"]["amount"],"tax_amount":invoice["tax_total"]["amount"],
                "source_category":invoice["lines"][0]["source_category"],
                "supplier_ref":invoice["supplier_ref"],"tax_code":invoice["lines"][0].get("tax_code"),
                "correlation_id":invoice["trace"]["correlation_id"]}
        mapping=await self.mapping_service.resolve(source)
        if mapping["mapping_status"]!="RESOLVED":
            return {"status":mapping["mapping_status"],"mapping":mapping}
        lines=self.line_generator.generate(source,mapping)
        voucher_payload={"voucher_type":"PURCHASE","project_ref":invoice["project_ref"],
                         "currency":invoice["currency"],"transaction_date":invoice["invoice_date"],
                         "requester_ref":{"entity_type":"SYSTEM","entity_id":"PROCUREMENT_ACCOUNTING"},
                         "lines":lines,"source_invoice_ref":source["source_ref"],
                         "correlation_id":invoice["trace"]["correlation_id"]}
        result=await self.voucher_gateway.create_purchase_voucher(
            voucher_payload, confirmation_proof_ref=None,
            idempotency_key=f"purchase-invoice:{invoice_id}:voucher"
        )
        return {"status":"VOUCHER_CREATED","voucher":result}

    async def recognize_actual_cost(self, invoice_id:str, voucher_id:str, *,
                                    approval_proof_ref:str|None, context:Mapping[str,Any]) -> Mapping[str,Any]:
        # Actual Project cost begins only when Project Financial Ledger posting commits.
        posting=await self.ledger_gateway.post_voucher(
            voucher_id,approval_proof_ref,
            idempotency_key=f"purchase-invoice:{invoice_id}:ledger-post",
            context=context
        )
        await self.outbox.append({"event_name":"PROJECT_ACTUAL_COST_RECOGNIZED",
                                  "invoice_id":invoice_id,"voucher_id":voucher_id,
                                  "posting_ref":posting["posting_ref"],
                                  "correlation_id":context["correlation_id"]})
        return {"actual_cost_status":"RECOGNIZED","posting":posting}
