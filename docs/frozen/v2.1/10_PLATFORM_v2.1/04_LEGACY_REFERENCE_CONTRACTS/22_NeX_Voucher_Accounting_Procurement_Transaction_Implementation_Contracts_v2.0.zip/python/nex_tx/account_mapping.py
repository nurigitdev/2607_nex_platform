from __future__ import annotations
from typing import Any, Mapping

class AccountMappingService:
    """Rule-first mapping. LLM suggestions never become stable account IDs."""

    def __init__(self, rules, accounts, projects, confirmations, id_generator, clock):
        self.rules=rules; self.accounts=accounts; self.projects=projects
        self.confirmations=confirmations; self.id_generator=id_generator; self.clock=clock

    async def resolve(self, context:Mapping[str,Any]) -> Mapping[str,Any]:
        project=await self.projects.get(context["project_ref"]["entity_id"])
        if project["status"]!="ACTIVE":
            raise ValueError("PROJECT_NOT_ACTIVE")
        candidates=list(await self.rules.find_rules(context))
        active=[]
        for rule in candidates:
            if not rule.get("active",True):
                continue
            active.append(rule)

        if not active:
            return {"mapping_status":"UNRESOLVED","reason":"NO_MAPPING_RULE"}

        # Deterministic ordering: specificity desc, business priority asc, rule id asc.
        active.sort(key=lambda r:(-int(r["specificity_score"]),int(r["priority"]),r["rule_id"]))
        best=active[0]
        tied=[r for r in active if (r["specificity_score"],r["priority"]) ==
              (best["specificity_score"],best["priority"])]
        if len(tied)>1 and len({r["mapping_signature"] for r in tied})>1:
            return {"mapping_status":"CONFLICT","candidate_rule_refs":[r["rule_id"] for r in tied]}

        mapping=best["mapping"]
        for aid in [mapping["debit_account_ref"]["entity_id"],mapping["credit_account_ref"]["entity_id"]]:
            account=await self.accounts.get(aid)
            if account["status"]!="ACTIVE":
                raise ValueError("MAPPED_ACCOUNT_NOT_ACTIVE")

        if best.get("requires_confirmation",False):
            confirmation=await self.confirmations.request_confirmation(
                {"mapping":mapping,"context":dict(context),"rule_ref":best["rule_id"]},
                idempotency_key=f"account-map:{context['source_ref']['entity_id']}:{best['rule_id']}"
            )
            return {"mapping_status":"CONFIRMATION_REQUIRED","rule_ref":best["rule_id"],
                    "confirmation_ref":confirmation["confirmation_ref"],"selected_mapping":mapping}
        return {"mapping_status":"RESOLVED","rule_ref":best["rule_id"],
                "rule_version":best["rule_version"],"selected_mapping":mapping}
