from __future__ import annotations
from decimal import Decimal
from typing import Any, Mapping, Sequence

class InvoiceMatchService:
    def __init__(self, policy_repo, procurement, receipts, id_generator, clock):
        self.policy_repo=policy_repo; self.procurement=procurement
        self.receipts=receipts; self.id_generator=id_generator; self.clock=clock

    async def match(self, invoice:Mapping[str,Any]) -> Mapping[str,Any]:
        policy=await self.policy_repo.resolve(invoice)
        mode=policy["match_mode"]
        checks=[]

        # Duplicate is a hard fail.
        duplicate=await self.procurement.find_invoice_by_fingerprint(invoice["invoice_fingerprint"])
        checks.append(self._check("DUPLICATE",duplicate is None,False,bool(duplicate),0))

        po=None; receipt_rows=[]
        if mode!="NON_PO":
            po=await self.procurement.get_po(invoice["po_ref"]["entity_id"])
            checks.append(self._check("SUPPLIER",po["supplier_ref"]["entity_id"]==invoice["supplier_ref"]["entity_id"],
                                      po["supplier_ref"]["entity_id"],invoice["supplier_ref"]["entity_id"],0))
            checks.append(self._check("PROJECT",po["project_ref"]["entity_id"]==invoice["project_ref"]["entity_id"],
                                      po["project_ref"]["entity_id"],invoice["project_ref"]["entity_id"],0))
            checks.append(self._check("CURRENCY",po["currency"]==invoice["currency"],po["currency"],invoice["currency"],0))
            if mode=="THREE_WAY":
                receipt_rows=list(await self.receipts.get_receipts_for_po(po["po_id"]))
                checks.append(self._check("RECEIPT",bool(receipt_rows),True,bool(receipt_rows),0))

        # Reference aggregate checks. Production version is line-level with tolerance policy.
        expected=Decimal(str(po["total_amount"]["amount"])) if po else Decimal(str(invoice["gross_total"]["amount"]))
        actual=Decimal(str(invoice["gross_total"]["amount"]))
        tol=Decimal(str(policy.get("amount_tolerance","0")))
        checks.append(self._check("NET_AMOUNT",abs(actual-expected)<=tol,str(expected),str(actual),str(tol)))

        failed=[c for c in checks if c["status"]=="FAIL"]
        status="MATCHED" if not failed else "EXCEPTION"
        result={"schema_version":"1.0","match_result_id":self.id_generator.new_id(),
                "invoice_ref":{"entity_type":"SUPPLIER_INVOICE","entity_id":invoice["invoice_id"]},
                "po_ref":invoice.get("po_ref"),"receipt_refs":invoice.get("receipt_refs",[]),
                "match_mode":mode,"status":status,"policy_ref":policy["policy_ref"],
                "checks":checks,"exception_codes":[c["check_code"] for c in failed],
                "override_approval_ref":None,"created_at":self.clock.now().isoformat()}
        return await self.procurement.save_match_result(result)

    def _check(self,code,ok,expected,actual,tolerance):
        return {"check_code":code,"status":"PASS" if ok else "FAIL",
                "expected":expected,"actual":actual,"tolerance":tolerance}
