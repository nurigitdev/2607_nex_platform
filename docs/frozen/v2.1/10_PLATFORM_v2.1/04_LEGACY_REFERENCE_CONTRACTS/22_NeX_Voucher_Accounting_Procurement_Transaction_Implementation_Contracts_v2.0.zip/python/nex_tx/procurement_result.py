from __future__ import annotations
from typing import Any, Mapping

class ProcurementResultService:
    def __init__(self, work_coordinator, commitment_gateway):
        self.work_coordinator=work_coordinator
        self.commitment_gateway=commitment_gateway

    async def submit_sourcing_result(self, *, work_item_id:str, requisition:Mapping[str,Any],
                                     po:Mapping[str,Any]|None, selected_quotes:list[Mapping[str,Any]],
                                     exception_codes:list[str]) -> Mapping[str,Any]:
        if po and po["state"]!="ISSUED":
            raise ValueError("PROCUREMENT_RESULT_REQUIRES_ISSUED_PO")
        commitment=None
        if po:
            commitment=await self.commitment_gateway.get_or_create_for_po(po["po_id"])
        result={
            "schema_version":"1.0","result_type":"PROCUREMENT_SOURCING_RESULT",
            "outcome":"SOURCING_COMPLETED" if po else "FAILED",
            "source_requisition_ref":{"entity_type":"PURCHASE_REQUISITION","entity_id":requisition["requisition_id"]},
            "project_ref":requisition["project_ref"],
            "supplier_ref":po["supplier_ref"] if po else None,
            "po_ref":{"entity_type":"PURCHASE_ORDER","entity_id":po["po_id"]} if po else None,
            "commitment_ref":commitment["commitment_ref"] if commitment else None,
            "ordered_amount":po["total_amount"] if po else None,
            "expected_delivery":min((x.get("expected_delivery_date") for x in po["lines"] if x.get("expected_delivery_date")),default=None) if po else None,
            "selected_quote_refs":selected_quotes,
            "exception_codes":exception_codes,
            "note":"PO commitment is not Project actual cost."
        }
        return await self.work_coordinator.report_result(
            work_item_id,result,idempotency_key=f"{work_item_id}:procurement-result"
        )
