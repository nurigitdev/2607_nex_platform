from __future__ import annotations
from decimal import Decimal
from typing import Any, Mapping

class ApprovalThresholdService:
    """Deterministic effective-dated threshold policy resolution."""

    def __init__(self, policy_repository):
        self.policy_repository=policy_repository

    async def resolve(self, ctx:Mapping[str,Any]) -> Mapping[str,Any]:
        rules=list(await self.policy_repository.find_effective(ctx))
        if not rules:
            # Fail closed for protected transaction types.
            if ctx.get("risk_level") in {"R4","R5"}:
                return {"gate_type":"FORMAL_APPROVAL","reason":"NO_POLICY_FAIL_CLOSED",
                        "approval_policy_ref":"POLICY:DEFAULT:HIGH_RISK"}
            return {"gate_type":"NONE","reason":"NO_APPROVAL_RULE"}

        rules.sort(key=lambda r:(-r["specificity_score"],r["priority"],r["rule_id"]))
        selected=rules[0]
        amount=Decimal(str(ctx["amount"]["amount"]))
        if selected.get("min_amount") is not None and amount < Decimal(str(selected["min_amount"])):
            return {"gate_type":"NONE","reason":"BELOW_THRESHOLD","rule_ref":selected["rule_id"]}
        if selected.get("max_amount") is not None and amount > Decimal(str(selected["max_amount"])):
            # Allow next stage/higher policy embedded in rule.
            pass
        return {"gate_type":selected["gate_type"],
                "approval_policy_ref":selected.get("approval_policy_ref"),
                "rule_ref":selected["rule_id"],
                "rule_version":selected["rule_version"]}
