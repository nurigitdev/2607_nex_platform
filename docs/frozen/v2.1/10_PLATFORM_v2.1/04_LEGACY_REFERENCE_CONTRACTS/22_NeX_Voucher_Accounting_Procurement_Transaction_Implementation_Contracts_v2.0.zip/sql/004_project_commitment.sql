-- Project Commitment read model: PO commitment != Actual P/L cost
CREATE TABLE IF NOT EXISTS nex_eos.project_commitment (
    commitment_id            uuid PRIMARY KEY,
    po_id                    uuid NOT NULL REFERENCES nex_eos.purchase_order(po_id),
    po_line_id               uuid NOT NULL REFERENCES nex_eos.purchase_order_line(line_id),
    project_id               uuid NOT NULL REFERENCES nex_eos.project(project_id),
    source_category          varchar(160) NOT NULL,
    economic_category        varchar(32),
    currency                 char(3) NOT NULL,
    committed_amount         numeric(38,12) NOT NULL,
    recognized_actual_amount numeric(38,12) NOT NULL DEFAULT 0,
    cancelled_amount         numeric(38,12) NOT NULL DEFAULT 0,
    open_commitment_amount   numeric(38,12) NOT NULL,
    status                   varchar(24) NOT NULL,
    source_ledger_watermark  varchar(128),
    updated_at               timestamptz NOT NULL DEFAULT now(),
    UNIQUE(po_line_id),
    CONSTRAINT ck_commitment_amounts CHECK (
      committed_amount >= 0 AND recognized_actual_amount >= 0
      AND cancelled_amount >= 0 AND open_commitment_amount >= 0
    ),
    CONSTRAINT ck_commitment_status CHECK (status IN ('OPEN','PARTIALLY_RECOGNIZED','FULLY_RECOGNIZED','CANCELLED','CLOSED'))
);

-- Commitment created/refreshed when PO becomes ISSUED.
-- Actual recognized amount is refreshed from Project Financial Ledger facts tied to source invoice/PO.
-- Project P/L itself never reads this commitment table as actual cost.
