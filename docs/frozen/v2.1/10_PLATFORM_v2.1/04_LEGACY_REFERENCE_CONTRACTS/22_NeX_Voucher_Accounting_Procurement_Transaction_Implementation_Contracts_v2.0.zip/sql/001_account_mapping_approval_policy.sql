-- Account mapping + approval threshold policy
CREATE SCHEMA IF NOT EXISTS nex_eos;

CREATE TABLE IF NOT EXISTS nex_eos.account_mapping_rule (
    rule_id                  varchar(160) NOT NULL,
    rule_version             varchar(64) NOT NULL,
    status                   varchar(24) NOT NULL,
    transaction_type         varchar(40) NOT NULL,
    source_category          varchar(160),
    item_class               varchar(160),
    supplier_ref             varchar(160),
    project_type             varchar(24),
    organization_ref         varchar(160),
    tax_code                 varchar(80),
    debit_account_id         uuid NOT NULL REFERENCES nex_eos.account(account_id),
    credit_account_id        uuid NOT NULL REFERENCES nex_eos.account(account_id),
    economic_category        varchar(32) NOT NULL,
    offset_economic_category varchar(32) NOT NULL DEFAULT 'NONE',
    tax_account_id           uuid REFERENCES nex_eos.account(account_id),
    tax_economic_category    varchar(32) NOT NULL DEFAULT 'NONE',
    requires_confirmation    boolean NOT NULL DEFAULT false,
    specificity_score        integer NOT NULL DEFAULT 0,
    priority                 integer NOT NULL DEFAULT 100,
    effective_from           date NOT NULL,
    effective_to             date,
    created_at               timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY(rule_id,rule_version)
);
CREATE INDEX IF NOT EXISTS ix_account_mapping_rule_lookup
    ON nex_eos.account_mapping_rule(transaction_type,source_category,status,effective_from,effective_to,specificity_score,priority);

CREATE TABLE IF NOT EXISTS nex_eos.account_mapping_decision (
    mapping_decision_id      uuid PRIMARY KEY,
    source_type              varchar(80) NOT NULL,
    source_id                varchar(160) NOT NULL,
    source_snapshot_hash     char(64) NOT NULL,
    transaction_type         varchar(40) NOT NULL,
    project_id               uuid NOT NULL REFERENCES nex_eos.project(project_id),
    rule_id                  varchar(160) NOT NULL,
    rule_version             varchar(64) NOT NULL,
    selected_mapping_json    jsonb NOT NULL,
    confirmation_proof_ref   varchar(256),
    correlation_id           varchar(128) NOT NULL,
    created_at               timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_eos.approval_threshold_rule (
    rule_id                  varchar(160) NOT NULL,
    rule_version             varchar(64) NOT NULL,
    status                   varchar(24) NOT NULL,
    domain                   varchar(80) NOT NULL,
    transaction_type         varchar(80) NOT NULL,
    currency                 char(3),
    min_amount               numeric(38,12),
    max_amount               numeric(38,12),
    project_type             varchar(24),
    economic_category        varchar(32),
    supplier_risk_class      varchar(40),
    exception_required       boolean,
    gate_type                varchar(32) NOT NULL,
    approval_policy_ref      varchar(256),
    specificity_score        integer NOT NULL DEFAULT 0,
    priority                 integer NOT NULL DEFAULT 100,
    effective_from           date NOT NULL,
    effective_to             date,
    PRIMARY KEY(rule_id,rule_version)
);
