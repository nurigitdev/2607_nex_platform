-- Purchase Requisition / PO
CREATE TABLE IF NOT EXISTS nex_eos.purchase_requisition (
    requisition_id           uuid PRIMARY KEY,
    requisition_no           varchar(80) NOT NULL UNIQUE,
    state                    varchar(32) NOT NULL,
    requester_ref            varchar(160) NOT NULL,
    project_id               uuid NOT NULL REFERENCES nex_eos.project(project_id),
    currency                 char(3) NOT NULL,
    total_estimated_amount   numeric(38,12) NOT NULL,
    approval_instance_id     uuid,
    sourcing_work_item_ref   varchar(160),
    correlation_id           varchar(128) NOT NULL,
    causation_id             varchar(128),
    idempotency_key          varchar(256) NOT NULL UNIQUE,
    version                  bigint NOT NULL DEFAULT 0,
    created_at               timestamptz NOT NULL DEFAULT now(),
    updated_at               timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_requisition_state CHECK (
      state IN ('DRAFT','SUBMITTED','APPROVAL_PENDING','APPROVED','SOURCING',
                'CONVERTED_TO_PO','REJECTED','CANCELLED','CLOSED')
    )
);

CREATE TABLE IF NOT EXISTS nex_eos.purchase_requisition_line (
    line_id                  uuid PRIMARY KEY,
    requisition_id           uuid NOT NULL REFERENCES nex_eos.purchase_requisition(requisition_id),
    line_no                  integer NOT NULL,
    item_ref                 varchar(160),
    item_description         text NOT NULL,
    source_category          varchar(160) NOT NULL,
    quantity                 numeric(38,12) NOT NULL,
    unit                     varchar(40) NOT NULL,
    estimated_unit_price     numeric(38,12),
    currency                 char(3) NOT NULL,
    project_id               uuid NOT NULL REFERENCES nex_eos.project(project_id),
    needed_by_date           date NOT NULL,
    budget_ref               varchar(160),
    UNIQUE(requisition_id,line_no),
    CONSTRAINT ck_req_qty CHECK (quantity > 0)
);

CREATE TABLE IF NOT EXISTS nex_eos.purchase_order (
    po_id                    uuid PRIMARY KEY,
    po_no                    varchar(80) NOT NULL UNIQUE,
    state                    varchar(32) NOT NULL,
    supplier_ref             varchar(160) NOT NULL,
    project_id               uuid NOT NULL REFERENCES nex_eos.project(project_id),
    currency                 char(3) NOT NULL,
    total_amount             numeric(38,12) NOT NULL,
    source_requisition_id    uuid NOT NULL REFERENCES nex_eos.purchase_requisition(requisition_id),
    selected_quote_refs_json jsonb NOT NULL DEFAULT '[]'::jsonb,
    approval_instance_id     uuid,
    correlation_id           varchar(128) NOT NULL,
    causation_id             varchar(128),
    idempotency_key          varchar(256) NOT NULL UNIQUE,
    version                  bigint NOT NULL DEFAULT 0,
    issued_at                timestamptz,
    created_at               timestamptz NOT NULL DEFAULT now(),
    updated_at               timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_po_state CHECK (
      state IN ('DRAFT','APPROVAL_PENDING','APPROVED','ISSUED','CLOSED','CANCELLED')
    )
);

CREATE TABLE IF NOT EXISTS nex_eos.purchase_order_line (
    line_id                  uuid PRIMARY KEY,
    po_id                    uuid NOT NULL REFERENCES nex_eos.purchase_order(po_id),
    line_no                  integer NOT NULL,
    item_ref                 varchar(160),
    description              text NOT NULL,
    source_category          varchar(160) NOT NULL,
    ordered_quantity         numeric(38,12) NOT NULL,
    received_quantity        numeric(38,12) NOT NULL DEFAULT 0,
    invoiced_quantity        numeric(38,12) NOT NULL DEFAULT 0,
    unit                     varchar(40) NOT NULL,
    unit_price               numeric(38,12) NOT NULL,
    line_amount              numeric(38,12) NOT NULL,
    currency                 char(3) NOT NULL,
    project_id               uuid NOT NULL REFERENCES nex_eos.project(project_id),
    tax_code                 varchar(80),
    expected_delivery_date   date,
    UNIQUE(po_id,line_no),
    CONSTRAINT ck_po_qty CHECK (ordered_quantity > 0 AND received_quantity >= 0 AND invoiced_quantity >= 0)
);

-- v2 baseline: every requisition/PO is single-project.
-- Application/domain invariant: all line project_id values == header project_id.
