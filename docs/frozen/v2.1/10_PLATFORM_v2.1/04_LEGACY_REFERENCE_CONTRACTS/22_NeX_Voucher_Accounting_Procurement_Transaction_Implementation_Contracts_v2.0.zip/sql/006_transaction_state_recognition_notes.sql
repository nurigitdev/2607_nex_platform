-- State / API invariants and reconciliation indexes

CREATE INDEX IF NOT EXISTS ix_requisition_project_state
    ON nex_eos.purchase_requisition(project_id,state,created_at);
CREATE INDEX IF NOT EXISTS ix_po_project_state
    ON nex_eos.purchase_order(project_id,state,issued_at);
CREATE INDEX IF NOT EXISTS ix_invoice_project_state
    ON nex_eos.supplier_invoice(project_id,state,invoice_date);
CREATE INDEX IF NOT EXISTS ix_invoice_supplier_no
    ON nex_eos.supplier_invoice(supplier_ref,supplier_invoice_no);
CREATE INDEX IF NOT EXISTS ix_commitment_project_status
    ON nex_eos.project_commitment(project_id,status,source_category);

-- Financial recognition source invariant:
-- requisition APPROVED: authorization to source, not cost
-- PO ISSUED: commitment, not actual cost
-- receipt CONFIRMED: fulfillment evidence; actual cost only if explicit accrual policy is added
-- invoice MATCHED/APPROVED: eligible for voucher, not actual cost
-- purchase voucher POSTED to Project Financial Ledger: actual cost recognized

-- Payment settlement:
-- AP debit / Cash credit, both economic category NONE for Project P/L.
-- Paying a supplier invoice does not recognize the project cost a second time.
