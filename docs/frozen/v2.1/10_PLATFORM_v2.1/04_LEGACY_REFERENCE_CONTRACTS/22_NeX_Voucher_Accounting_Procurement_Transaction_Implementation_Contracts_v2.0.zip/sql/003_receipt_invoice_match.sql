-- Goods/Service Receipt + Supplier Invoice + Matching
CREATE TABLE IF NOT EXISTS nex_eos.goods_receipt (
    receipt_id               uuid PRIMARY KEY,
    receipt_no               varchar(80) NOT NULL UNIQUE,
    po_id                    uuid NOT NULL REFERENCES nex_eos.purchase_order(po_id),
    project_id               uuid NOT NULL REFERENCES nex_eos.project(project_id),
    state                    varchar(24) NOT NULL,
    receipt_type             varchar(24) NOT NULL,
    received_by_ref          varchar(160) NOT NULL,
    receipt_date             date NOT NULL,
    artifact_refs_json       jsonb NOT NULL DEFAULT '[]'::jsonb,
    correlation_id           varchar(128) NOT NULL,
    version                  bigint NOT NULL DEFAULT 0,
    created_at               timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_receipt_state CHECK (state IN ('DRAFT','CONFIRMED','REVERSED')),
    CONSTRAINT ck_receipt_type CHECK (receipt_type IN ('GOODS','SERVICE_ACCEPTANCE'))
);

CREATE TABLE IF NOT EXISTS nex_eos.goods_receipt_line (
    receipt_line_id          uuid PRIMARY KEY,
    receipt_id               uuid NOT NULL REFERENCES nex_eos.goods_receipt(receipt_id),
    po_line_id               uuid NOT NULL REFERENCES nex_eos.purchase_order_line(line_id),
    received_quantity        numeric(38,12) NOT NULL,
    accepted_amount          numeric(38,12),
    UNIQUE(receipt_id,po_line_id),
    CONSTRAINT ck_receipt_qty CHECK (received_quantity >= 0)
);

CREATE TABLE IF NOT EXISTS nex_eos.supplier_invoice (
    invoice_id               uuid PRIMARY KEY,
    supplier_invoice_no      varchar(160) NOT NULL,
    supplier_ref             varchar(160) NOT NULL,
    state                    varchar(32) NOT NULL,
    project_id               uuid NOT NULL REFERENCES nex_eos.project(project_id),
    currency                 char(3) NOT NULL,
    invoice_date             date NOT NULL,
    po_id                    uuid REFERENCES nex_eos.purchase_order(po_id),
    net_total                numeric(38,12) NOT NULL,
    tax_total                numeric(38,12) NOT NULL DEFAULT 0,
    gross_total              numeric(38,12) NOT NULL,
    invoice_fingerprint      char(64) NOT NULL UNIQUE,
    match_result_id          uuid,
    approval_instance_id     uuid,
    voucher_id               uuid REFERENCES nex_eos.voucher(voucher_id),
    artifact_refs_json       jsonb NOT NULL DEFAULT '[]'::jsonb,
    correlation_id           varchar(128) NOT NULL,
    causation_id             varchar(128),
    version                  bigint NOT NULL DEFAULT 0,
    created_at               timestamptz NOT NULL DEFAULT now(),
    updated_at               timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_invoice_state CHECK (
      state IN ('RECEIVED','VALIDATED','MATCH_PENDING','MATCHED','EXCEPTION',
                'APPROVAL_PENDING','APPROVED','VOUCHER_CREATED','POSTED','REJECTED','CANCELLED')
    ),
    CONSTRAINT ck_invoice_amounts CHECK (gross_total = net_total + tax_total)
);

CREATE TABLE IF NOT EXISTS nex_eos.supplier_invoice_line (
    line_id                  uuid PRIMARY KEY,
    invoice_id               uuid NOT NULL REFERENCES nex_eos.supplier_invoice(invoice_id),
    line_no                  integer NOT NULL,
    po_line_id               uuid REFERENCES nex_eos.purchase_order_line(line_id),
    description              text NOT NULL,
    quantity                 numeric(38,12) NOT NULL,
    unit_price               numeric(38,12) NOT NULL,
    net_amount               numeric(38,12) NOT NULL,
    tax_amount               numeric(38,12) NOT NULL DEFAULT 0,
    gross_amount             numeric(38,12) NOT NULL,
    currency                 char(3) NOT NULL,
    project_id               uuid NOT NULL REFERENCES nex_eos.project(project_id),
    source_category          varchar(160) NOT NULL,
    tax_code                 varchar(80),
    UNIQUE(invoice_id,line_no),
    CONSTRAINT ck_invoice_line_amount CHECK (gross_amount = net_amount + tax_amount)
);

CREATE TABLE IF NOT EXISTS nex_eos.invoice_match_result (
    match_result_id          uuid PRIMARY KEY,
    invoice_id               uuid NOT NULL UNIQUE REFERENCES nex_eos.supplier_invoice(invoice_id),
    po_id                    uuid REFERENCES nex_eos.purchase_order(po_id),
    match_mode               varchar(24) NOT NULL,
    status                   varchar(24) NOT NULL,
    policy_ref               varchar(256) NOT NULL,
    checks_json              jsonb NOT NULL,
    exception_codes_json     jsonb NOT NULL DEFAULT '[]'::jsonb,
    override_approval_id     uuid,
    created_at               timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_match_mode CHECK (match_mode IN ('TWO_WAY','THREE_WAY','NON_PO')),
    CONSTRAINT ck_match_status CHECK (status IN ('MATCHED','EXCEPTION','OVERRIDE_APPROVED','REJECTED'))
);
