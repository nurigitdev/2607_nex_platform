-- Purchase Invoice Match -> Voucher creation -> Actual Cost posting

-- A. Create purchase Voucher only from accepted match result (or governed NON_PO rule).
BEGIN;
SELECT *
  FROM nex_eos.supplier_invoice
 WHERE invoice_id=:invoice_id FOR UPDATE;

SELECT *
  FROM nex_eos.invoice_match_result
 WHERE invoice_id=:invoice_id FOR UPDATE;

-- Domain:
-- invoice state MATCHED or APPROVED
-- match status MATCHED or OVERRIDE_APPROVED
-- single Project invariant
-- AccountMappingDecision(s) RESOLVED
-- generated voucher lines balanced
-- recoverable tax may map to economic category NONE

INSERT INTO nex_eos.voucher(... voucher_type='PURCHASE', state='DRAFT', ...)
VALUES (...);

INSERT INTO nex_eos.voucher_line(...)
SELECT ... FROM jsonb_to_recordset(:generated_lines_json::jsonb) ...;

UPDATE nex_eos.supplier_invoice
   SET state='VOUCHER_CREATED',
       voucher_id=:voucher_id,
       version=version+1,
       updated_at=now()
 WHERE invoice_id=:invoice_id
   AND version=:expected_invoice_version;

INSERT INTO nex_eos.event_outbox(... 'PURCHASE_VOUCHER_CREATED' ...);
COMMIT;

-- B. Approval threshold resolves whether protected POST operation needs Formal Approval.
-- If required, approval proof must bind exact voucher payload and capability/operation.

-- C. Actual Project cost is recognized ONLY when Project Financial Ledger posting commits.
-- The posting projects only voucher lines with economic_category != 'NONE'.
-- Balance sheet offsets (AP/Cash/Recoverable Tax) remain in Voucher accounting layer.

-- D. After posting:
UPDATE nex_eos.supplier_invoice
   SET state='POSTED', version=version+1, updated_at=now()
 WHERE invoice_id=:invoice_id AND state='VOUCHER_CREATED';

INSERT INTO nex_eos.event_outbox(... 'PROJECT_ACTUAL_COST_RECOGNIZED' ...);
