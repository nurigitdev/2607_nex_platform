# NeX Voucher / Accounting / Procurement Transaction v2.0 Reference Package

Accompanies `22_NeX_Voucher_Accounting_Procurement_Transaction_Design_v2.0`.

## Core decisions
1. Account mapping is deterministic rule-first and produces stable AccountRefs. LLM candidates never become account IDs directly.
2. Voucher line templates:
   - Expense: Dr Expense, Cr Cash/Employee Payable/AP.
   - Revenue: Dr AR/Cash, Cr Revenue.
   - Purchase Invoice: Dr Material/Expense (+ optional tax), Cr AP.
   - Payment: Dr AP, Cr Cash; both P/L category NONE.
3. Voucher must balance; Project Financial Ledger projects only lines whose economic category != NONE.
4. Recoverable VAT is category NONE. Non-recoverable tax can be mapped to DIRECT_EXPENSE/COMMON_COST by rule.
5. Requisition and PO are sourcing/commitment transactions, not Project Actual Cost.
6. PO becomes Project Commitment only when ISSUED.
7. Goods/Service Receipt is fulfillment evidence. v2 default actual-cost recognition basis is INVOICE_MATCH_APPROVED; receipt-based accrual is an explicit policy extension.
8. Invoice match supports TWO_WAY / THREE_WAY / NON_PO with deterministic tolerances and duplicate fingerprint.
9. Actual Project Cost is recognized only when the Purchase Voucher is POSTED into Project Financial Ledger.
10. Procurement WorkResult returns PO/Commitment/expected delivery to the parent WorkItem; it must not claim actual cost recognition.
11. Approval threshold selection is deterministic and versioned; Formal Approval proof binds the exact protected operation/payload.
12. Paying the supplier invoice is settlement, not a second Project P/L cost.

All 8 schemas/examples and Python modules are validated during artifact generation.
