from __future__ import annotations
from typing import Any, Mapping

Json = Mapping[str, Any]

class PlanCompiler:
    """Transforms validated logical AgentPlan into immutable ExecutablePlan."""

    def __init__(
        self, capability_registry, skill_registry, resolver,
        authorization_pdp, policy_registry, id_generator, clock
    ):
        self.capability_registry = capability_registry
        self.skill_registry = skill_registry
        self.resolver = resolver
        self.authorization_pdp = authorization_pdp
        self.policy_registry = policy_registry
        self.id_generator = id_generator
        self.clock = clock

    async def compile(self, work_intent: Json, logical_plan: Json, ctx: Json) -> dict:
        executable_steps: list[dict] = []
        logical_to_exec: dict[str, str] = {}

        for logical_step in self._topological_order(logical_plan["steps"]):
            compiled = await self._compile_step(
                work_intent, logical_step, ctx, logical_to_exec
            )
            for step in compiled:
                executable_steps.append(step)
                logical_to_exec.setdefault(logical_step["step_id"], step["step_id"])

        plan = {
            "schema_version": "1.0",
            "executable_plan_id": self.id_generator.new_id(),
            "execution_id": ctx["execution_id"],
            "work_item_id": ctx.get("work_item_id"),
            "work_intent_id": work_intent["intent_id"],
            "agent_plan_id": logical_plan["plan_id"],
            "agent_plan_version": logical_plan["plan_version"],
            "plan_kind": logical_plan["plan_kind"],
            "goal": logical_plan["goal"],
            "compiled_at": self.clock.now_iso(),
            "compiler_provenance": await self._provenance(),
            "resolved_context_refs": ctx.get("resolved_context_refs", []),
            "steps": executable_steps,
            "completion_criteria": logical_plan["completion_criteria"],
            "source_plan_template": logical_plan.get("source_plan_template"),
            "supersedes_executable_plan_id": ctx.get("supersedes_executable_plan_id"),
            "metadata": {},
        }
        plan["plan_hash"] = self._canonical_sha256(plan)
        return plan

    async def _compile_step(
        self, work_intent: Json, step: Json, ctx: Json,
        logical_to_exec: dict[str, str]
    ) -> list[dict]:
        step_type = step["step_type"]
        if step_type == "LOCAL_CAPABILITY":
            return await self._compile_local(step, ctx, logical_to_exec)
        if step_type == "DELEGATE_WORK":
            return [await self._compile_delegate(step, ctx, logical_to_exec)]
        if step_type == "AGGREGATE":
            return [self._compile_aggregate(step, logical_to_exec)]
        if step_type == "REPORT":
            return [self._compile_report(step, logical_to_exec)]
        raise ValueError(f"Unsupported logical step type: {step_type}")

    async def _compile_local(self, step: Json, ctx: Json, mapping: dict) -> list[dict]:
        capability = await self.capability_registry.get(step["required_capability"])
        resolved_inputs = await self._resolve_inputs(step, ctx)
        skill = await self.skill_registry.resolve_certified(capability, ctx)
        policy = await self.policy_registry.execution_policy(capability, ctx)

        compiled: list[dict] = []
        dependency_ids = [mapping[d] for d in step.get("depends_on", [])]

        if policy.human_gate == "CONFIRMATION":
            gate_id = self.id_generator.new_step_id()
            compiled.append(self._confirmation_step(
                gate_id, step["step_id"], dependency_ids, policy
            ))
            dependency_ids = [gate_id]
        elif policy.human_gate == "FORMAL_APPROVAL":
            gate_id = self.id_generator.new_step_id()
            compiled.append(self._approval_step(
                gate_id, step["step_id"], dependency_ids, policy
            ))
            dependency_ids = [gate_id]

        compiled.append(self._business_step(
            step, capability, skill, policy, resolved_inputs, dependency_ids
        ))
        return compiled

    def _topological_order(self, steps): ...
    async def _resolve_inputs(self, step, ctx): ...
    async def _compile_delegate(self, step, ctx, mapping): ...
    def _compile_aggregate(self, step, mapping): ...
    def _compile_report(self, step, mapping): ...
    def _confirmation_step(self, gate_id, logical_step_id, deps, policy): ...
    def _approval_step(self, gate_id, logical_step_id, deps, policy): ...
    def _business_step(self, step, capability, skill, policy, inputs, deps): ...
    async def _provenance(self): ...
    def _canonical_sha256(self, obj): ...
