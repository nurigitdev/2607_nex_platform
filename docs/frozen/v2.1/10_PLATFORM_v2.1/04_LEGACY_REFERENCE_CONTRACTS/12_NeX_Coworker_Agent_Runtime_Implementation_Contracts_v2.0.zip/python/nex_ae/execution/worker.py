from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping

Json = Mapping[str, Any]

@dataclass(frozen=True)
class ClaimedJob:
    job_id: str
    lease_token: str
    job_type: str
    payload: Json
    execution_id: str | None
    attempts: int

class RuntimeWorker:
    """Reference worker loop. Business side effects remain idempotent independently of job lease."""

    def __init__(self, queue, dispatcher, worker_id: str, lease_seconds: int = 90):
        self.queue = queue
        self.dispatcher = dispatcher
        self.worker_id = worker_id
        self.lease_seconds = lease_seconds

    async def run_once(self) -> bool:
        job = await self.queue.claim(self.worker_id, self.lease_seconds)
        if job is None:
            return False
        try:
            await self.dispatcher.dispatch(job)
        except Exception as exc:
            await self.queue.fail(
                job["job_id"], job["lease_token"],
                {"type": type(exc).__name__, "message": str(exc)}
            )
            return True

        ok = await self.queue.complete(job["job_id"], job["lease_token"])
        if not ok:
            # The lease may have expired/reclaimed. Never infer that business effects
            # should be repeated; reconciliation/idempotency rules decide.
            raise RuntimeError("STALE_JOB_LEASE")
        return True
