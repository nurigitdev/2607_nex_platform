from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping

Json = Mapping[str, Any]

@dataclass(frozen=True)
class ValidationIssue:
    code: str
    severity: str
    step_id: str | None
    message: str

@dataclass(frozen=True)
class ValidationReport:
    valid: bool
    issues: tuple[ValidationIssue, ...]

class SemanticPlanValidator:
    """Deterministic validator; never asks the LLM whether its own plan is safe."""

    def __init__(self, capability_registry, policy):
        self.capability_registry = capability_registry
        self.policy = policy

    async def validate(self, plan: Json, context: Json) -> ValidationReport:
        issues: list[ValidationIssue] = []
        steps = list(plan.get("steps", []))

        if len(steps) > self.policy.max_plan_steps:
            issues.append(ValidationIssue(
                "PLAN_STEP_LIMIT_EXCEEDED", "ERROR", None, "Too many steps"
            ))

        ids = [s["step_id"] for s in steps]
        if len(ids) != len(set(ids)):
            issues.append(ValidationIssue(
                "PLAN_DUPLICATE_STEP_ID", "ERROR", None, "Duplicate step id"
            ))

        deps = {s["step_id"]: tuple(s.get("depends_on", [])) for s in steps}
        known = set(ids)
        for sid, refs in deps.items():
            for ref in refs:
                if ref not in known:
                    issues.append(ValidationIssue(
                        "PLAN_UNKNOWN_DEPENDENCY", "ERROR", sid, ref
                    ))

        if self._has_cycle(deps):
            issues.append(ValidationIssue(
                "PLAN_DEPENDENCY_CYCLE", "ERROR", None, "Dependency graph has a cycle"
            ))

        for step in steps:
            step_type = step["step_type"]
            cap = step.get("required_capability")
            if step_type in ("LOCAL_CAPABILITY", "DELEGATE_WORK") and not cap:
                issues.append(ValidationIssue(
                    "PLAN_CAPABILITY_REQUIRED", "ERROR", step["step_id"],
                    "Capability is required"
                ))
                continue
            if cap:
                try:
                    contract = await self.capability_registry.get(cap)
                except Exception:
                    issues.append(ValidationIssue(
                        "PLAN_CAPABILITY_NOT_FOUND", "ERROR", step["step_id"], cap
                    ))
                    continue
                if contract.risk_level > context["risk_ceiling"]:
                    issues.append(ValidationIssue(
                        "PLAN_RISK_CEILING_EXCEEDED", "ERROR", step["step_id"], cap
                    ))

            if step_type not in {
                "LOCAL_CAPABILITY", "DELEGATE_WORK", "AGGREGATE", "REPORT"
            }:
                issues.append(ValidationIssue(
                    "PLAN_STEP_TYPE_NOT_ALLOWED", "ERROR", step["step_id"], step_type
                ))

            if "actual_assignee_id" in step:
                issues.append(ValidationIssue(
                    "PLAN_ACTUAL_ASSIGNEE_FORBIDDEN", "ERROR", step["step_id"],
                    "Planner must not choose actual assignee"
                ))

        return ValidationReport(
            valid=not any(i.severity == "ERROR" for i in issues),
            issues=tuple(issues),
        )

    @staticmethod
    def _has_cycle(deps: dict[str, tuple[str, ...]]) -> bool:
        visiting: set[str] = set()
        visited: set[str] = set()

        def dfs(node: str) -> bool:
            if node in visiting:
                return True
            if node in visited:
                return False
            visiting.add(node)
            for nxt in deps.get(node, ()):
                if dfs(nxt):
                    return True
            visiting.remove(node)
            visited.add(node)
            return False

        return any(dfs(n) for n in deps)
