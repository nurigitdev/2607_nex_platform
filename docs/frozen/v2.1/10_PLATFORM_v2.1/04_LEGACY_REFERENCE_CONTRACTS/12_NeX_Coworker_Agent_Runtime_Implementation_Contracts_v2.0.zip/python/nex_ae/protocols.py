from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping, Protocol, Sequence

Json = Mapping[str, Any]

@dataclass(frozen=True)
class StructuredGenerationRequest:
    model_profile: str
    response_schema_ref: str
    system_prompt: str
    user_content: str
    context_hash: str
    timeout_ms: int

@dataclass(frozen=True)
class StructuredGenerationResponse:
    value: Json
    model_ref: str
    latency_ms: int

@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    reason_codes: tuple[str, ...]
    policy_snapshot_ref: str
    human_gate: str | None = None

@dataclass(frozen=True)
class CapabilityContract:
    capability_id: str
    contract_version: str
    contract_hash: str
    risk_level: str
    owner_context: str
    required_permissions: tuple[str, ...]
    exposure: tuple[str, ...]
    input_schema_ref: str
    output_schema_ref: str
    idempotency_required: bool
    commit_semantics: str

@dataclass(frozen=True)
class SkillBinding:
    skill_id: str
    version: str
    contract_hash: str
    runtime: str

class ModelGateway(Protocol):
    async def generate_structured(
        self, request: StructuredGenerationRequest
    ) -> StructuredGenerationResponse: ...

class CapabilityRegistry(Protocol):
    async def get(self, capability_id: str) -> CapabilityContract: ...
    async def search(self, query: Json, limit: int) -> Sequence[Json]: ...

class SkillRegistry(Protocol):
    async def resolve_certified(
        self, capability: CapabilityContract, context: Json
    ) -> SkillBinding | None: ...

class AuthorizationPDP(Protocol):
    async def authorize(
        self, *,
        principal_ref: str,
        business_actor_ref: str,
        capability: CapabilityContract,
        resource_refs: Sequence[Json],
        context: Json,
    ) -> PolicyDecision: ...

class CanonicalResolver(Protocol):
    async def resolve(self, selector: Json, context: Json) -> Json: ...

class WorkCoordinator(Protocol):
    async def create_child_work(
        self, *, command: Json, idempotency_key: str
    ) -> Json: ...
    async def report_result(
        self, *, command: Json, idempotency_key: str
    ) -> Json: ...

class CanonicalInvoker(Protocol):
    async def query(self, capability: str, payload: Json, trace: Json) -> Json: ...
    async def command(
        self, capability: str, payload: Json, trace: Json,
        idempotency_key: str, expected_version: str | int | None
    ) -> Json: ...

class PlanRepository(Protocol):
    async def save_logical_plan(self, plan: Json) -> None: ...
    async def save_executable_plan(self, plan: Json) -> None: ...
    async def load_executable_plan(self, executable_plan_id: str) -> Json: ...

class ExecutionRepository(Protocol):
    async def load_execution(self, execution_id: str) -> Json: ...
    async def update_state(
        self, execution_id: str, expected_version: int, new_state: str
    ) -> int: ...

class JobQueue(Protocol):
    async def enqueue(
        self, job_type: str, payload: Json, *, dedup_key: str | None,
        priority: int = 0
    ) -> str: ...
    async def claim(self, worker_id: str, lease_seconds: int) -> Json | None: ...
    async def heartbeat(self, job_id: str, lease_token: str, lease_seconds: int) -> bool: ...
    async def complete(self, job_id: str, lease_token: str) -> bool: ...
    async def fail(self, job_id: str, lease_token: str, error: Json) -> bool: ...

class EventPublisher(Protocol):
    async def append_outbox(self, event: Json) -> None: ...
