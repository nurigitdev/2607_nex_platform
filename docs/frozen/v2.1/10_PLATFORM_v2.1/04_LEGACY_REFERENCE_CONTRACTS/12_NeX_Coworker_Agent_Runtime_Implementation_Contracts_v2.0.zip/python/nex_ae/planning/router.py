from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

Json = Mapping[str, Any]

@dataclass(frozen=True)
class RouterPolicy:
    top_k: int = 5
    lexical_weight: float = 0.45
    semantic_weight: float = 0.45
    capability_overlap_weight: float = 0.10

@dataclass(frozen=True)
class RouteResult:
    route_type: str
    direct_capability_id: str | None = None
    routing_binding_id: str | None = None
    plan_template_id: str | None = None
    plan_template_version: str | None = None
    evidence: Json | None = None

class PlanRouter:
    """Reference algorithm contract. Business IDs are selected only from registries."""

    def __init__(
        self, direct_bindings, routing_bindings, template_registry,
        retriever, selector, policy: RouterPolicy
    ):
        self.direct_bindings = direct_bindings
        self.routing_bindings = routing_bindings
        self.template_registry = template_registry
        self.retriever = retriever
        self.selector = selector
        self.policy = policy

    async def route(self, work_intent: Json, runtime_context: Json) -> RouteResult:
        direct = await self.direct_bindings.match(work_intent, runtime_context)
        if direct is not None:
            return RouteResult(
                route_type="DIRECT",
                direct_capability_id=direct["capability_id"],
                evidence={"binding_id": direct["binding_id"]},
            )

        certified = await self.routing_bindings.match(work_intent, runtime_context)
        if certified is not None:
            return RouteResult(
                route_type="CERTIFIED_BINDING",
                routing_binding_id=certified["routing_binding_id"],
                plan_template_id=certified["plan_template_id"],
                plan_template_version=certified["version"],
            )

        eligible: Sequence[Json] = await self.template_registry.eligible(
            work_intent, runtime_context
        )
        if not eligible:
            return RouteResult(route_type="DYNAMIC")

        ranked = await self.retriever.rank(
            work_intent, eligible,
            top_k=self.policy.top_k,
            lexical_weight=self.policy.lexical_weight,
            semantic_weight=self.policy.semantic_weight,
            capability_overlap_weight=self.policy.capability_overlap_weight,
        )
        if not ranked:
            return RouteResult(route_type="DYNAMIC")

        decision = await self.selector.select(work_intent, ranked, runtime_context)
        if decision["decision"] == "NONE":
            return RouteResult(route_type="DYNAMIC", evidence={"candidates": ranked})

        selected_id = decision["selected_candidate_id"]
        selected = next(
            (c for c in ranked if c["candidate_id"] == selected_id), None
        )
        if selected is None:
            raise ValueError("PLAN_SELECTOR_RETURNED_NON_CANDIDATE")

        return RouteResult(
            route_type="KNOWN_TEMPLATE",
            plan_template_id=selected["plan_template_id"],
            plan_template_version=selected["version"],
            evidence={"candidates": ranked, "selector": decision},
        )
