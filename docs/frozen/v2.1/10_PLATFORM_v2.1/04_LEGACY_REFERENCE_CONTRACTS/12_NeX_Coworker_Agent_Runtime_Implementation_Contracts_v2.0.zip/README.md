# NeX Coworker Agent Runtime v2.0 — Reference Implementation Contracts

This package accompanies `12_Coworker_Agent_Semi_Autonomous_Detailed_Design_v2.0`.

Contents:
- `schemas/`: JSON Schema Draft 2020-12 reference contracts.
- `python/nex_ae/`: Python Protocol and algorithm skeletons. These are implementation blueprints, not production-ready code.
- `sql/`: PostgreSQL-first reference physical model, durable JobQueue/Lease/Inbox/Outbox, and checkpoint transaction boundaries.

Design rules:
1. LLM produces structured candidates; deterministic validation/compiler/policy controls execution.
2. Background workers authenticate as service principals and rebuild effective authority on resume.
3. Job lease coordinates workers; business idempotency protects side effects.
4. `UNKNOWN_COMMIT_STATE` never causes blind retry.
5. Checkpoints contain no long-lived user token or raw secret.
6. Cross-service business writes go through canonical API/event contracts, not direct DB writes.

All JSON Schemas were meta-schema validated during artifact generation.
