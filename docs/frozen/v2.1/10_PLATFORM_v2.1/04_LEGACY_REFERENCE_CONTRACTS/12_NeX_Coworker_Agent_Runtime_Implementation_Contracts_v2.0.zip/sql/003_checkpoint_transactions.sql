-- Checkpoint transaction boundaries (reference pseudo-SQL).

-- A. Suspend after remote idempotent side effect/reference creation has succeeded.
BEGIN;

SELECT execution_id, state, version
  FROM nex_ae.agent_execution
 WHERE execution_id = :execution_id
 FOR UPDATE;

-- Verify expected RUNNING/version in application.

INSERT INTO nex_ae.agent_checkpoint(
    checkpoint_id, execution_id, executable_plan_id, plan_version,
    current_step_id, wait_state, checkpoint_json, checkpoint_hash
) VALUES (
    :checkpoint_id, :execution_id, :executable_plan_id, :plan_version,
    :current_step_id, :wait_state, :checkpoint_json::jsonb, :checkpoint_hash
);

INSERT INTO nex_ae.execution_wait(
    wait_id, execution_id, checkpoint_id, condition_type,
    external_ref, expected_event_name
) VALUES (
    :wait_id, :execution_id, :checkpoint_id, :condition_type,
    :external_ref, :expected_event_name
);

UPDATE nex_ae.agent_execution
   SET state = :wait_state,
       current_step_id = :current_step_id,
       version = version + 1,
       updated_at = now()
 WHERE execution_id = :execution_id
   AND version = :expected_execution_version;

INSERT INTO nex_ae.runtime_outbox(
    outbox_id, event_id, event_name, aggregate_ref,
    correlation_id, causation_id, payload_json
) VALUES (
    :outbox_id, :event_id, 'AGENT_EXECUTION_WAITING',
    'AGENT_EXECUTION:' || :execution_id,
    :correlation_id, :causation_id, :event_payload::jsonb
);

-- If this transaction is running inside the job dispatcher:
UPDATE nex_ae.runtime_job
   SET state='DONE', claimed_by=NULL, lease_token=NULL, lease_until=NULL, updated_at=now()
 WHERE job_id=:job_id AND state='CLAIMED' AND lease_token=:lease_token;

COMMIT;

-- B. Matching domain event -> create exactly one resume job.
BEGIN;

INSERT INTO nex_ae.runtime_event_inbox(
    event_id, event_name, aggregate_ref, correlation_id, causation_id, payload_json
) VALUES (
    :event_id, :event_name, :aggregate_ref, :correlation_id, :causation_id, :payload::jsonb
)
ON CONFLICT (event_id) DO NOTHING;

-- Application exits if event_id already existed.

SELECT wait_id, execution_id, checkpoint_id
  FROM nex_ae.execution_wait
 WHERE state='WAITING'
   AND condition_type=:condition_type
   AND external_ref=:external_ref
 FOR UPDATE;

UPDATE nex_ae.execution_wait
   SET state='SATISFIED', satisfied_event_id=:event_id, satisfied_at=now()
 WHERE wait_id=:wait_id AND state='WAITING';

INSERT INTO nex_ae.runtime_job(
    job_id, job_type, state, payload_json, execution_id,
    correlation_id, causation_id, dedup_key
) VALUES (
    :resume_job_id, 'RESUME_EXECUTION', 'READY', :resume_payload::jsonb,
    :execution_id, :correlation_id, :event_id,
    'resume:' || :execution_id || ':' || :checkpoint_id
)
ON CONFLICT DO NOTHING;

UPDATE nex_ae.runtime_event_inbox
   SET status='HANDLED', handled_at=now()
 WHERE event_id=:event_id;

COMMIT;

-- C. Resume worker first rebuilds and reauthorizes Effective Authority Context.
-- Only after successful reauthorization:
BEGIN;

SELECT *
  FROM nex_ae.agent_execution
 WHERE execution_id=:execution_id
 FOR UPDATE;

SELECT *
  FROM nex_ae.agent_checkpoint
 WHERE checkpoint_id=:checkpoint_id
 FOR UPDATE;

UPDATE nex_ae.agent_execution
   SET state='RUNNING',
       version=version+1,
       updated_at=now()
 WHERE execution_id=:execution_id
   AND state IN (
       'WAITING_INPUT','WAITING_CONFIRMATION',
       'WAITING_APPROVAL','WAITING_DEPENDENCY','BLOCKED'
   );

UPDATE nex_ae.agent_checkpoint
   SET resumed_at=now()
 WHERE checkpoint_id=:checkpoint_id
   AND resumed_at IS NULL;

INSERT INTO nex_ae.runtime_outbox(...)
VALUES (... 'AGENT_EXECUTION_RESUMED' ...);

COMMIT;

-- If reauthorization fails, transition to BLOCKED/ESCALATED instead of RUNNING.
