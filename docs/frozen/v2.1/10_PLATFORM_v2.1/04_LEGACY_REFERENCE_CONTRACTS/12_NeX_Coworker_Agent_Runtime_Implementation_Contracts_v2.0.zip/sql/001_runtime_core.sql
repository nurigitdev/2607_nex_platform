-- NeX AE Runtime v2.0 - reference physical design
-- Application generates UUID/ULID values; no extension dependency required.

CREATE SCHEMA IF NOT EXISTS nex_ae;

CREATE TABLE IF NOT EXISTS nex_ae.agent_execution (
    execution_id            uuid PRIMARY KEY,
    execution_mode          varchar(40) NOT NULL,
    source_type             varchar(40) NOT NULL,
    source_ref              varchar(160),
    work_item_id            uuid,
    actor_type              varchar(40) NOT NULL,
    actor_ref               varchar(160) NOT NULL,
    coworker_profile_id     uuid,
    active_role_binding_id  uuid,
    state                   varchar(48) NOT NULL,
    current_step_id         varchar(32),
    plan_version            integer,
    replan_count            integer NOT NULL DEFAULT 0,
    correlation_id          varchar(128) NOT NULL,
    version                 bigint NOT NULL DEFAULT 0,
    started_at              timestamptz,
    completed_at            timestamptz,
    created_at              timestamptz NOT NULL DEFAULT now(),
    updated_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_agent_execution_state CHECK (
        state IN (
            'QUEUED','RUNNING','WAITING_INPUT','WAITING_CONFIRMATION',
            'WAITING_APPROVAL','WAITING_DEPENDENCY','BLOCKED',
            'RECONCILIATION_REQUIRED','ESCALATED','SUCCEEDED','FAILED','CANCELLED'
        )
    )
);

CREATE INDEX IF NOT EXISTS ix_agent_execution_state
    ON nex_ae.agent_execution(state, updated_at);
CREATE INDEX IF NOT EXISTS ix_agent_execution_workitem
    ON nex_ae.agent_execution(work_item_id);
CREATE INDEX IF NOT EXISTS ix_agent_execution_corr
    ON nex_ae.agent_execution(correlation_id);

CREATE TABLE IF NOT EXISTS nex_ae.work_intent (
    intent_id                uuid PRIMARY KEY,
    execution_id             uuid NOT NULL REFERENCES nex_ae.agent_execution(execution_id),
    schema_version           varchar(16) NOT NULL,
    intent_json              jsonb NOT NULL,
    input_context_hash       char(64),
    prompt_template_id       varchar(160),
    prompt_template_version  varchar(64),
    model_profile            varchar(80),
    model_ref                varchar(160),
    created_at               timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_ae.agent_plan (
    plan_id                  uuid NOT NULL,
    plan_version             integer NOT NULL,
    execution_id             uuid NOT NULL REFERENCES nex_ae.agent_execution(execution_id),
    work_intent_id           uuid REFERENCES nex_ae.work_intent(intent_id),
    plan_kind                varchar(32) NOT NULL,
    plan_json                jsonb NOT NULL,
    plan_hash                char(64) NOT NULL,
    supersedes_plan_id       uuid,
    supersedes_plan_version  integer,
    replan_reason            text,
    created_at               timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY(plan_id, plan_version)
);

CREATE TABLE IF NOT EXISTS nex_ae.executable_plan (
    executable_plan_id       uuid PRIMARY KEY,
    execution_id             uuid NOT NULL REFERENCES nex_ae.agent_execution(execution_id),
    plan_id                  uuid NOT NULL,
    plan_version             integer NOT NULL,
    schema_version           varchar(16) NOT NULL,
    executable_plan_json     jsonb NOT NULL,
    plan_hash                char(64) NOT NULL,
    compiler_version         varchar(64) NOT NULL,
    policy_snapshot_ref      varchar(256) NOT NULL,
    created_at               timestamptz NOT NULL DEFAULT now(),
    UNIQUE(execution_id, plan_version),
    FOREIGN KEY(plan_id, plan_version)
        REFERENCES nex_ae.agent_plan(plan_id, plan_version)
);

CREATE TABLE IF NOT EXISTS nex_ae.plan_step_execution (
    step_execution_id        uuid PRIMARY KEY,
    execution_id             uuid NOT NULL REFERENCES nex_ae.agent_execution(execution_id),
    executable_plan_id       uuid NOT NULL REFERENCES nex_ae.executable_plan(executable_plan_id),
    step_id                  varchar(32) NOT NULL,
    logical_step_id          varchar(32) NOT NULL,
    attempt_no               integer NOT NULL DEFAULT 1,
    state                    varchar(40) NOT NULL,
    operation_key            varchar(256),
    idempotency_key          varchar(256),
    input_hash               char(64),
    output_json              jsonb,
    output_refs              jsonb,
    error_json               jsonb,
    started_at               timestamptz,
    completed_at             timestamptz,
    created_at               timestamptz NOT NULL DEFAULT now(),
    UNIQUE(executable_plan_id, step_id, attempt_no)
);

CREATE INDEX IF NOT EXISTS ix_step_execution_exec_state
    ON nex_ae.plan_step_execution(execution_id, state);

CREATE TABLE IF NOT EXISTS nex_ae.agent_checkpoint (
    checkpoint_id            uuid PRIMARY KEY,
    execution_id             uuid NOT NULL REFERENCES nex_ae.agent_execution(execution_id),
    executable_plan_id       uuid NOT NULL REFERENCES nex_ae.executable_plan(executable_plan_id),
    plan_version             integer NOT NULL,
    current_step_id          varchar(32),
    wait_state               varchar(48) NOT NULL,
    checkpoint_json          jsonb NOT NULL,
    checkpoint_hash          char(64) NOT NULL,
    resumed_at               timestamptz,
    created_at               timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_ae.execution_wait (
    wait_id                  uuid PRIMARY KEY,
    execution_id             uuid NOT NULL REFERENCES nex_ae.agent_execution(execution_id),
    checkpoint_id            uuid NOT NULL REFERENCES nex_ae.agent_checkpoint(checkpoint_id),
    condition_type           varchar(64) NOT NULL,
    external_ref             varchar(256) NOT NULL,
    expected_event_name      varchar(128),
    state                    varchar(32) NOT NULL DEFAULT 'WAITING',
    satisfied_event_id       varchar(128),
    created_at               timestamptz NOT NULL DEFAULT now(),
    satisfied_at             timestamptz,
    UNIQUE(execution_id, checkpoint_id, condition_type, external_ref)
);

CREATE INDEX IF NOT EXISTS ix_execution_wait_lookup
    ON nex_ae.execution_wait(state, condition_type, external_ref);

CREATE TABLE IF NOT EXISTS nex_ae.plan_routing_decision (
    routing_decision_id      uuid PRIMARY KEY,
    execution_id             uuid NOT NULL REFERENCES nex_ae.agent_execution(execution_id),
    work_intent_id           uuid NOT NULL REFERENCES nex_ae.work_intent(intent_id),
    route_type               varchar(48) NOT NULL,
    decision_json            jsonb NOT NULL,
    created_at               timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_ae.plan_execution_record (
    plan_execution_record_id uuid PRIMARY KEY,
    execution_id             uuid NOT NULL REFERENCES nex_ae.agent_execution(execution_id),
    plan_template_id         varchar(160),
    plan_template_version    varchar(64),
    routing_decision_id      uuid REFERENCES nex_ae.plan_routing_decision(routing_decision_id),
    technical_outcome        varchar(48),
    business_outcome         varchar(48),
    replan_count             integer NOT NULL DEFAULT 0,
    human_correction_count   integer NOT NULL DEFAULT 0,
    clarification_count      integer NOT NULL DEFAULT 0,
    exception_codes          jsonb,
    evidence_refs            jsonb,
    started_at               timestamptz,
    completed_at             timestamptz,
    created_at               timestamptz NOT NULL DEFAULT now()
);
