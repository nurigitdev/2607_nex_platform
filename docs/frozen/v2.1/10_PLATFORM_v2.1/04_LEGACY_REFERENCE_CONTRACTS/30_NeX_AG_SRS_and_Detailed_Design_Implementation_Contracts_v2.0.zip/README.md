# NeX-AG v2.0 Implementation Contracts

Reference-only implementation contracts for Governance/Operations Plane. Owning service source-of-truth data and internal logic are not copied into NeX-AG.

Core invariant: AG governs/observes through OA-authorized typed contracts; OA and owning services enforce runtime state.
