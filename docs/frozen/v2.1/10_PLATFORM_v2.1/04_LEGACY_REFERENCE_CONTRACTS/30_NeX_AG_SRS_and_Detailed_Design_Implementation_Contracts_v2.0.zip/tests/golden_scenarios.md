1. Policy exact hash/version distribution and ACK
2. Partial policy distribution visible and retryable
3. Emergency capability kill propagation
4. Plan certification human governance boundary
5. Plan degradation revalidation
6. Skill exact evidence certification
7. Revoked signing key blocks runtime
8. Prompt exact version activation
9. Stale worker does not imply business replay
10. Unknown control state reconciled, no blind duplicate
11. Reconciliation backlog separate from failed jobs
12. AG outage keeps last validated runtime policy