def dispatch_control(request, authz, client):
    decision=authz.authorize_admin(request["action_type"],request["target_ref"],request)
    if not decision.get("allowed"):
        return {"state":"REJECTED","reason":"POLICY_DENIED"}
    return client.control(request)
