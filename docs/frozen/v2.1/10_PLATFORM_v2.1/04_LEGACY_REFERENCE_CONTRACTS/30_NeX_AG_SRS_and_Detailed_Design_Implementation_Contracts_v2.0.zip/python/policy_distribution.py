def distribute(snapshot, targets):
    results=[]
    for name,client in targets.items():
        try:
            ack=client.apply_policy_snapshot(snapshot)
            results.append({"target":name,"state":"ACK","ack":ack})
        except Exception as exc:
            results.append({"target":name,"state":"FAILED","error":type(exc).__name__})
    return results
