def evaluate(rule, metric):
    # deterministic example only; production rules are versioned typed predicates
    op=rule["op"]; threshold=rule["threshold"]; value=metric["value"]
    if op==">": return value > threshold
    if op==">=": return value >= threshold
    if op=="==": return value == threshold
    raise ValueError("unsupported op")
