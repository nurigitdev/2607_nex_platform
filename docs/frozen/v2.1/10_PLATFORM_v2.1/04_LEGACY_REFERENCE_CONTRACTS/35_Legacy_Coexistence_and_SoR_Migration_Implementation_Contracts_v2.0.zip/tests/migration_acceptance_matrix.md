# Migration Acceptance Matrix

- SoR overlap/gap -> write blocked
- READ_SYNC lag/failure visible
- ambiguous mapping -> no canonical ID
- dual-run mismatch -> reconciliation issue
- cutover with critical mismatch -> blocked
- legacy write after read-only -> denied
- unknown commit -> reconcile, never blind retry
- Jira/WAMS new work after cutover -> WC only
- Groupware in-flight approval stays legacy; new submission -> target
- Golden A/B pass on target-authoritative path
