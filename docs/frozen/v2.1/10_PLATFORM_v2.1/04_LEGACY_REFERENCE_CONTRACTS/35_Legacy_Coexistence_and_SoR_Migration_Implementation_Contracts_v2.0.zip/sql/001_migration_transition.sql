CREATE TABLE domain_transition (
 transition_id uuid PRIMARY KEY, domain text NOT NULL, scope_ref text, state text NOT NULL, primary_write_system text NOT NULL, read_targets jsonb NOT NULL DEFAULT '[]', effective_from timestamptz NOT NULL, effective_to timestamptz, policy_version text NOT NULL, rollback_window_until timestamptz, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE legacy_mapping (
 mapping_id uuid PRIMARY KEY, source_system text NOT NULL, source_key text NOT NULL, target_type text NOT NULL, target_id text, mapping_status text NOT NULL, mapping_rule_version text, source_hash text, reviewer_ref text, created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(source_system, source_key, target_type, mapping_rule_version));
CREATE TABLE migration_batch (
 batch_id uuid PRIMARY KEY, domain text NOT NULL, source_system text NOT NULL, scope_ref text, status text NOT NULL, source_watermark jsonb, record_count bigint, success_count bigint, error_count bigint, started_at timestamptz, completed_at timestamptz);
CREATE TABLE reconciliation_issue (
 issue_id uuid PRIMARY KEY, domain text NOT NULL, scope_ref text, level text NOT NULL, source_ref text, target_ref text, status text NOT NULL, severity text NOT NULL, expected jsonb, actual jsonb, owner_ref text, created_at timestamptz NOT NULL DEFAULT now(), resolved_at timestamptz);