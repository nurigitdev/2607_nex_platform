# Domain Cutover Runbook

1. Confirm approved CutoverDecision and exact scope.
2. Confirm verified backup / Recovery Point Manifest.
3. Freeze or delta-sync per policy.
4. Final mapping + L1-L6 reconciliation.
5. Activate exact transition/routing policy.
6. Disable Legacy write.
7. Smoke + Golden-safe validation.
8. Monitor mismatch, write attempts, unknown commit.
9. Enter rollback window.
