# Rollback / Forward-fix Runbook

Rollback SoR only if target-created delta can be reconciled/exported and no unresolved unknown commit exists. Otherwise prefer forward-fix. Application rollback never implies business transaction rollback.
