# 35 Legacy Coexistence & SoR Migration Reference Package

Reference contracts for state/scope routing, mapping, reconciliation, cutover and rollback. This package does not replace repository-specific migration plans; actual KEEP/REFACTOR/REPLACE disposition requires source/runtime evidence per Document 10.
