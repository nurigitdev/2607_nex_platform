from dataclasses import dataclass
from enum import Enum

class State(str, Enum):
    LEGACY='LEGACY'; READ_SYNC='READ_SYNC'; DUAL='DUAL_RUN_VALIDATION'; NEW='NEW_SYSTEM'; RO='LEGACY_READ_ONLY'; ARCH='ARCHIVED'

@dataclass(frozen=True)
class RoutingDecision:
    read_targets: tuple[str, ...]
    write_target: str | None
    policy_version: str

def route(state: State, legacy: str, target: str) -> RoutingDecision:
    if state == State.LEGACY:
        return RoutingDecision((legacy,), legacy, 'example')
    if state == State.READ_SYNC:
        return RoutingDecision((target, legacy), legacy, 'example')
    if state == State.DUAL:
        # one writer; example keeps legacy authoritative until cutover
        return RoutingDecision((legacy, target), legacy, 'example')
    if state == State.NEW:
        return RoutingDecision((target,), target, 'example')
    if state in (State.RO, State.ARCH):
        return RoutingDecision((target, legacy), target, 'example')
    raise ValueError('WRITE_TARGET_AMBIGUOUS')
