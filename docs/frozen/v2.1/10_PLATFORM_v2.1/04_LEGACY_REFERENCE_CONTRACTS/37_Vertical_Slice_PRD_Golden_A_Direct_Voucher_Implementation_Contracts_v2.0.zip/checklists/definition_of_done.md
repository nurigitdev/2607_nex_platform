# PRD 37 Definition of Done

- [ ] Golden A happy path works with CX disabled
- [ ] Stable project/account/actor resolution is deterministic
- [ ] Current OA authorization before side effect
- [ ] Structured Confirmation proof is payload-bound
- [ ] Exact Certified Skill Version pinned
- [ ] NSL strict preflight + one controlled write
- [ ] Canonical API only; no cross-service DB write
- [ ] COMMITTED/NOT_COMMITTED/UNKNOWN explicit
- [ ] UNKNOWN → RECONCILIATION_REQUIRED, zero blind retry
- [ ] Authoritative voucher_ref verified
- [ ] Ledger/P&L state shown separately if async
- [ ] Mandatory fault/security suite passes
- [ ] 95/85 target + no coverage regression
- [ ] E2E trace reconstructed
- [ ] RC smoke/rollback readiness
- [ ] Acceptance Evidence Package + baseline tag
