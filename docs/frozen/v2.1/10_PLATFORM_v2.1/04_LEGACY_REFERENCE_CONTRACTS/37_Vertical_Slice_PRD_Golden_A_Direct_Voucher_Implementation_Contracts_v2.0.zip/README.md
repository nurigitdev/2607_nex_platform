# 37 Golden A Direct Voucher - Reference Package

Reference-only contracts, fixtures and acceptance skeletons. Physical repository paths, endpoint names, DB migrations and production skill version remain intentionally unresolved until INC-0 Repository Evidence Gate is completed.
