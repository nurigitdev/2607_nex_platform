# AE ↔ NSL Boundary for PRD 37

AE owns WorkIntent, Direct Routing, Plan Validation/Compile, Human Confirmation, current-authority orchestration and Result mapping.
NSL owns exact Certified Skill preflight and deterministic atomic execution.

Required request fields:
- execution_id / plan_step_id
- exact skill_id + skill_version
- actor / role / org / project authority refs
- typed voucher inputs
- confirmation_proof_ref
- stable idempotency_key
- correlation / causation refs

Forbidden:
- arbitrary .nsl source from LLM
- latest skill resolution after compile
- browser token as long-lived background authority
- direct Enterprise OS DB write
