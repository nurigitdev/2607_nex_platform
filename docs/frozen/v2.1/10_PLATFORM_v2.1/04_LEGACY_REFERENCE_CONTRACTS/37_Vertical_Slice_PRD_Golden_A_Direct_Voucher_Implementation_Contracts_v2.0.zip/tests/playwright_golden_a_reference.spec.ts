// Reference-only. Bind selectors/routes after AE-WEB repository evidence.
test("Golden A direct voucher", async ({ page }) => {
  await page.goto("/workspace");
  await page.getByRole("textbox").fill("A 프로젝트 출장비 84,000원을 전표로 등록해줘.");
  await page.getByRole("button", { name: /전송|요청/ }).click();
  await expect(page.getByText(/A 프로젝트/)).toBeVisible();
  await expect(page.getByText(/84,000/)).toBeVisible();
  await page.getByRole("button", { name: /확인|실행/ }).click();
  await expect(page.getByText(/전표.*등록|voucher/i)).toBeVisible();
});
