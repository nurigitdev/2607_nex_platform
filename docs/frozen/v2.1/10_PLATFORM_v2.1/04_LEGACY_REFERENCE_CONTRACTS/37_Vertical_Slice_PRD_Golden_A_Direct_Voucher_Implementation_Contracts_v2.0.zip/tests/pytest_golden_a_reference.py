"""Reference-only Golden A test skeleton; bind to actual adapters after Repository Evidence Gate."""

def test_happy_path_cx_disabled(golden_a_client):
    result = golden_a_client.run(cx_enabled=False)
    assert result.commit_state == "COMMITTED"
    assert result.voucher_ref
    assert result.amount == 84000

def test_unknown_commit_never_blind_retries(golden_a_client):
    result = golden_a_client.run(inject_fault="timeout_after_provider_commit")
    assert result.execution_state == "RECONCILIATION_REQUIRED"
    assert result.automatic_write_retry_count == 0

def test_confirmation_reject_has_zero_write_calls(golden_a_client):
    result = golden_a_client.run(confirm=False)
    assert result.provider_write_call_count == 0
