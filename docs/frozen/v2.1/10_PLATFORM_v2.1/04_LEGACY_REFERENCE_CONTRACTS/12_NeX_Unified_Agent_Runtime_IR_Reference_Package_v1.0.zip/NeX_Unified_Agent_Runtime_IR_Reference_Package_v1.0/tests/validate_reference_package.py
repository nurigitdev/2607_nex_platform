from pathlib import Path
import json
from referencing import Registry, Resource
from jsonschema import Draft202012Validator
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "validators"))
from semantic_validator_reference import validate_agent_plan_semantics

def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

work_schema = load(ROOT/"schemas/work-intent-v1.schema.json")
step_schema = load(ROOT/"schemas/plan-step-v1.schema.json")
plan_schema = load(ROOT/"schemas/agent-plan-v1.schema.json")

registry = Registry().with_resources([
    (step_schema["$id"], Resource.from_contents(step_schema)),
    ("plan-step-v1.schema.json", Resource.from_contents(step_schema)),
])

Draft202012Validator(work_schema).validate(load(ROOT/"examples/work-intent-accounting-voucher.json"))
validator = Draft202012Validator(plan_schema, registry=registry)
validator.validate(load(ROOT/"examples/agent-plan-direct-voucher.json"))
validator.validate(load(ROOT/"examples/agent-plan-delegation-resume.json"))

# additionalProperties:false must reject actual_assignee_id
bad = load(ROOT/"examples/invalid-agent-plan-forbidden-assignee.json")
assert list(validator.iter_errors(bad)), "forbidden assignee example must fail schema"

# Cycle is schema-valid but semantic-invalid
cycle = load(ROOT/"examples/invalid-agent-plan-cycle.json")
validator.validate(cycle)
issues = validate_agent_plan_semantics(cycle)
assert any(i.code == "VAL-004" for i in issues), issues

valid_issues = validate_agent_plan_semantics(load(ROOT/"examples/agent-plan-delegation-resume.json"))
assert not valid_issues, valid_issues

print("Reference package validation: PASS")
