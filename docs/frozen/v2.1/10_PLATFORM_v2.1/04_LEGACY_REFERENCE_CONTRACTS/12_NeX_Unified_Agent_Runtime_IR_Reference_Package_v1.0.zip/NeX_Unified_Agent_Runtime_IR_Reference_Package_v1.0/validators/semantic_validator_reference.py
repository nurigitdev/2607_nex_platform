"""
Reference semantic validator for NeX AgentPlan v1.

This is not the production validator. It demonstrates rules that JSON Schema
cannot fully express: step-id uniqueness, dependency existence, DAG acyclicity,
source-step reachability, bounded step count, forbidden logical bindings, etc.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any

ALLOWED_LOGICAL_TYPES = {"LOCAL_CAPABILITY", "DELEGATE_WORK", "AGGREGATE", "REPORT"}
FORBIDDEN_KEYS = {
    "actual_assignee_id", "approval_result", "secret", "raw_credential",
    "raw_http", "raw_sql", "script", "code"
}

@dataclass(frozen=True)
class ValidationIssue:
    code: str
    message: str

def _walk_keys(obj: Any):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield k
            yield from _walk_keys(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _walk_keys(v)

def validate_agent_plan_semantics(plan: dict, max_plan_steps: int = 12) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    steps = plan.get("steps", [])
    if len(steps) > max_plan_steps:
        issues.append(ValidationIssue("VAL-002", f"step_count={len(steps)} > {max_plan_steps}"))

    ids = [s.get("step_id") for s in steps]
    if len(ids) != len(set(ids)):
        issues.append(ValidationIssue("VAL-003", "duplicate step_id"))
    idset = set(ids)

    for step in steps:
        sid = step.get("step_id")
        stype = step.get("step_type")
        if stype not in ALLOWED_LOGICAL_TYPES:
            issues.append(ValidationIssue("VAL-005", f"{sid}: disallowed step_type={stype}"))
        for dep in step.get("depends_on", []):
            if dep not in idset:
                issues.append(ValidationIssue("VAL-003", f"{sid}: missing dependency={dep}"))

    # DAG cycle detection
    graph = {s["step_id"]: list(s.get("depends_on", [])) for s in steps if s.get("step_id")}
    visiting, visited = set(), set()
    def dfs(node: str):
        if node in visiting:
            return True
        if node in visited:
            return False
        visiting.add(node)
        for dep in graph.get(node, []):
            if dep in graph and dfs(dep):
                return True
        visiting.remove(node)
        visited.add(node)
        return False
    if any(dfs(n) for n in list(graph)):
        issues.append(ValidationIssue("VAL-004", "dependency graph contains a cycle"))

    # Forbidden bindings/authority
    keys = set(_walk_keys(plan))
    forbidden = sorted(keys & FORBIDDEN_KEYS)
    if forbidden:
        issues.append(ValidationIssue("VAL-008", f"forbidden logical fields: {forbidden}"))

    # Step-specific semantic checks
    position = {sid: i for i, sid in enumerate(ids)}
    for step in steps:
        sid = step.get("step_id")
        stype = step.get("step_type")
        if stype in {"LOCAL_CAPABILITY", "DELEGATE_WORK"} and not step.get("required_capability"):
            issues.append(ValidationIssue("VAL-006", f"{sid}: required_capability missing"))
        if stype == "DELEGATE_WORK":
            if not step.get("delegated_work_contract") or not step.get("result_contract"):
                issues.append(ValidationIssue("VAL-010", f"{sid}: delegation contract incomplete"))
        if stype in {"AGGREGATE", "REPORT"}:
            refs = step.get("source_step_refs", [])
            if not refs:
                issues.append(ValidationIssue("VAL-011" if stype=="AGGREGATE" else "VAL-012",
                                              f"{sid}: source_step_refs empty"))
            for ref in refs:
                if ref not in idset:
                    issues.append(ValidationIssue("VAL-009", f"{sid}: source ref {ref} missing"))
                elif position[ref] >= position[sid]:
                    issues.append(ValidationIssue("VAL-009", f"{sid}: source ref {ref} is not earlier"))
        # STEP_OUTPUT references must point to existing earlier steps.
        for b in (step.get("input_bindings") or {}).values():
            if isinstance(b, dict) and b.get("source") == "STEP_OUTPUT":
                ref = b.get("step_id")
                if ref not in idset:
                    issues.append(ValidationIssue("VAL-009", f"{sid}: STEP_OUTPUT ref {ref} missing"))
                elif position[ref] >= position[sid]:
                    issues.append(ValidationIssue("VAL-009", f"{sid}: STEP_OUTPUT ref {ref} is not earlier"))

    if not plan.get("completion_criteria"):
        issues.append(ValidationIssue("VAL-013", "completion_criteria empty"))

    return issues
