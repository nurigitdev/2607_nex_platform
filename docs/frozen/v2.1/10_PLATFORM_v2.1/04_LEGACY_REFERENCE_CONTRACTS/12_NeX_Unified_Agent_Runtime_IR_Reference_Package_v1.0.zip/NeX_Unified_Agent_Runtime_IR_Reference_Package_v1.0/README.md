# NeX Unified Agent Runtime IR Reference Package v1.0

## Purpose

This package fills the machine-readable gap around:

- `WorkIntent v1`
- `AgentPlan v1`
- `PlanStep v1`

and complements the already-defined `ExecutablePlan v1` contract.

The architectural boundary remains:

`LLM candidate → WorkIntent → AgentPlan(JSON Logical IR) → Schema/Semantic Validation → deterministic Compiler → ExecutablePlan → Step Executor`.

## Source-derived invariants

The package preserves these frozen design rules:

1. WorkIntent expresses `goal / work_class / capability hints / entity selectors / parameter candidates / completion criteria / clarification state`.
2. LLM may propose selectors/candidates but must not create authoritative Employee/Project/Account/Vendor stable IDs.
3. AgentPlan is JSON Logical IR, not natural language and not NSL.
4. Logical PlanStep v1 allows only:
   - `LOCAL_CAPABILITY`
   - `DELEGATE_WORK`
   - `AGGREGATE`
   - `REPORT`
5. Logical plan must not contain actual assignee, approval result, secret/raw credential, raw HTTP/SQL/script/code.
6. Planner may express `required_capability` but must not pin a concrete Certified Skill version.
7. DELEGATE_WORK expresses required capability + delegated work/result contract; WC decides actual assignee.
8. AGGREGATE identifies source step/result refs and an explicit aggregation mode.
9. REPORT expresses Interactive Response / Work Result / Artifact result contracts.
10. Semantic validation enforces step IDs, dependency existence, DAG, max steps, capability validity, I/O compatibility, delegation rules and completion criteria.
11. Compiler—not Planner—resolves Stable IDs, exact Capability/Skill version, Human Gates, WC routing, idempotency/commit policy.

## Package-level concretization decisions

The frozen documents define the semantic obligations above, but they do not fully specify every JSON field name, enum spelling, or nested object shape for WorkIntent v1 / AgentPlan v1 / PlanStep v1.

Therefore this package makes **concretization decisions** needed for a machine-readable baseline. They are designed to remain compatible with the frozen semantics and should be versioned if later Repository Evidence or implementation code establishes a different exact contract.

Notable concretizations:
- `clarification_state.status`: `NOT_REQUIRED | REQUIRED | RESOLVED`
- `plan_kind`: `DIRECT | CERTIFIED_BINDING | KNOWN_TEMPLATE | DYNAMIC`
- input binding sources: `WORK_INTENT_PARAMETER | ENTITY_SELECTOR | STEP_OUTPUT | LITERAL`
- aggregation mode: `DETERMINISTIC | STRUCTURED | LLM_SYNTHESIS`
- report kind: `INTERACTIVE_RESPONSE | WORK_RESULT | ARTIFACT`

## Files

### schemas/
- `work-intent-v1.schema.json`
- `plan-step-v1.schema.json`
- `agent-plan-v1.schema.json`

### examples/
- `work-intent-accounting-voucher.json`
- `agent-plan-direct-voucher.json`
- `agent-plan-delegation-resume.json`
- `invalid-agent-plan-forbidden-assignee.json`
- `invalid-agent-plan-cycle.json`

### validators/
- `semantic_validator_reference.py`

### tests/
- `validate_reference_package.py`

## Important separation

`AgentPlan v1` is a **logical** plan. It must not contain:
- exact Certified Skill version
- actual Coworker assignee
- formal approval result
- current permission token
- raw secret/credential
- canonical business commit

These belong to deterministic compile/runtime boundaries.

## Validation

The package should pass:
1. Draft 2020-12 JSON Schema validation for positive examples.
2. Schema rejection of forbidden logical fields.
3. Semantic cycle detection for the cycle example.
4. Zero semantic issues for valid delegation example.
