# PRD42 Golden Operations Scenarios

1. Worker heartbeat expires; stale-worker alert opens; no duplicate business effect after reclaim.
2. Controlled write returns UNKNOWN_COMMIT_STATE; blind retry count remains zero.
3. Scoped Kill Switch blocks new/resume/R3+ protected writes.
4. CONFIRMED_COMMITTED restores result without rewrite.
5. CONFIRMED_NOT_COMMITTED permits retry only after kill release and current OA authorization.
6. Partial control acknowledgement remains UNKNOWN_CONTROL_STATE until target reconciliation.
7. STILL_UNKNOWN keeps the incident open and escalated.
8. AG restart rebuilds projections without modifying owner SoR.
9. Incident resolve requires recovery evidence package and no critical blockers.
10. Unauthorized operator cannot issue control actions.
