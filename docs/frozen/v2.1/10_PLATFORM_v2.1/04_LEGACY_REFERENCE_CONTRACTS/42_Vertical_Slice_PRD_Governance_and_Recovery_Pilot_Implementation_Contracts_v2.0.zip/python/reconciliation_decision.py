from enum import Enum

class Result(Enum):
    CONFIRMED_COMMITTED = "CONFIRMED_COMMITTED"
    CONFIRMED_NOT_COMMITTED = "CONFIRMED_NOT_COMMITTED"
    STILL_UNKNOWN = "STILL_UNKNOWN"
    CONFLICT = "CONFLICT"

def next_action(result: Result, *, kill_active: bool, current_authorized: bool, retry_allowed: bool):
    if result is Result.CONFIRMED_COMMITTED:
        return "RESTORE_RESULT_NO_WRITE"
    if result is Result.CONFIRMED_NOT_COMMITTED:
        return "SAFE_RETRY" if retry_allowed and current_authorized and not kill_active else "BLOCK"
    if result is Result.STILL_UNKNOWN:
        return "ESCALATE_NO_RETRY"
    return "PRESERVE_EVIDENCE_AND_ESCALATE"
