from __future__ import annotations

class FinancialLineageService:
    def __init__(self, lineage, hierarchy):
        self.lineage=lineage; self.hierarchy=hierarchy

    async def get_entry_lineage(self, ledger_entry_id:str):
        record=await self.lineage.find_by_entry(ledger_entry_id)
        if not record:
            raise KeyError("LEDGER_ENTRY_LINEAGE_NOT_FOUND")
        return record
