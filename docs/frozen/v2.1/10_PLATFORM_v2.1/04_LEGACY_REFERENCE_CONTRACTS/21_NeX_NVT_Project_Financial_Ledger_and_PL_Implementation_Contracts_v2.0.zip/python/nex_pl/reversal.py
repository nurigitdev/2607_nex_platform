from __future__ import annotations
from typing import Any, Mapping

OPPOSITE={"DEBIT":"CREDIT","CREDIT":"DEBIT"}

class LedgerReversalService:
    def __init__(self, ledger, periods, pdp, gate_verifier, id_generator, outbox):
        self.ledger=ledger; self.periods=periods; self.pdp=pdp
        self.gate_verifier=gate_verifier; self.id_generator=id_generator; self.outbox=outbox

    async def reverse(self, request:Mapping[str,Any], *, context:Mapping[str,Any]) -> Mapping[str,Any]:
        original_id=request["original_posting_ref"]["entity_id"]
        prior=await self.ledger.find_reversal(original_id)
        if prior:
            if prior.get("idempotency_key")==request["idempotency_key"]:
                return prior
            raise ValueError("POSTING_ALREADY_REVERSED")

        posting=await self.ledger.get_posting(original_id)
        entries=await self.ledger.get_entries(original_id)
        period=await self.periods.get_for_date(request["posting_date"])
        if period["status"]!="OPEN":
            raise ValueError("REVERSAL_PERIOD_NOT_OPEN")

        auth=await self.pdp.authorize("LEDGER.REVERSE_POSTING",context,[request["original_posting_ref"]])
        if not auth.get("allowed",False):
            raise PermissionError("REVERSAL_DENIED")
        if request.get("human_gate_proof_ref"):
            await self.gate_verifier.verify(
                request["human_gate_proof_ref"], request,
                {"capability_id":"LEDGER.REVERSE_POSTING","operation_key":"REVERSE_POSTING"}, context
            )

        reversal_posting_id=self.id_generator.new_id()
        reversed_entries=[]
        for e in entries:
            reversed_entries.append({
                **e,
                "ledger_entry_id":self.id_generator.new_id(),
                "posting_id":reversal_posting_id,
                "side":OPPOSITE[e["side"]],
                "posting_date":request["posting_date"],
                "period_ref":{"entity_type":"FISCAL_PERIOD","entity_id":period["period_id"]},
                "reversal_of_entry_ref":{"entity_type":"LEDGER_ENTRY","entity_id":e["ledger_entry_id"]},
                "created_at":context["now"],
            })
        result=await self.ledger.append_posting({
            "posting_id":reversal_posting_id,
            "source_transaction_ref":request["original_posting_ref"],
            "posting_date":request["posting_date"],
            "period_ref":{"entity_type":"FISCAL_PERIOD","entity_id":period["period_id"]},
            "currency":posting["currency"],
            "idempotency_key":request["idempotency_key"],
            "reversal_of_posting_ref":request["original_posting_ref"],
        },reversed_entries)
        await self.outbox.append({"event_name":"LEDGER_ENTRY_REVERSED",
                                  "original_posting_id":original_id,
                                  "reversal_posting_id":reversal_posting_id,
                                  "correlation_id":context["correlation_id"]})
        return result
