from __future__ import annotations
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any, Mapping
from pydantic import BaseModel, ConfigDict

class EntrySide(StrEnum):
    DEBIT="DEBIT"; CREDIT="CREDIT"

class Category(StrEnum):
    REVENUE="REVENUE"; LABOR="LABOR"; MATERIAL="MATERIAL"
    DIRECT_EXPENSE="DIRECT_EXPENSE"; COMMON_COST="COMMON_COST"; ADJUSTMENT="ADJUSTMENT"

COST_CATEGORIES={Category.LABOR,Category.MATERIAL,Category.DIRECT_EXPENSE,Category.COMMON_COST}

class Money(BaseModel):
    model_config=ConfigDict(extra="forbid",frozen=True)
    amount: Decimal
    currency: str

class EntityRef(BaseModel):
    model_config=ConfigDict(extra="forbid",frozen=True)
    entity_type: str
    entity_id: str
    version: str|int|None=None
    status: str|None=None

class PLAmounts(BaseModel):
    model_config=ConfigDict(extra="forbid")
    revenue: Decimal=Decimal("0")
    labor: Decimal=Decimal("0")
    material: Decimal=Decimal("0")
    direct_expense: Decimal=Decimal("0")
    common_cost: Decimal=Decimal("0")
    adjustment_profit_effect: Decimal=Decimal("0")

    @property
    def profit(self)->Decimal:
        return (self.revenue-self.labor-self.material-self.direct_expense
                -self.common_cost+self.adjustment_profit_effect)
