from __future__ import annotations
from decimal import Decimal
from typing import Any, Mapping

class ProjectAttributionService:
    """Deterministic inheritance first; model candidates are never final authority."""

    def __init__(self, work_gateway, workspace_gateway, resolver, confirmations, projects, repository, policy):
        self.work_gateway=work_gateway
        self.workspace_gateway=workspace_gateway
        self.resolver=resolver
        self.confirmations=confirmations
        self.projects=projects
        self.repository=repository
        self.policy=policy

    async def resolve_single(self, *, context:Mapping[str,Any], selectors:Mapping[str,Any]) -> Mapping[str,Any]:
        # 1. WorkItem project
        if context.get("work_item_id"):
            p=await self.work_gateway.get_work_item_project(context["work_item_id"])
            if p:
                return await self._save("WORKITEM",context["work_item_id"],p,"DETERMINISTIC_INHERITANCE",context)

        # 2. Explicit transaction/project context
        if context.get("transaction_project_ref"):
            return await self._save("BUSINESS_TRANSACTION",context["transaction_ref"],
                                    context["transaction_project_ref"],"DETERMINISTIC_INHERITANCE",context)

        # 3. Workspace current project
        p=await self.workspace_gateway.get_current_project(context["business_actor_ref"])
        if p:
            return await self._save("WORKSPACE",context["business_actor_ref"],p,"DETERMINISTIC_INHERITANCE",context)

        # 4. Parent work inheritance
        if context.get("work_item_id"):
            p=await self.work_gateway.get_parent_work_project(context["work_item_id"])
            if p:
                return await self._save("PARENT_WORK",context["work_item_id"],p,"DETERMINISTIC_INHERITANCE",context)

        # 5. Canonical candidate resolution + human confirmation if ambiguous
        candidates=await self.resolver.resolve_candidates(selectors,limit=self.policy.max_candidates)
        if len(candidates)==1 and candidates[0].get("exact",False):
            return await self._save("AGENT_CANDIDATE",context.get("transaction_ref","UNKNOWN"),
                                    candidates[0]["project_ref"],"CANONICAL_RESOLUTION",context)

        if candidates:
            confirmation=await self.confirmations.request_project_confirmation(
                {"candidates":candidates,"source_context":dict(context)},
                idempotency_key=f"project-attribution:{context.get('correlation_id')}:{context.get('transaction_ref','new')}"
            )
            return {"status":"CONFIRMATION_REQUIRED","confirmation_ref":confirmation["confirmation_ref"],
                    "candidates":candidates}

        # 6. Do NOT silently select Common Work.
        return {"status":"UNRESOLVED","reason":"NO_PROJECT_CONTEXT_OR_CANDIDATE"}

    async def _save(self, source_type, source_ref, project_ref, decision_source, context):
        project=await self.projects.get_project(project_ref["entity_id"])
        if project["status"]!="ACTIVE" or project["project_type"]=="NVT":
            raise ValueError("PROJECT_NOT_ELIGIBLE_FOR_DIRECT_ATTRIBUTION")
        decision={
            "source_type":source_type,"source_ref":source_ref,
            "decision_type":"SINGLE_PROJECT","selected_projects":[{"project_ref":project_ref}],
            "decision_source":decision_source,"status":"RESOLVED",
            "trace":{"correlation_id":context["correlation_id"],
                     "work_item_id":context.get("work_item_id"),
                     "agent_execution_id":context.get("agent_execution_id")}
        }
        return await self.repository.save_decision(decision)
