from __future__ import annotations
from decimal import Decimal
from typing import Any, Mapping, Sequence
from .sign_rules import accumulate

class ProjectPLProjectionService:
    def __init__(self, hierarchy, ledger, projection, clock):
        self.hierarchy=hierarchy; self.ledger=ledger; self.projection=projection; self.clock=clock

    async def rebuild_period(self, *, period_ref:Mapping[str,Any], currency:str) -> None:
        # Reference rebuild algorithm. Production implementation can use SQL aggregation/materialized view.
        direct_entries=await self.ledger.list_entries({
            "period_ref":period_ref, "currency":currency
        })
        by_project={}
        for e in direct_entries:
            by_project.setdefault(e["project_ref"]["entity_id"],[]).append(e)

        for project_id,entries in by_project.items():
            direct=accumulate(entries)
            await self.projection.upsert_period_bucket(
                self._bucket(project_id,period_ref,currency,"DIRECT",direct,len(entries))
            )

        # Roll up descendant entries through the hierarchy closure.
        all_projects=await self.hierarchy.descendants("__ALL__")  # implementation-specific read model
        for p in all_projects:
            descendants=await self.hierarchy.descendants(p["project_id"])
            ids={p["project_id"],*(d["project_id"] for d in descendants)}
            entries=[e for e in direct_entries if e["project_ref"]["entity_id"] in ids]
            rolled=accumulate(entries)
            await self.projection.upsert_period_bucket(
                self._bucket(p["project_id"],period_ref,currency,"ROLLUP",rolled,len(entries))
            )

    def _bucket(self,project_id,period_ref,currency,scope,amounts,count):
        return {
            "project_ref":{"entity_type":"PROJECT","entity_id":project_id},
            "period_ref":period_ref,
            "view_scope":scope,
            "currency":currency,
            "revenue":{"amount":str(amounts.revenue),"currency":currency},
            "labor":{"amount":str(amounts.labor),"currency":currency},
            "material":{"amount":str(amounts.material),"currency":currency},
            "direct_expense":{"amount":str(amounts.direct_expense),"currency":currency},
            "common_cost":{"amount":str(amounts.common_cost),"currency":currency},
            "adjustment_profit_effect":{"amount":str(amounts.adjustment_profit_effect),"currency":currency},
            "profit":{"amount":str(amounts.profit),"currency":currency},
            "entry_count":count,
            "source_ledger_version":"rebuild",
            "refreshed_at":self.clock.now().isoformat(),
        }

    async def query_cumulative(self, query:Mapping[str,Any]) -> Mapping[str,Any]:
        buckets=await self.projection.query_period_buckets(query)
        fields=["revenue","labor","material","direct_expense","common_cost","adjustment_profit_effect","profit"]
        out={f:Decimal("0") for f in fields}
        for b in buckets:
            for f in fields:
                out[f]+=Decimal(b[f]["amount"])
        return {f:{"amount":str(v),"currency":query["currency"]} for f,v in out.items()}
