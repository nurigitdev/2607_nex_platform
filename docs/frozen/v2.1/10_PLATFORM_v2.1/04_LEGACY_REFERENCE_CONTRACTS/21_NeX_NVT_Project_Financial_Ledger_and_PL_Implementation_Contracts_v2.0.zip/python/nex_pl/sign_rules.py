from __future__ import annotations
from decimal import Decimal
from typing import Any, Mapping
from .models import Category, EntrySide, PLAmounts, COST_CATEGORIES

def _amount(entry:Mapping[str,Any])->Decimal:
    return Decimal(str(entry["amount"]["amount"]))

def category_net_amount(entry:Mapping[str,Any])->Decimal:
    """Returns the displayed net amount for a normal P/L category.
    REVENUE: credit - debit
    COST: debit - credit
    ADJUSTMENT: not valid here; use adjustment_profit_effect().
    """
    cat=Category(entry["category"])
    side=EntrySide(entry["side"])
    amount=_amount(entry)
    if cat==Category.REVENUE:
        return amount if side==EntrySide.CREDIT else -amount
    if cat in COST_CATEGORIES:
        return amount if side==EntrySide.DEBIT else -amount
    raise ValueError("ADJUSTMENT_REQUIRES_TARGET_CATEGORY")

def adjustment_profit_effect(entry:Mapping[str,Any])->Decimal:
    """Adjustment must declare dimensions.adjustment_target_category.
    Profit effect:
      target revenue: CREDIT +, DEBIT -
      target cost: CREDIT +, DEBIT -
    Note: both reduce to credit-positive/debit-negative for profit effect,
    but target category is still required for audit/reclassification semantics.
    """
    if Category(entry["category"])!=Category.ADJUSTMENT:
        raise ValueError("NOT_ADJUSTMENT")
    target=entry.get("dimensions",{}).get("adjustment_target_category")
    if target not in {c.value for c in Category if c!=Category.ADJUSTMENT}:
        raise ValueError("ADJUSTMENT_TARGET_CATEGORY_REQUIRED")
    side=EntrySide(entry["side"])
    amount=_amount(entry)
    return amount if side==EntrySide.CREDIT else -amount

def accumulate(entries:list[Mapping[str,Any]])->PLAmounts:
    out=PLAmounts()
    for e in entries:
        cat=Category(e["category"])
        if cat==Category.ADJUSTMENT:
            out.adjustment_profit_effect += adjustment_profit_effect(e)
            continue
        net=category_net_amount(e)
        if cat==Category.REVENUE: out.revenue += net
        elif cat==Category.LABOR: out.labor += net
        elif cat==Category.MATERIAL: out.material += net
        elif cat==Category.DIRECT_EXPENSE: out.direct_expense += net
        elif cat==Category.COMMON_COST: out.common_cost += net
    return out
