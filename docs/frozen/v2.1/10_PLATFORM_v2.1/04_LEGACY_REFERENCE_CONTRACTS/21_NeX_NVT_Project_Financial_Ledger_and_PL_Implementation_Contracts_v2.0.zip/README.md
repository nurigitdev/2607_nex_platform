# NeX NVT / Project Financial Ledger & P/L v2.0 Reference Package

Accompanies `21_NeX_NVT_Project_Financial_Ledger_and_PL_Design_v2.0`.

## Core decisions
1. Project attribution is deterministic inheritance/resolution first. LLM candidates never become final project IDs without canonical resolution/confirmation.
2. Common Work is explicit, not a null-project fallback.
3. Each atomic business transaction has one direct ProjectRef. Multi-project business requests are split before posting or represented by an explicit allocation source such as LaborAllocation.
4. LedgerPosting is atomic; LedgerEntry is immutable.
5. Full reversal creates a new posting with opposite Debit/Credit entries and links original posting/entries.
6. Partial/reclassification correction uses ADJUSTMENT posting, not partial mutation.
7. P/L sign rules:
   - REVENUE net = CREDIT - DEBIT
   - LABOR/MATERIAL/DIRECT_EXPENSE/COMMON_COST net = DEBIT - CREDIT
   - ADJUSTMENT is a signed profit effect; adjustment_target_category is mandatory for audit semantics. CREDIT increases profit, DEBIT decreases profit.
   - Profit = Revenue - Labor - Material - DirectExpense - CommonCost + AdjustmentProfitEffect
8. Roll-up uses project_hierarchy_closure: descendant facts aggregate to Mother/NVT ancestors.
9. Period P/L is a rebuildable read model. Cumulative is sum of period buckets, never a separate source of truth.
10. Evidence drill-down traces P/L → LedgerEntry → Posting → Source Transaction/Line → Work/Agent/Skill/Approval/Artifact/Evidence.

11. Project Financial Ledger is a management P/L subledger, not a full statutory/general-ledger mirror. Voucher balance remains in Voucher/VoucherLine; only P/L-relevant economic lines are projected to Project Financial Ledger. Balance-sheet offset lines with economic category NONE are excluded.
12. P/L projection uses a monotonic posting_seq watermark and recomputes affected buckets; projection tables remain rebuildable and never become financial SoR.

All 5 schemas/examples and Python modules are validated during artifact generation.
