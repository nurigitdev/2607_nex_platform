-- Financial lineage read model / index
CREATE TABLE IF NOT EXISTS nex_eos.financial_lineage_index (
    ledger_entry_id          uuid PRIMARY KEY REFERENCES nex_eos.ledger_entry(ledger_entry_id),
    posting_id               uuid NOT NULL REFERENCES nex_eos.ledger_posting(posting_id),
    direct_project_id        uuid NOT NULL REFERENCES nex_eos.project(project_id),
    project_path_json        jsonb NOT NULL,
    source_transaction_type  varchar(40) NOT NULL,
    source_transaction_id    varchar(160) NOT NULL,
    source_transaction_line_id varchar(160),
    work_item_ref            varchar(160),
    agent_execution_ref      varchar(160),
    skill_ref                varchar(256),
    approval_ref             varchar(256),
    artifact_refs_json       jsonb NOT NULL DEFAULT '[]'::jsonb,
    evidence_refs_json       jsonb NOT NULL DEFAULT '[]'::jsonb,
    correlation_id           varchar(128) NOT NULL,
    causation_id             varchar(128),
    refreshed_at             timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_lineage_source_tx
    ON nex_eos.financial_lineage_index(source_transaction_type,source_transaction_id);
CREATE INDEX IF NOT EXISTS ix_lineage_corr
    ON nex_eos.financial_lineage_index(correlation_id);

-- The lineage index is rebuildable. Authoritative lineage remains in LedgerEntry/Posting,
-- source transaction refs, project hierarchy and artifact/evidence refs.
