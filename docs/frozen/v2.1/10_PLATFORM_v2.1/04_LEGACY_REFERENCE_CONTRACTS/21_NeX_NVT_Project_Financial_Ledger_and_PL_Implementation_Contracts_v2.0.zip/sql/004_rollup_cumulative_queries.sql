-- Roll-up query via hierarchy closure
-- Direct Project bucket: entries exactly on project_id.
-- Roll-up bucket: entries from project and all descendants.

SELECT
    ph.ancestor_project_id AS project_id,
    le.period_id,
    le.currency,
    SUM(CASE WHEN le.category='REVENUE'
        THEN CASE WHEN le.side='CREDIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS revenue,
    SUM(CASE WHEN le.category='LABOR'
        THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS labor,
    SUM(CASE WHEN le.category='MATERIAL'
        THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS material,
    SUM(CASE WHEN le.category='DIRECT_EXPENSE'
        THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS direct_expense,
    SUM(CASE WHEN le.category='COMMON_COST'
        THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS common_cost,
    SUM(CASE WHEN le.category='ADJUSTMENT'
        THEN CASE WHEN le.side='CREDIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS adjustment_profit_effect
FROM nex_eos.project_hierarchy_closure ph
JOIN nex_eos.ledger_entry le
  ON le.project_id=ph.descendant_project_id
GROUP BY ph.ancestor_project_id,le.period_id,le.currency;

-- Cumulative view is SUM(project_pl_period) over an ordered period range.
-- It is not a new source of truth and can always be rebuilt from ledger facts.
