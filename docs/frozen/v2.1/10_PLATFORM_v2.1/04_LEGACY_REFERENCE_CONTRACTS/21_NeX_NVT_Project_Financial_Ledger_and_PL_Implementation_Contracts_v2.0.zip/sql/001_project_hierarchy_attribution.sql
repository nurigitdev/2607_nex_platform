-- Project hierarchy closure + attribution decisions
CREATE SCHEMA IF NOT EXISTS nex_eos;

CREATE TABLE IF NOT EXISTS nex_eos.project_hierarchy_closure (
    ancestor_project_id     uuid NOT NULL REFERENCES nex_eos.project(project_id),
    descendant_project_id   uuid NOT NULL REFERENCES nex_eos.project(project_id),
    depth                   integer NOT NULL,
    PRIMARY KEY(ancestor_project_id,descendant_project_id),
    CONSTRAINT ck_project_closure_depth CHECK (depth >= 0)
);
CREATE INDEX IF NOT EXISTS ix_project_closure_descendant
    ON nex_eos.project_hierarchy_closure(descendant_project_id,depth);

-- Self rows depth=0; NVT->Mother depth=1; NVT->Child depth=2; Mother->Child depth=1.
-- Rebuild/maintain in the same transaction as authorized hierarchy changes.

CREATE TABLE IF NOT EXISTS nex_eos.project_attribution_decision (
    attribution_id          uuid PRIMARY KEY,
    source_type             varchar(40) NOT NULL,
    source_ref              varchar(256) NOT NULL,
    decision_type           varchar(32) NOT NULL,
    decision_source         varchar(40) NOT NULL,
    status                  varchar(32) NOT NULL,
    selected_projects_json  jsonb NOT NULL,
    candidate_projects_json jsonb NOT NULL DEFAULT '[]'::jsonb,
    confirmation_proof_ref  varchar(256),
    policy_version          varchar(64),
    correlation_id          varchar(128) NOT NULL,
    causation_id            varchar(128),
    work_item_id            varchar(128),
    agent_execution_id      varchar(128),
    created_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_attribution_status CHECK (
      status IN ('RESOLVED','CONFIRMATION_REQUIRED','SPLIT_REQUIRED','COMMON_CONFIRMED','UNRESOLVED')
    )
);
CREATE INDEX IF NOT EXISTS ix_attribution_source
    ON nex_eos.project_attribution_decision(source_type,source_ref,created_at);
