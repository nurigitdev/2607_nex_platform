-- Projection watermark / incremental refresh control
ALTER TABLE nex_eos.ledger_posting
    ADD COLUMN IF NOT EXISTS posting_seq bigint GENERATED ALWAYS AS IDENTITY;

CREATE UNIQUE INDEX IF NOT EXISTS uq_ledger_posting_seq
    ON nex_eos.ledger_posting(posting_seq);

CREATE TABLE IF NOT EXISTS nex_eos.financial_projection_checkpoint (
    projection_name         varchar(160) PRIMARY KEY,
    last_posting_seq        bigint NOT NULL DEFAULT 0,
    updated_at              timestamptz NOT NULL DEFAULT now()
);

-- Projector algorithm:
-- 1) read committed postings with posting_seq > checkpoint;
-- 2) collect affected (direct_project_id, period_id, currency) and all ancestors;
-- 3) recompute those DIRECT/ROLLUP buckets from authoritative ledger facts;
-- 4) update project_pl_period with source_ledger_version='posting_seq:<max>';
-- 5) advance checkpoint only after all affected buckets commit.
-- This makes projection retryable/rebuildable and prevents double counting.
