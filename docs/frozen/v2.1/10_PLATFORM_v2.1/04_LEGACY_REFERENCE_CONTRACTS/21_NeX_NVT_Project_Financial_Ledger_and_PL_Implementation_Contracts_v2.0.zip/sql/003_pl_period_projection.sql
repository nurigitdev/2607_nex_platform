-- Project P/L period projection
CREATE TABLE IF NOT EXISTS nex_eos.project_pl_period (
    project_id               uuid NOT NULL REFERENCES nex_eos.project(project_id),
    period_id                uuid NOT NULL REFERENCES nex_eos.fiscal_period(period_id),
    view_scope               varchar(16) NOT NULL,
    currency                 char(3) NOT NULL,
    revenue                  numeric(38,12) NOT NULL DEFAULT 0,
    labor                    numeric(38,12) NOT NULL DEFAULT 0,
    material                 numeric(38,12) NOT NULL DEFAULT 0,
    direct_expense           numeric(38,12) NOT NULL DEFAULT 0,
    common_cost              numeric(38,12) NOT NULL DEFAULT 0,
    adjustment_profit_effect numeric(38,12) NOT NULL DEFAULT 0,
    profit                   numeric(38,12) NOT NULL DEFAULT 0,
    entry_count              bigint NOT NULL DEFAULT 0,
    source_ledger_version    varchar(128) NOT NULL,
    refreshed_at             timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY(project_id,period_id,view_scope,currency),
    CONSTRAINT ck_pl_scope CHECK (view_scope IN ('DIRECT','ROLLUP'))
);
CREATE INDEX IF NOT EXISTS ix_pl_period_scope
    ON nex_eos.project_pl_period(period_id,view_scope,project_id);

-- Deterministic direct-period aggregation reference.
-- ADJUSTMENT profit effect: CREDIT positive, DEBIT negative.
-- Other categories display as positive net category amounts according to their normal P/L polarity.
WITH entry_effect AS (
  SELECT
    le.project_id, le.period_id, le.currency,
    CASE WHEN le.category='REVENUE'
         THEN CASE WHEN le.side='CREDIT' THEN le.amount ELSE -le.amount END
         ELSE 0 END AS revenue,
    CASE WHEN le.category='LABOR'
         THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END
         ELSE 0 END AS labor,
    CASE WHEN le.category='MATERIAL'
         THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END
         ELSE 0 END AS material,
    CASE WHEN le.category='DIRECT_EXPENSE'
         THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END
         ELSE 0 END AS direct_expense,
    CASE WHEN le.category='COMMON_COST'
         THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END
         ELSE 0 END AS common_cost,
    CASE WHEN le.category='ADJUSTMENT'
         THEN CASE WHEN le.side='CREDIT' THEN le.amount ELSE -le.amount END
         ELSE 0 END AS adjustment_profit_effect
  FROM nex_eos.ledger_entry le
)
SELECT * FROM entry_effect;
