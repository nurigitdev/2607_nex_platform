-- Extend ledger posting/entry for reversal and adjustment semantics.

ALTER TABLE nex_eos.ledger_posting
    ADD COLUMN IF NOT EXISTS posting_kind varchar(24) NOT NULL DEFAULT 'NORMAL';

ALTER TABLE nex_eos.ledger_posting
    ADD COLUMN IF NOT EXISTS reversal_reason_code varchar(64);

ALTER TABLE nex_eos.ledger_posting
    ADD COLUMN IF NOT EXISTS reversal_reason text;

ALTER TABLE nex_eos.ledger_entry
    ADD COLUMN IF NOT EXISTS adjustment_target_category varchar(32);

ALTER TABLE nex_eos.ledger_posting
    ADD CONSTRAINT ck_ledger_posting_kind
    CHECK (posting_kind IN ('NORMAL','REVERSAL','ADJUSTMENT'));

-- One full reversal per original posting. Partial corrections use ADJUSTMENT posting.
CREATE UNIQUE INDEX IF NOT EXISTS uq_one_full_reversal_per_posting
    ON nex_eos.ledger_posting(reversal_of_posting_id)
    WHERE reversal_of_posting_id IS NOT NULL AND posting_kind='REVERSAL';

-- Profit/P&L rule:
-- REVENUE net = CREDIT - DEBIT
-- LABOR/MATERIAL/DIRECT_EXPENSE/COMMON_COST net = DEBIT - CREDIT
-- ADJUSTMENT requires adjustment_target_category and is converted to profit effect.
ALTER TABLE nex_eos.ledger_entry
    ADD CONSTRAINT ck_adjustment_target
    CHECK (
      (category <> 'ADJUSTMENT' AND adjustment_target_category IS NULL)
      OR
      (category = 'ADJUSTMENT' AND adjustment_target_category IN
       ('REVENUE','LABOR','MATERIAL','DIRECT_EXPENSE','COMMON_COST'))
    );
