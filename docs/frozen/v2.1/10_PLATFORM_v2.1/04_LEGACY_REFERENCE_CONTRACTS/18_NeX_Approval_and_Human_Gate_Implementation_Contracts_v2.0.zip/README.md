# NeX Approval & Human Gate v2.0 Reference Package

Accompanies `18_NeX_Approval_and_Human_Gate_Detailed_Design_v2.0`.

## Ownership
- Structured Confirmation: NeX-AE / Human Gate service.
- Formal Approval: Enterprise OS Approval Engine.
- Unified Agent Runtime: WAITING_CONFIRMATION / WAITING_APPROVAL, checkpoint/resume.
- NSL Runtime: fetch/validate HumanGateProof immediately before WRITE.

## Key rules
1. Confirmation is requester confirmation of a structured payload; it is not enterprise approval.
2. Formal approval is an append-only business governance decision by an authorized Human approver.
3. Both gate types freeze/write-bind `write_intent_hash` and `payload_hash`.
4. Payload/operation changes require a new gate; an old proof cannot authorize a changed write.
5. Pending requests can expire/cancel. Approved historical decisions are not erased; an approved instance may be INVALIDATED before execution if the protected payload/operation changes.
6. Later role changes do not retroactively rewrite historical approval evidence, but current side-effect authorization still runs before execution.
7. A proof is reusable only for the same protected operation/idempotent retry; different operation_key is denied.
8. Gate completion emits events; AE resumes through its own event inbox/checkpoint. Confirmation/Approval services do not write AE execution tables.
9. After COMMITTED business effect, cancellation/invalidation of approval does not roll back the business transaction; a domain reversal/follow-up is required.

All schemas/examples and Python syntax are validated during artifact generation.
