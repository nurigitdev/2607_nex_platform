-- Enterprise OS-owned Formal Approval Engine
CREATE SCHEMA IF NOT EXISTS nex_eos;

CREATE TABLE IF NOT EXISTS nex_eos.approval_policy (
    policy_id                varchar(160) NOT NULL,
    policy_version           varchar(64) NOT NULL,
    domain                   varchar(80) NOT NULL,
    status                   varchar(24) NOT NULL,
    criteria_json            jsonb NOT NULL,
    separation_of_duties_json jsonb,
    default_expiry_seconds   integer NOT NULL,
    proof_validity_seconds   integer NOT NULL,
    effective_from           timestamptz,
    effective_to             timestamptz,
    created_at               timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY(policy_id, policy_version)
);

CREATE TABLE IF NOT EXISTS nex_eos.approval_policy_stage (
    policy_id                varchar(160) NOT NULL,
    policy_version           varchar(64) NOT NULL,
    stage_no                 integer NOT NULL,
    mode                     varchar(16) NOT NULL,
    quorum                   integer NOT NULL DEFAULT 1,
    required_roles_json      jsonb NOT NULL,
    candidate_scope_json     jsonb,
    PRIMARY KEY(policy_id, policy_version, stage_no),
    FOREIGN KEY(policy_id, policy_version)
      REFERENCES nex_eos.approval_policy(policy_id, policy_version)
);

CREATE TABLE IF NOT EXISTS nex_eos.approval_instance (
    approval_instance_id     uuid PRIMARY KEY,
    approval_request_id      uuid NOT NULL UNIQUE,
    gate_id                  varchar(160) NOT NULL,
    agent_execution_id       uuid NOT NULL,
    work_item_id             uuid,
    plan_step_id             varchar(64) NOT NULL,
    requester_ref            varchar(160) NOT NULL,
    policy_id                varchar(160) NOT NULL,
    policy_version           varchar(64) NOT NULL,
    status                   varchar(24) NOT NULL,
    write_intent_hash        char(64) NOT NULL,
    payload_hash             char(64) NOT NULL,
    payload_snapshot         jsonb NOT NULL,
    business_object_refs     jsonb,
    idempotency_key          varchar(256) NOT NULL UNIQUE,
    correlation_id           varchar(128) NOT NULL,
    causation_id             varchar(128),
    version                  bigint NOT NULL DEFAULT 0,
    created_at               timestamptz NOT NULL DEFAULT now(),
    requested_at             timestamptz,
    decided_at               timestamptz,
    expires_at               timestamptz NOT NULL,
    approval_valid_until     timestamptz,
    invalidated_at           timestamptz,
    invalidation_reason      text,
    CONSTRAINT ck_approval_status CHECK (
      status IN ('DRAFT','REQUESTED','IN_REVIEW','APPROVED','REJECTED',
                 'CANCELLED','EXPIRED','INVALIDATED')
    ),
    FOREIGN KEY(policy_id, policy_version)
      REFERENCES nex_eos.approval_policy(policy_id, policy_version)
);
CREATE INDEX IF NOT EXISTS ix_approval_inbox
    ON nex_eos.approval_instance(status, expires_at, created_at);

CREATE TABLE IF NOT EXISTS nex_eos.approval_stage_instance (
    approval_instance_id     uuid NOT NULL REFERENCES nex_eos.approval_instance(approval_instance_id),
    stage_no                 integer NOT NULL,
    mode                     varchar(16) NOT NULL,
    quorum                   integer NOT NULL,
    required_roles_json      jsonb NOT NULL,
    status                   varchar(24) NOT NULL DEFAULT 'PENDING',
    started_at               timestamptz,
    completed_at             timestamptz,
    PRIMARY KEY(approval_instance_id, stage_no)
);

CREATE TABLE IF NOT EXISTS nex_eos.approval_decision (
    decision_id              uuid PRIMARY KEY,
    approval_instance_id     uuid NOT NULL REFERENCES nex_eos.approval_instance(approval_instance_id),
    stage_no                 integer NOT NULL,
    approver_ref             varchar(160) NOT NULL,
    role_binding_ref         varchar(160) NOT NULL,
    decision                 varchar(16) NOT NULL,
    comment                  text,
    authority_decision_ref   varchar(256) NOT NULL,
    separation_of_duties_passed boolean NOT NULL,
    payload_hash             char(64) NOT NULL,
    write_intent_hash        char(64) NOT NULL,
    decided_at               timestamptz NOT NULL DEFAULT now(),
    correlation_id           varchar(128) NOT NULL,
    CONSTRAINT ck_approval_decision CHECK (decision IN ('APPROVE','REJECT')),
    UNIQUE(approval_instance_id, stage_no, approver_ref)
);

CREATE TABLE IF NOT EXISTS nex_eos.approval_proof (
    proof_id                 uuid PRIMARY KEY,
    approval_instance_id     uuid NOT NULL UNIQUE REFERENCES nex_eos.approval_instance(approval_instance_id),
    proof_json               jsonb NOT NULL,
    proof_hash               char(64) NOT NULL,
    status                   varchar(24) NOT NULL DEFAULT 'SATISFIED',
    expires_at               timestamptz NOT NULL,
    consumed_operation_key   varchar(256),
    revoked_at               timestamptz,
    revocation_reason        text,
    created_at               timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_eos.approval_event_outbox (
    outbox_id                uuid PRIMARY KEY,
    event_id                 varchar(128) NOT NULL UNIQUE,
    event_name               varchar(128) NOT NULL,
    aggregate_ref            varchar(256) NOT NULL,
    payload_json             jsonb NOT NULL,
    correlation_id           varchar(128),
    causation_id             varchar(128),
    state                    varchar(24) NOT NULL DEFAULT 'PENDING',
    available_at             timestamptz NOT NULL DEFAULT now(),
    published_at             timestamptz,
    created_at               timestamptz NOT NULL DEFAULT now()
);
