-- AE-owned Structured Confirmation
CREATE TABLE IF NOT EXISTS nex_ae.confirmation_request (
    confirmation_id          uuid PRIMARY KEY,
    gate_id                  varchar(160) NOT NULL,
    agent_execution_id       uuid NOT NULL,
    work_item_id             uuid,
    plan_step_id             varchar(64) NOT NULL,
    requester_ref            varchar(160) NOT NULL,
    status                   varchar(24) NOT NULL,
    write_intent_hash        char(64) NOT NULL,
    payload_hash             char(64) NOT NULL,
    payload_snapshot         jsonb NOT NULL,
    message                  text NOT NULL,
    policy_ref               varchar(256),
    idempotency_key          varchar(256) NOT NULL UNIQUE,
    correlation_id           varchar(128) NOT NULL,
    causation_id             varchar(128),
    version                  bigint NOT NULL DEFAULT 0,
    created_at               timestamptz NOT NULL DEFAULT now(),
    presented_at             timestamptz,
    decided_at               timestamptz,
    expires_at               timestamptz NOT NULL,
    revoked_at               timestamptz,
    revocation_reason        text,
    CONSTRAINT ck_confirmation_status CHECK (
      status IN ('REQUIRED','PRESENTED','SATISFIED','REJECTED','CANCELLED','EXPIRED','REVOKED')
    )
);
CREATE INDEX IF NOT EXISTS ix_confirmation_execution
    ON nex_ae.confirmation_request(agent_execution_id, status, expires_at);

CREATE TABLE IF NOT EXISTS nex_ae.confirmation_decision (
    decision_id              uuid PRIMARY KEY,
    confirmation_id          uuid NOT NULL REFERENCES nex_ae.confirmation_request(confirmation_id),
    actor_ref                varchar(160) NOT NULL,
    decision                 varchar(16) NOT NULL,
    authority_decision_ref   varchar(256),
    payload_hash             char(64) NOT NULL,
    write_intent_hash        char(64) NOT NULL,
    decided_at               timestamptz NOT NULL DEFAULT now(),
    correlation_id           varchar(128) NOT NULL,
    CONSTRAINT ck_confirmation_decision CHECK (decision IN ('CONFIRM','REJECT','CANCEL'))
);

CREATE TABLE IF NOT EXISTS nex_ae.confirmation_proof (
    proof_id                 uuid PRIMARY KEY,
    confirmation_id          uuid NOT NULL UNIQUE REFERENCES nex_ae.confirmation_request(confirmation_id),
    proof_json               jsonb NOT NULL,
    proof_hash               char(64) NOT NULL,
    status                   varchar(24) NOT NULL DEFAULT 'SATISFIED',
    expires_at               timestamptz NOT NULL,
    consumed_operation_key   varchar(256),
    revoked_at               timestamptz,
    revocation_reason        text,
    created_at               timestamptz NOT NULL DEFAULT now()
);
