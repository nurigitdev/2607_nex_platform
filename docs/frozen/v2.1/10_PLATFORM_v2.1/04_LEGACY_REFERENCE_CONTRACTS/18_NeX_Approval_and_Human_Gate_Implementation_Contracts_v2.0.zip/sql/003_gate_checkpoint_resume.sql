-- Confirmation / Approval request and AE suspend/resume transaction boundaries

-- A. AE creates a gate request idempotently OUTSIDE the checkpoint transaction.
-- Confirmation owner = AE ConfirmationService
-- Formal Approval owner = Enterprise OS Approval Engine
-- Both requests freeze write_intent_hash + payload_hash + payload_snapshot.

-- B. After a stable gate object ref exists, AE persists WAITING_* checkpoint locally.
BEGIN;
SELECT execution_id, state, version
  FROM nex_ae.agent_execution
 WHERE execution_id=:execution_id
 FOR UPDATE;

INSERT INTO nex_ae.agent_checkpoint(... wait_state, checkpoint_json, checkpoint_hash ...)
VALUES (... :wait_state ...);

INSERT INTO nex_ae.execution_wait(
  wait_id, execution_id, checkpoint_id, condition_type,
  external_ref, expected_event_name
) VALUES (
  :wait_id, :execution_id, :checkpoint_id,
  CASE WHEN :gate_type='CONFIRMATION'
       THEN 'CONFIRMATION_RESOLVED'
       ELSE 'APPROVAL_RESOLVED' END,
  :gate_object_ref,
  CASE WHEN :gate_type='CONFIRMATION'
       THEN 'CONFIRMATION_SATISFIED'
       ELSE 'APPROVAL_APPROVED' END
);

UPDATE nex_ae.agent_execution
   SET state = CASE WHEN :gate_type='CONFIRMATION'
                    THEN 'WAITING_CONFIRMATION'
                    ELSE 'WAITING_APPROVAL' END,
       version=version+1, updated_at=now()
 WHERE execution_id=:execution_id
   AND version=:expected_version;

INSERT INTO nex_ae.runtime_outbox(...)
VALUES (... 'AGENT_EXECUTION_WAITING' ...);
COMMIT;

-- C. Confirmation/Approval owner commits decision + proof + owner outbox event atomically.
-- The event contains proof_ref, source object ref, payload_hash, write_intent_hash, correlation_id.
-- It does NOT contain a raw secret or trusted authority as client-provided fields.

-- D. AE event inbox deduplicates event_id and enqueues one RESUME_EXECUTION job.
-- On Resume:
-- 1) rebuild current Effective Authority Context;
-- 2) fetch current proof through trusted GateProofProvider;
-- 3) if proof expired/revoked/invalidated/rejected -> BLOCKED/ESCALATED or request new gate;
-- 4) if protected payload/write intent changed -> invalidate old proof and request a new gate;
-- 5) if current policy denies execution -> do not consume proof / no side effect.

-- E. NSL immediately before WRITE validates exact proof/payload/intent/operation binding.
-- Provider WRITE uses stable idempotency key.
