-- Reference expiry/cancellation/invalidation processing

-- Confirmation expiry
UPDATE nex_ae.confirmation_request
   SET status='EXPIRED', version=version+1
 WHERE status IN ('REQUIRED','PRESENTED')
   AND expires_at <= now();

-- Pending formal approval expiry
UPDATE nex_eos.approval_instance
   SET status='EXPIRED', version=version+1, decided_at=now()
 WHERE status IN ('REQUESTED','IN_REVIEW')
   AND expires_at <= now();

-- Approved proof validity is time-bound even if historical ApprovalInstance remains APPROVED.
-- GateProofVerifier checks approval_valid_until/proof.expires_at at execution time.

-- Material protected-payload change invalidates an approved instance before side effect.
UPDATE nex_eos.approval_instance
   SET status='INVALIDATED',
       invalidated_at=now(),
       invalidation_reason=:reason,
       version=version+1
 WHERE approval_instance_id=:approval_instance_id
   AND status='APPROVED';

-- Cancellation is allowed only before a final approval/rejection.
UPDATE nex_eos.approval_instance
   SET status='CANCELLED',
       decided_at=now(),
       version=version+1
 WHERE approval_instance_id=:approval_instance_id
   AND status IN ('DRAFT','REQUESTED','IN_REVIEW');
