from __future__ import annotations
from datetime import datetime
from enum import StrEnum
from typing import Any
from pydantic import BaseModel, ConfigDict, Field

class GateType(StrEnum):
    CONFIRMATION = "CONFIRMATION"
    FORMAL_APPROVAL = "FORMAL_APPROVAL"

class ConfirmationStatus(StrEnum):
    REQUIRED = "REQUIRED"
    PRESENTED = "PRESENTED"
    SATISFIED = "SATISFIED"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"

class ApprovalStatus(StrEnum):
    DRAFT = "DRAFT"
    REQUESTED = "REQUESTED"
    IN_REVIEW = "IN_REVIEW"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"
    INVALIDATED = "INVALIDATED"

class HumanGateRequirement(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    requirement_version: str = "1.0"
    gate_id: str
    gate_type: GateType
    protected_step_id: str
    skill_ref: dict[str, str]
    capability_id: str
    operation_key: str
    policy_ref: str
    requester_ref: str | None = None
    approver_policy_ref: str | None = None
    payload_binding: str = "BOTH"
    valid_for_seconds: int = 900
    created_at: datetime

class HumanGateProof(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    proof_version: str = "1.1"
    proof_id: str
    gate_id: str
    gate_type: GateType
    status: str
    actor_ref: str
    role_binding_ref: str | None = None
    skill_id: str
    skill_version: str
    agent_execution_id: str
    work_item_id: str | None = None
    plan_step_id: str
    capability_id: str
    operation_key: str
    write_intent_hash: str
    payload_hash: str
    policy_ref: str | None = None
    policy_version: str | None = None
    source_object_ref: str
    approval_instance_ref: str | None = None
    issued_at: datetime
    expires_at: datetime
    consumed_operation_key: str | None = None
    proof_source: str
    proof_signature: str | None = None
    correlation_id: str
