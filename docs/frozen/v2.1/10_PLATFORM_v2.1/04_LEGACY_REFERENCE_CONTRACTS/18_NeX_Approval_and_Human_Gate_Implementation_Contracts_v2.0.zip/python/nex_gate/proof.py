from __future__ import annotations
from datetime import datetime, timezone
from typing import Any
from .hashing import payload_hash, write_intent_hash
from .models import HumanGateProof

class GateProofVerifier:
    def __init__(self, proof_store, pdp):
        self.proof_store=proof_store
        self.pdp=pdp

    async def verify(self, *, proof_ref: str, requirement, execution_context,
                     write_payload: dict[str,Any]) -> HumanGateProof:
        proof=await self.proof_store.get(proof_ref)
        now=datetime.now(timezone.utc)
        if proof.status!="SATISFIED":
            raise ValueError("GATE_PROOF_NOT_SATISFIED")
        if proof.expires_at <= now:
            raise ValueError("GATE_PROOF_EXPIRED")
        if proof.gate_id!=requirement.gate_id or proof.gate_type!=requirement.gate_type:
            raise ValueError("GATE_REQUIREMENT_MISMATCH")
        if proof.skill_id!=requirement.skill_ref["skill_id"] or proof.skill_version!=requirement.skill_ref["skill_version"]:
            raise ValueError("GATE_SKILL_VERSION_MISMATCH")
        if proof.agent_execution_id!=execution_context["agent_execution_id"] or proof.plan_step_id!=requirement.protected_step_id:
            raise ValueError("GATE_EXECUTION_BINDING_MISMATCH")
        if proof.capability_id!=requirement.capability_id or proof.operation_key!=requirement.operation_key:
            raise ValueError("GATE_OPERATION_BINDING_MISMATCH")

        expected_intent=write_intent_hash(
            skill_id=requirement.skill_ref["skill_id"],
            skill_version=requirement.skill_ref["skill_version"],
            capability_id=requirement.capability_id,
            operation_key=requirement.operation_key,
            protected_step_id=requirement.protected_step_id,
        )
        expected_payload=payload_hash(write_payload)
        if proof.write_intent_hash!=expected_intent:
            raise ValueError("GATE_WRITE_INTENT_HASH_MISMATCH")
        if proof.payload_hash!=expected_payload:
            raise ValueError("GATE_PAYLOAD_HASH_MISMATCH")

        current=await self.pdp.authorize_protected_operation(
            requirement=requirement, execution_context=execution_context,
            proof=proof.model_dump(mode="json")
        )
        if not current.get("allowed",False):
            raise PermissionError("PROTECTED_OPERATION_CURRENT_POLICY_DENIED")
        return proof
