from __future__ import annotations
from datetime import datetime, timedelta, timezone
from typing import Any, Mapping
from .hashing import payload_hash, write_intent_hash, gate_request_hash

Json = Mapping[str, Any]

class ConfirmationService:
    def __init__(self, repository, pdp, proof_issuer, outbox, id_generator, clock):
        self.repository=repository
        self.pdp=pdp
        self.proof_issuer=proof_issuer
        self.outbox=outbox
        self.id_generator=id_generator
        self.clock=clock

    async def create(
        self, *, requirement, execution_context: Json, write_payload: Json,
        message: str, idempotency_key: str
    ) -> Json:
        auth=await self.pdp.can_confirm(requirement.requester_ref, execution_context)
        if not auth.get("allowed",False):
            raise PermissionError("CONFIRMATION_REQUESTER_NOT_ALLOWED")

        wh=write_intent_hash(
            skill_id=requirement.skill_ref["skill_id"],
            skill_version=requirement.skill_ref["skill_version"],
            capability_id=requirement.capability_id,
            operation_key=requirement.operation_key,
            protected_step_id=requirement.protected_step_id,
        )
        ph=payload_hash(write_payload)
        now=self.clock.now()
        request={
            "request_version":"1.0",
            "confirmation_id":self.id_generator.new_id(),
            "gate_id":requirement.gate_id,
            "agent_execution_id":execution_context["agent_execution_id"],
            "work_item_id":execution_context.get("work_item_id"),
            "plan_step_id":requirement.protected_step_id,
            "requester_ref":requirement.requester_ref,
            "status":"REQUIRED",
            "write_intent_hash":wh,
            "payload_hash":ph,
            "payload_snapshot":write_payload,
            "message":message,
            "policy_ref":requirement.policy_ref,
            "created_at":now.isoformat(),
            "presented_at":None,
            "decided_at":None,
            "expires_at":(now+timedelta(seconds=requirement.valid_for_seconds)).isoformat(),
            "correlation_id":execution_context["correlation_id"],
            "causation_id":execution_context.get("causation_id"),
        }
        return await self.repository.create(request,idempotency_key)

    async def decide(self, *, confirmation_id: str, requester_ref: str,
                     decision: str, expected_version: int, requirement) -> Json:
        current=await self.repository.get(confirmation_id)
        if current["requester_ref"] != requester_ref:
            raise PermissionError("CONFIRMATION_ACTOR_MISMATCH")
        auth=await self.pdp.can_confirm(requester_ref,current)
        if not auth.get("allowed",False):
            raise PermissionError("CONFIRMATION_AUTHORITY_DENIED")
        if current["status"] not in {"REQUIRED","PRESENTED"}:
            raise ValueError("CONFIRMATION_NOT_DECIDABLE")
        if self.clock.now().isoformat() >= current["expires_at"]:
            raise ValueError("CONFIRMATION_EXPIRED")

        updated=await self.repository.decide({
            "confirmation_id":confirmation_id,
            "decision":decision,
            "actor_ref":requester_ref,
        },expected_version)

        if decision=="CONFIRM":
            proof=await self.proof_issuer.issue_confirmation(updated,requirement)
            await self.outbox.append({
                "event_name":"CONFIRMATION_SATISFIED",
                "confirmation_id":confirmation_id,
                "proof_ref":proof.proof_id,
                "correlation_id":updated["correlation_id"],
            })
            return {"confirmation":updated,"proof":proof.model_dump(mode="json")}

        await self.outbox.append({
            "event_name":"CONFIRMATION_REJECTED",
            "confirmation_id":confirmation_id,
            "correlation_id":updated["correlation_id"],
        })
        return {"confirmation":updated,"proof":None}
