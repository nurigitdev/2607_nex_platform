from __future__ import annotations
from typing import Any, Mapping
from .hashing import payload_hash, write_intent_hash

Json = Mapping[str, Any]

class ApprovalService:
    def __init__(self, repository, policy_resolver, approver_resolver, pdp,
                 proof_issuer, outbox, id_generator, clock):
        self.repository=repository
        self.policy_resolver=policy_resolver
        self.approver_resolver=approver_resolver
        self.pdp=pdp
        self.proof_issuer=proof_issuer
        self.outbox=outbox
        self.id_generator=id_generator
        self.clock=clock

    async def create(self, *, requirement, execution_context: Json, write_payload: Json,
                     business_object_refs: list[Json], idempotency_key: str) -> Json:
        wh=write_intent_hash(
            skill_id=requirement.skill_ref["skill_id"],
            skill_version=requirement.skill_ref["skill_version"],
            capability_id=requirement.capability_id,
            operation_key=requirement.operation_key,
            protected_step_id=requirement.protected_step_id,
        )
        ph=payload_hash(write_payload)
        request={
            "request_version":"1.0",
            "approval_request_id":self.id_generator.new_id(),
            "gate_id":requirement.gate_id,
            "agent_execution_id":execution_context["agent_execution_id"],
            "work_item_id":execution_context.get("work_item_id"),
            "plan_step_id":requirement.protected_step_id,
            "requester_ref":execution_context["business_actor_ref"],
            "policy_ref":requirement.approver_policy_ref or requirement.policy_ref,
            "write_intent_hash":wh,
            "payload_hash":ph,
            "payload_snapshot":write_payload,
            "business_object_refs":business_object_refs,
            "requested_validity_seconds":requirement.valid_for_seconds,
            "created_at":self.clock.now().isoformat(),
            "correlation_id":execution_context["correlation_id"],
            "causation_id":execution_context.get("causation_id"),
        }
        policy=await self.policy_resolver.resolve(request)
        return await self.repository.create_instance(request,policy,idempotency_key)

    async def decide(self, *, approval_instance_id: str, stage_no: int,
                     approver: Json, decision: str, comment: str | None,
                     expected_version: int, requirement) -> Json:
        instance=await self.repository.get(approval_instance_id)
        if instance["status"] not in {"REQUESTED","IN_REVIEW"}:
            raise ValueError("APPROVAL_NOT_DECIDABLE")
        stage=next(s for s in instance["stages"] if s["stage_no"]==stage_no)
        auth=await self.pdp.can_approve(approver=approver,request=instance,stage=stage)
        if not auth.get("allowed",False):
            raise PermissionError("APPROVER_AUTHORITY_DENIED")
        if not auth.get("separation_of_duties_passed",True):
            raise PermissionError("SEPARATION_OF_DUTIES_DENIED")

        decision_record={
            "decision_version":"1.0",
            "decision_id":self.id_generator.new_id(),
            "approval_instance_id":approval_instance_id,
            "stage_no":stage_no,
            "approver_ref":approver["approver_ref"],
            "role_binding_ref":approver["role_binding_ref"],
            "decision":decision,
            "comment":comment,
            "authority_decision_ref":auth["decision_ref"],
            "separation_of_duties_passed":auth.get("separation_of_duties_passed",True),
            "payload_hash":instance["payload_hash"],
            "write_intent_hash":instance["write_intent_hash"],
            "decided_at":self.clock.now().isoformat(),
            "correlation_id":instance["correlation_id"],
        }
        updated=await self.repository.append_decision(decision_record,expected_version)

        proof=None
        if updated["status"]=="APPROVED":
            proof=await self.proof_issuer.issue_approval(updated,decision_record,requirement)
            await self.outbox.append({
                "event_name":"APPROVAL_APPROVED",
                "approval_instance_id":approval_instance_id,
                "proof_ref":proof.proof_id,
                "correlation_id":updated["correlation_id"],
            })
        elif updated["status"]=="REJECTED":
            await self.outbox.append({
                "event_name":"APPROVAL_REJECTED",
                "approval_instance_id":approval_instance_id,
                "correlation_id":updated["correlation_id"],
            })
        return {"approval":updated,"decision":decision_record,
                "proof":proof.model_dump(mode="json") if proof else None}
