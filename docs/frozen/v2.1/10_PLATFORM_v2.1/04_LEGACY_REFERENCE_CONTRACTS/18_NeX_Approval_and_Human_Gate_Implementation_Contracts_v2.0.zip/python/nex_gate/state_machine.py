CONFIRMATION_TRANSITIONS = {
    "REQUIRED":{"PRESENTED","SATISFIED","REJECTED","CANCELLED","EXPIRED","REVOKED"},
    "PRESENTED":{"SATISFIED","REJECTED","CANCELLED","EXPIRED","REVOKED"},
    "SATISFIED":{"REVOKED"},
    "REJECTED":set(),"CANCELLED":set(),"EXPIRED":set(),"REVOKED":set(),
}

APPROVAL_TRANSITIONS = {
    "DRAFT":{"REQUESTED","CANCELLED"},
    "REQUESTED":{"IN_REVIEW","APPROVED","REJECTED","CANCELLED","EXPIRED"},
    "IN_REVIEW":{"APPROVED","REJECTED","CANCELLED","EXPIRED"},
    "APPROVED":{"INVALIDATED"},
    "REJECTED":set(),"CANCELLED":set(),"EXPIRED":set(),"INVALIDATED":set(),
}

def assert_confirmation_transition(current:str,target:str)->None:
    if target not in CONFIRMATION_TRANSITIONS.get(current,set()):
        raise ValueError(f"INVALID_CONFIRMATION_TRANSITION:{current}->{target}")

def assert_approval_transition(current:str,target:str)->None:
    if target not in APPROVAL_TRANSITIONS.get(current,set()):
        raise ValueError(f"INVALID_APPROVAL_TRANSITION:{current}->{target}")
