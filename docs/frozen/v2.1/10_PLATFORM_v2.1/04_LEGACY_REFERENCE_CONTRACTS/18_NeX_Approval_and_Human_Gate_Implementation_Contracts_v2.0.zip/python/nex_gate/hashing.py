from __future__ import annotations
import hashlib, json
from typing import Any, Mapping

Json = Mapping[str, Any]

def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")

def sha256_hex(value: Any) -> str:
    if isinstance(value, bytes):
        data=value
    elif isinstance(value, str):
        data=value.encode("utf-8")
    else:
        data=canonical_json_bytes(value)
    return hashlib.sha256(data).hexdigest()

def write_intent_hash(*, skill_id: str, skill_version: str, capability_id: str,
                      operation_key: str, protected_step_id: str) -> str:
    return sha256_hex({
        "skill_id": skill_id,
        "skill_version": skill_version,
        "capability_id": capability_id,
        "operation_key": operation_key,
        "protected_step_id": protected_step_id,
    })

def payload_hash(payload: Json) -> str:
    return sha256_hex(payload)

def gate_request_hash(*, gate_type: str, policy_ref: str, write_intent_hash_value: str,
                      payload_hash_value: str, requester_ref: str | None) -> str:
    return sha256_hex({
        "gate_type": gate_type,
        "policy_ref": policy_ref,
        "write_intent_hash": write_intent_hash_value,
        "payload_hash": payload_hash_value,
        "requester_ref": requester_ref,
    })
