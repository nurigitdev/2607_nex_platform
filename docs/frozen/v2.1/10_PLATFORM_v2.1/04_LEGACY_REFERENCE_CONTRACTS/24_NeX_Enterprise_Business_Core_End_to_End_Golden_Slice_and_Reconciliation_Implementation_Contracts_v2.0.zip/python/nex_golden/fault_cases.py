from __future__ import annotations
from typing import Mapping, Any

EXPECTED_CONTROLS={
    "DUPLICATE_COMMAND":"same idempotency key returns original object/posting; no duplicate financial effect",
    "APPROVAL_PAYLOAD_CHANGE":"old proof rejected by payload/write-intent hash; new gate required",
    "INVOICE_MATCH_EXCEPTION":"invoice remains EXCEPTION; no purchase voucher/actual cost unless governed override",
    "UNKNOWN_COMMIT_STATE":"RECONCILIATION_REQUIRED; no blind duplicate posting",
    "DUPLICATE_EVENT":"inbox/event dedup or bucket recompute prevents duplicate financial/read-model effect",
    "PROJECTION_LAG":"Golden run WAITING_CONVERGENCE until projection watermark catches ledger",
    "LABOR_COST_MISMATCH":"monthly close/allocation blocked or Golden reconciliation FAIL",
    "LEGACY_MISMATCH":"optional dual-run check reports MISMATCH; no automatic dual write/correction",
}

def validate_fault_case(case:Mapping[str,Any])->None:
    expected=EXPECTED_CONTROLS.get(case["fault_type"])
    if not expected:
        raise ValueError("UNKNOWN_FAULT_TYPE")
    if case["expected_control"] != expected:
        raise ValueError("FAULT_EXPECTED_CONTROL_MISMATCH")
