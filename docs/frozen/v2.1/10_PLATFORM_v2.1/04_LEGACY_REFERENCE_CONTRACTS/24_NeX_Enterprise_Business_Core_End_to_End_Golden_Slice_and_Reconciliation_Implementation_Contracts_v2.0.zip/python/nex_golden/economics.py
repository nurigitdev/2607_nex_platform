from __future__ import annotations
from decimal import Decimal
from typing import Any, Mapping

COST_FIELDS=("labor","material","direct_expense","common_cost")

def decimal_money(obj:Mapping[str,Any])->Decimal:
    return Decimal(str(obj["amount"]))

def expected_profit(e:Mapping[str,Any])->Decimal:
    return (decimal_money(e["revenue"])
            - decimal_money(e["labor"])
            - decimal_money(e["material_actual"])
            - decimal_money(e["direct_expense"])
            - decimal_money(e["common_cost"])
            + decimal_money(e["adjustment_profit_effect"]))

def assert_expected_economics(e:Mapping[str,Any])->None:
    currency=e["revenue"]["currency"]
    for key,val in e.items():
        if isinstance(val,dict) and "currency" in val and val["currency"]!=currency:
            raise ValueError(f"CURRENCY_MISMATCH:{key}")
    if expected_profit(e)!=decimal_money(e["profit"]):
        raise ValueError("EXPECTED_PROFIT_FORMULA_MISMATCH")
    commitment=decimal_money(e["procurement_commitment"])
    actual=decimal_money(e["procurement_recognized_actual"])
    open_amt=decimal_money(e["procurement_open_commitment"])
    if commitment-actual != open_amt:
        raise ValueError("COMMITMENT_ACTUAL_OPEN_MISMATCH")
