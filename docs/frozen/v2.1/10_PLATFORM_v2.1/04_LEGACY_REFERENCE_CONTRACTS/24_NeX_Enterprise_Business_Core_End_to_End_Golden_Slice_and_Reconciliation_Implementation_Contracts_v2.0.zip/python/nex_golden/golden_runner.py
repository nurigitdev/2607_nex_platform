from __future__ import annotations
from typing import Any, Mapping

class GoldenSliceRunner:
    """Reference test-harness orchestrator. Production services are called only through canonical test gateways."""

    def __init__(self, actions, reconciler, repository, clock):
        self.actions=actions; self.reconciler=reconciler
        self.repository=repository; self.clock=clock

    async def run(self, scenario:Mapping[str,Any], context:Mapping[str,Any]) -> Mapping[str,Any]:
        run={
            "schema_version":"1.0","run_id":context["run_id"],
            "scenario_id":scenario["scenario_id"],"state":"RUNNING",
            "project_ref":scenario["project_hierarchy"]["child_project_ref"],
            "period_ref":scenario["period_ref"],"checks":[],
            "required_pass_count":0,"required_fail_count":0,"optional_na_count":0,
            "final_status":"WAITING","started_at":self.clock.now().isoformat(),"completed_at":None
        }
        await self.repository.start_run(run)

        results=[]
        completed=set()
        for step in scenario["steps"]:
            missing=[x for x in step.get("depends_on",[]) if x not in completed]
            if missing:
                raise ValueError(f"GOLDEN_DEPENDENCY_NOT_COMPLETED:{step['step_id']}:{missing}")
            result=await self.actions.execute_step(step,context)
            results.append(result)
            if result["status"]!="PASS":
                run["state"]="FAILED"; run["final_status"]="FAIL"
                run["completed_at"]=self.clock.now().isoformat()
                return await self.repository.complete_run(run)
            completed.add(step["step_id"])

        recon=await self.reconciler.run(scenario)
        run["checks"]=recon["checks"]
        run["required_pass_count"]=recon["required_pass_count"]
        run["required_fail_count"]=recon["required_fail_count"]
        run["optional_na_count"]=recon["optional_na_count"]
        run["final_status"]=recon["final_status"]
        run["state"]="WAITING_CONVERGENCE" if recon["final_status"]=="WAITING" else ("COMPLETED" if recon["final_status"]=="PASS" else "FAILED")
        run["completed_at"]=None if run["state"]=="WAITING_CONVERGENCE" else self.clock.now().isoformat()
        return await self.repository.complete_run(run)
