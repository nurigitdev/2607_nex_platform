from __future__ import annotations
from decimal import Decimal
from typing import Any, Mapping, Sequence
from .models import ReconStatus
from .economics import decimal_money, expected_profit

def _now(clock):
    return clock.now().isoformat()

class ReconciliationEngine:
    def __init__(self, source, ledger, pl, lineage, legacy, clock):
        self.source=source; self.ledger=ledger; self.pl=pl
        self.lineage=lineage; self.legacy=legacy; self.clock=clock

    def _check(self, check_id, check_type, status, required, expected, actual,
               difference=None, tolerance=None, reason_codes=None, evidence_refs=None):
        return {
            "schema_version":"1.0","check_id":check_id,"check_type":check_type,
            "status":status,"required":required,"expected":expected,"actual":actual,
            "difference":difference,"tolerance":tolerance,
            "reason_codes":reason_codes or [],"evidence_refs":evidence_refs or [],
            "checked_at":_now(self.clock)
        }

    async def run(self, scenario:Mapping[str,Any]) -> dict[str,Any]:
        project=scenario["project_hierarchy"]["child_project_ref"]
        mother=scenario["project_hierarchy"]["mother_project_ref"]
        nvt=scenario["project_hierarchy"]["nvt_project_ref"]
        period=scenario["period_ref"]
        exp=scenario["expected_economics"]
        checks=[]

        vouchers=list(await self.source.get_vouchers(project,period))
        # Voucher balance checks
        for v in vouchers:
            debit=sum(Decimal(str(x["amount"])) for x in v["lines"] if x["side"]=="DEBIT")
            credit=sum(Decimal(str(x["amount"])) for x in v["lines"] if x["side"]=="CREDIT")
            status="PASS" if debit==credit else "MISMATCH"
            checks.append(self._check(f"VOUCHER_BALANCE:{v['voucher_id']}","VOUCHER_BALANCE",
                                      status,True,str(debit),str(credit),str(debit-credit),0,
                                      [] if status=="PASS" else ["VOUCHER_NOT_BALANCED"]))

        entries=list(await self.ledger.list_entries(project,period,"DIRECT"))
        # Source economic lines vs PFL entries by source voucher
        for v in vouchers:
            econ=Decimal("0")
            for x in v["lines"]:
                if x["economic_category"]!="NONE":
                    amount=Decimal(str(x["amount"]))
                    if x["economic_category"]=="REVENUE":
                        econ += amount if x["side"]=="CREDIT" else -amount
                    else:
                        econ += amount if x["side"]=="DEBIT" else -amount
            led=Decimal("0")
            for e in entries:
                if e.get("source_transaction_id")==v["voucher_id"]:
                    amount=Decimal(str(e["amount"]))
                    if e["category"]=="REVENUE":
                        led += amount if e["side"]=="CREDIT" else -amount
                    else:
                        led += amount if e["side"]=="DEBIT" else -amount
            st="PASS" if econ==led else "MISMATCH"
            checks.append(self._check(f"SOURCE_LEDGER:{v['voucher_id']}","SOURCE_TO_LEDGER",
                                      st,True,str(econ),str(led),str(econ-led),0,
                                      [] if st=="PASS" else ["SOURCE_LEDGER_EFFECT_MISMATCH"]))

        procurement=await self.source.get_procurement(project,period)
        commitment=Decimal(str(procurement["commitment_amount"]))
        recognized=Decimal(str(procurement["recognized_actual_amount"]))
        open_amt=Decimal(str(procurement["open_commitment_amount"]))
        expected_triplet=(decimal_money(exp["procurement_commitment"]),
                          decimal_money(exp["procurement_recognized_actual"]),
                          decimal_money(exp["procurement_open_commitment"]))
        actual_triplet=(commitment,recognized,open_amt)
        cst="PASS" if actual_triplet==expected_triplet and commitment-recognized==open_amt else "MISMATCH"
        checks.append(self._check("COMMITMENT_ACTUAL","COMMITMENT_ACTUAL",cst,True,
                                  [str(x) for x in expected_triplet],[str(x) for x in actual_triplet],
                                  None,0,[] if cst=="PASS" else ["COMMITMENT_RECONCILIATION_FAILED"]))

        labor=await self.source.get_labor(project,period)
        labor_pool=Decimal(str(labor["cost_pool_amount"]))
        labor_alloc=Decimal(str(labor["allocated_project_amount"]))
        labor_ledger=Decimal(str(labor["ledger_labor_amount"]))
        expected_labor=decimal_money(exp["labor"])
        lst="PASS" if labor_pool==labor_alloc==labor_ledger==expected_labor else "MISMATCH"
        checks.append(self._check("LABOR_COST","LABOR_COST",lst,True,str(expected_labor),
                                  {"cost_pool":str(labor_pool),"allocation":str(labor_alloc),"ledger":str(labor_ledger)},
                                  None,0,[] if lst=="PASS" else ["LABOR_COST_NOT_RECONCILED"]))

        direct=await self.pl.get_pl(project,period,"DIRECT")
        roll_m=await self.pl.get_pl(mother,period,"ROLLUP")
        roll_n=await self.pl.get_pl(nvt,period,"ROLLUP")
        expected_direct={
            "revenue":exp["revenue"]["amount"],"labor":exp["labor"]["amount"],
            "material":exp["material_actual"]["amount"],"direct_expense":exp["direct_expense"]["amount"],
            "common_cost":exp["common_cost"]["amount"],"adjustment_profit_effect":exp["adjustment_profit_effect"]["amount"],
            "profit":exp["profit"]["amount"]
        }
        fields=list(expected_direct)
        def subset(x): return {k:str(x[k]) for k in fields}
        dst="PASS" if subset(direct)==expected_direct else "MISMATCH"
        checks.append(self._check("PL_DIRECT","PL_DIRECT",dst,True,expected_direct,subset(direct),
                                  None,0,[] if dst=="PASS" else ["DIRECT_PL_MISMATCH"]))
        mst="PASS" if subset(roll_m)==expected_direct else "MISMATCH"
        checks.append(self._check("PL_MOTHER_ROLLUP","PL_ROLLUP",mst,True,expected_direct,subset(roll_m),
                                  None,0,[] if mst=="PASS" else ["MOTHER_ROLLUP_MISMATCH"]))
        nst="PASS" if subset(roll_n)==expected_direct else "MISMATCH"
        checks.append(self._check("PL_NVT_ROLLUP","PL_ROLLUP",nst,True,expected_direct,subset(roll_n),
                                  None,0,[] if nst=="PASS" else ["NVT_ROLLUP_MISMATCH"]))

        # Projection freshness
        ledger_seq=await self.ledger.max_posting_seq(project,period)
        projection_seq=await self.pl.get_projection_watermark()
        fst="PASS" if projection_seq>=ledger_seq else "STALE_READ_MODEL"
        checks.append(self._check("PROJECTION_FRESHNESS","PROJECTION_FRESHNESS",fst,True,
                                  ledger_seq,projection_seq,ledger_seq-projection_seq,0,
                                  [] if fst=="PASS" else ["PROJECTION_BEHIND_LEDGER"]))

        # Lineage completeness
        missing=[]
        for e in entries:
            lin=await self.lineage.get_lineage(e["ledger_entry_id"])
            if not lin or not lin.get("source_transaction_ref") or not lin.get("project_path"):
                missing.append(e["ledger_entry_id"])
        lin_st="PASS" if not missing else "UNVERIFIED"
        checks.append(self._check("LINEAGE","LINEAGE",lin_st,True,0,len(missing),len(missing),0,
                                  [] if not missing else ["MISSING_FINANCIAL_LINEAGE"],
                                  []))

        # Optional legacy comparison
        legacy_result=await self.legacy.compare(scenario,{
            "direct_pl":direct,"procurement":procurement,"labor":labor
        })
        if legacy_result.get("available",False):
            lstatus="PASS" if legacy_result.get("match",False) else "MISMATCH"
            checks.append(self._check("LEGACY_DUAL_RUN","LEGACY_DUAL_RUN",lstatus,False,
                                      legacy_result.get("expected"),legacy_result.get("actual"),
                                      legacy_result.get("difference"),legacy_result.get("tolerance",0),
                                      legacy_result.get("reason_codes",[])))
        else:
            checks.append(self._check("LEGACY_DUAL_RUN","LEGACY_DUAL_RUN","NOT_APPLICABLE",False,
                                      None,None,None,None,["LEGACY_COMPARATOR_NOT_CONFIGURED"]))

        required_fail=sum(1 for c in checks if c["required"] and c["status"]!="PASS")
        required_pass=sum(1 for c in checks if c["required"] and c["status"]=="PASS")
        waiting=any(c["required"] and c["status"]=="STALE_READ_MODEL" for c in checks)
        final="WAITING" if waiting and all(c["status"] in {"PASS","STALE_READ_MODEL"} for c in checks if c["required"]) else ("PASS" if required_fail==0 else "FAIL")
        return {
            "schema_version":"1.0","checks":checks,
            "required_pass_count":required_pass,"required_fail_count":required_fail,
            "optional_na_count":sum(1 for c in checks if not c["required"] and c["status"]=="NOT_APPLICABLE"),
            "final_status":final
        }
