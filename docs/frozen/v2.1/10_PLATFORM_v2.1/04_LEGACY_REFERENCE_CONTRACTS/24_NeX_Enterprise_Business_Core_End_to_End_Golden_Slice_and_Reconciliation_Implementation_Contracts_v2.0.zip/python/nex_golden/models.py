from __future__ import annotations
from decimal import Decimal
from enum import StrEnum
from pydantic import BaseModel, ConfigDict

class ReconStatus(StrEnum):
    PASS="PASS"; MISMATCH="MISMATCH"; MISSING_SOURCE="MISSING_SOURCE"
    MISSING_LEDGER="MISSING_LEDGER"; DUPLICATE="DUPLICATE"
    STALE_READ_MODEL="STALE_READ_MODEL"; UNVERIFIED="UNVERIFIED"
    NOT_APPLICABLE="NOT_APPLICABLE"

class FinalStatus(StrEnum):
    PASS="PASS"; FAIL="FAIL"; WAITING="WAITING"

class Money(BaseModel):
    model_config=ConfigDict(extra="forbid", frozen=True)
    amount: Decimal
    currency: str
