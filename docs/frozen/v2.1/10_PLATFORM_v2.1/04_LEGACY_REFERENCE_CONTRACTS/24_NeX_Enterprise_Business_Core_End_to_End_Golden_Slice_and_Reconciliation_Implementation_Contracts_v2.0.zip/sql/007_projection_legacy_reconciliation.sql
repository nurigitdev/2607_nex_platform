-- Projection freshness and legacy dual-run reference
SELECT
  (SELECT COALESCE(MAX(posting_seq),0) FROM nex_eos.ledger_posting) AS ledger_max_seq,
  (SELECT last_posting_seq FROM nex_eos.financial_projection_checkpoint
    WHERE projection_name='PROJECT_PL_PERIOD') AS projection_seq;

-- Legacy dual-run is validation, NOT dual-write.
-- Adapter-specific legacy financial facts are loaded into a test/reconciliation staging table:
--   nex_test.legacy_project_economics_snapshot
-- and compared by Project/Period/Category/Currency after explicit canonical ID mapping.
-- Mismatch never causes automatic writes to either system.
