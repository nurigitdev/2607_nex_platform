-- Source Voucher -> Project Financial Ledger reconciliation
WITH voucher_economic AS (
    SELECT
        v.voucher_id,
        v.project_id,
        v.currency,
        SUM(CASE
            WHEN vl.economic_category='NONE' THEN 0
            WHEN vl.economic_category='REVENUE'
              THEN CASE WHEN vl.side='CREDIT' THEN vl.amount ELSE -vl.amount END
            ELSE CASE WHEN vl.side='DEBIT' THEN vl.amount ELSE -vl.amount END
        END) AS economic_effect
    FROM nex_eos.voucher v
    JOIN nex_eos.voucher_line vl ON vl.voucher_id=v.voucher_id
    WHERE v.project_id=:project_id
      AND v.state='POSTED'
      AND v.transaction_date BETWEEN :period_start AND :period_end
    GROUP BY v.voucher_id,v.project_id,v.currency
),
ledger_effect AS (
    SELECT
        le.source_transaction_id AS voucher_id,
        le.project_id,
        le.currency,
        SUM(CASE
            WHEN le.category='REVENUE'
              THEN CASE WHEN le.side='CREDIT' THEN le.amount ELSE -le.amount END
            ELSE CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END
        END) AS ledger_effect
    FROM nex_eos.ledger_entry le
    WHERE le.project_id=:project_id
      AND le.source_transaction_type='VOUCHER'
      AND le.posting_date BETWEEN :period_start AND :period_end
    GROUP BY le.source_transaction_id,le.project_id,le.currency
)
SELECT
    ve.voucher_id,ve.economic_effect,le.ledger_effect,
    ve.economic_effect-COALESCE(le.ledger_effect,0) AS difference
FROM voucher_economic ve
LEFT JOIN ledger_effect le ON le.voucher_id=ve.voucher_id;
