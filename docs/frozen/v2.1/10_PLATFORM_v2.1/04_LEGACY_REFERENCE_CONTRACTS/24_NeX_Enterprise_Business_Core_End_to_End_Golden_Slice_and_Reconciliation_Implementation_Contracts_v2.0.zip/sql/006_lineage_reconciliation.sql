-- Financial lineage completeness check
SELECT
  le.ledger_entry_id,
  fli.ledger_entry_id IS NOT NULL AS lineage_index_present,
  le.source_transaction_type,
  le.source_transaction_id,
  le.project_id,
  le.correlation_id,
  CASE
    WHEN le.source_transaction_id IS NULL THEN 'MISSING_SOURCE_TRANSACTION'
    WHEN le.project_id IS NULL THEN 'MISSING_PROJECT'
    WHEN le.correlation_id IS NULL THEN 'MISSING_CORRELATION'
    WHEN fli.ledger_entry_id IS NULL THEN 'MISSING_LINEAGE_INDEX'
    ELSE 'OK'
  END AS lineage_status
FROM nex_eos.ledger_entry le
LEFT JOIN nex_eos.financial_lineage_index fli
  ON fli.ledger_entry_id=le.ledger_entry_id
WHERE le.project_id=:project_id AND le.period_id=:period_id;
