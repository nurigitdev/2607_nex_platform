-- Labor Cost Pool -> Labor Allocation -> Project Financial Ledger LABOR
WITH alloc AS (
  SELECT
    lab.employee_ref,lab.period_ref,
    SUM(lai.allocated_cost) AS allocated_cost
  FROM nex_eos.labor_allocation_batch lab
  JOIN nex_eos.labor_allocation_item lai ON lai.batch_id=lab.batch_id
  WHERE lab.state='POSTED'
    AND lab.period_ref=:period_ref
  GROUP BY lab.employee_ref,lab.period_ref
),
ledger AS (
  SELECT
    le.dimensions_json->>'employee_ref' AS employee_ref,
    le.period_id::text AS period_ref,
    SUM(CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END) AS ledger_labor
  FROM nex_eos.ledger_entry le
  WHERE le.category='LABOR'
    AND le.period_id=:period_id
  GROUP BY le.dimensions_json->>'employee_ref',le.period_id
)
SELECT
  lcp.employee_ref,lcp.period_ref,lcp.cost_amount,
  a.allocated_cost,l.ledger_labor,
  lcp.cost_amount-COALESCE(a.allocated_cost,0) AS allocation_difference,
  COALESCE(a.allocated_cost,0)-COALESCE(l.ledger_labor,0) AS ledger_difference
FROM nex_eos.labor_cost_pool lcp
LEFT JOIN alloc a ON a.employee_ref=lcp.employee_ref AND a.period_ref=lcp.period_ref
LEFT JOIN ledger l ON l.employee_ref=lcp.employee_ref AND l.period_ref=lcp.period_ref
WHERE lcp.period_ref=:period_ref;
