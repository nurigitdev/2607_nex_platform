-- Procurement commitment vs recognized actual
SELECT
    pc.project_id,
    SUM(pc.committed_amount) AS commitment_amount,
    SUM(pc.recognized_actual_amount) AS recognized_actual_amount,
    SUM(pc.open_commitment_amount) AS open_commitment_amount,
    SUM(pc.committed_amount)
      - SUM(pc.recognized_actual_amount)
      - SUM(pc.cancelled_amount)
      - SUM(pc.open_commitment_amount) AS reconciliation_difference
FROM nex_eos.project_commitment pc
WHERE pc.project_id=:project_id
GROUP BY pc.project_id;
