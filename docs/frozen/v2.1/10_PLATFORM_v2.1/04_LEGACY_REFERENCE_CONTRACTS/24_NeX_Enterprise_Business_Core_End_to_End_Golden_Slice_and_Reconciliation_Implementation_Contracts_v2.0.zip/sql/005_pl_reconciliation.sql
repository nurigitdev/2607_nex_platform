-- Ledger facts -> project_pl_period DIRECT/ROLLUP reconciliation
-- DIRECT expected is recomputed from immutable LedgerEntry facts.
WITH expected AS (
  SELECT
    le.project_id,le.period_id,le.currency,
    SUM(CASE WHEN le.category='REVENUE' THEN CASE WHEN le.side='CREDIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS revenue,
    SUM(CASE WHEN le.category='LABOR' THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS labor,
    SUM(CASE WHEN le.category='MATERIAL' THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS material,
    SUM(CASE WHEN le.category='DIRECT_EXPENSE' THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS direct_expense,
    SUM(CASE WHEN le.category='COMMON_COST' THEN CASE WHEN le.side='DEBIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS common_cost,
    SUM(CASE WHEN le.category='ADJUSTMENT' THEN CASE WHEN le.side='CREDIT' THEN le.amount ELSE -le.amount END ELSE 0 END) AS adjustment_profit_effect
  FROM nex_eos.ledger_entry le
  WHERE le.project_id=:project_id AND le.period_id=:period_id
  GROUP BY le.project_id,le.period_id,le.currency
)
SELECT e.*,p.revenue AS p_revenue,p.labor AS p_labor,p.material AS p_material,
       p.direct_expense AS p_direct_expense,p.common_cost AS p_common_cost,
       p.adjustment_profit_effect AS p_adjustment_profit_effect,p.profit
FROM expected e
JOIN nex_eos.project_pl_period p
  ON p.project_id=e.project_id AND p.period_id=e.period_id
 AND p.view_scope='DIRECT' AND p.currency=e.currency;
