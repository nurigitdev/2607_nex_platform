-- Test / Golden Slice reconciliation records
CREATE SCHEMA IF NOT EXISTS nex_test;

CREATE TABLE IF NOT EXISTS nex_test.golden_run (
    run_id                    uuid PRIMARY KEY,
    scenario_id               varchar(160) NOT NULL,
    state                     varchar(32) NOT NULL,
    project_ref               varchar(160) NOT NULL,
    period_ref                varchar(160) NOT NULL,
    final_status              varchar(16) NOT NULL,
    required_pass_count       integer NOT NULL DEFAULT 0,
    required_fail_count       integer NOT NULL DEFAULT 0,
    optional_na_count         integer NOT NULL DEFAULT 0,
    started_at                timestamptz NOT NULL DEFAULT now(),
    completed_at              timestamptz,
    context_json              jsonb NOT NULL DEFAULT '{}'::jsonb,
    CONSTRAINT ck_golden_run_state CHECK (state IN ('RUNNING','WAITING_CONVERGENCE','COMPLETED','FAILED')),
    CONSTRAINT ck_golden_final_status CHECK (final_status IN ('PASS','FAIL','WAITING'))
);

CREATE TABLE IF NOT EXISTS nex_test.golden_step_result (
    step_result_id            uuid PRIMARY KEY,
    run_id                    uuid NOT NULL REFERENCES nex_test.golden_run(run_id),
    step_id                   varchar(80) NOT NULL,
    status                    varchar(16) NOT NULL,
    commit_state              varchar(40) NOT NULL,
    operation_refs_json       jsonb NOT NULL DEFAULT '[]'::jsonb,
    source_state_json         jsonb NOT NULL DEFAULT '{}'::jsonb,
    error_code                varchar(160),
    correlation_id            varchar(128),
    started_at                timestamptz NOT NULL,
    completed_at              timestamptz,
    UNIQUE(run_id,step_id)
);

CREATE TABLE IF NOT EXISTS nex_test.reconciliation_check (
    reconciliation_check_id   uuid PRIMARY KEY,
    run_id                    uuid NOT NULL REFERENCES nex_test.golden_run(run_id),
    check_id                  varchar(160) NOT NULL,
    check_type                varchar(48) NOT NULL,
    status                    varchar(32) NOT NULL,
    required                  boolean NOT NULL,
    expected_json             jsonb,
    actual_json               jsonb,
    difference_json           jsonb,
    tolerance_json            jsonb,
    reason_codes_json         jsonb NOT NULL DEFAULT '[]'::jsonb,
    evidence_refs_json        jsonb NOT NULL DEFAULT '[]'::jsonb,
    checked_at                timestamptz NOT NULL DEFAULT now(),
    UNIQUE(run_id,check_id)
);
