# NeX Enterprise Business Core End-to-End Golden Slice & Reconciliation v2.0

Accompanies `24_NeX_Enterprise_Business_Core_End_to_End_Golden_Slice_and_Reconciliation_Design_v2.0`.

## Reference Golden Project
- NVT: NVT-10
- Mother: M-100
- Child: P-300
- Period: 2026-09
- Currency: KRW

## Expected economics
- Revenue: 25,000,000
- Procurement commitment: 7,000,000
- Purchase material actual: 6,000,000
- Open commitment: 1,000,000
- Direct expense: 840,000
- Labor: 4,000,000
- Common cost: 0
- Adjustment: 0
- Profit: 14,160,000

## Golden PASS rule
All REQUIRED reconciliation checks must be PASS:
1. Voucher balance.
2. Source economic lines ↔ Project Financial Ledger.
3. Commitment = recognized actual + cancelled + open commitment.
4. Labor cost pool = allocation = LABOR ledger.
5. DIRECT P/L matches expected economics.
6. Mother/NVT ROLLUP matches the Child dataset for this isolated fixture.
7. Financial lineage complete.
8. Idempotent command/event behavior produces no duplicate economic effect.
9. Project P/L projection watermark has converged to authoritative ledger.

Legacy dual-run is optional. If configured, a mismatch is surfaced but never triggers automatic dual-write or data correction.

## Important
- This is a target/reference integration harness, not a claim about current repository implementation.
- Test execution should use isolated resettable PostgreSQL databases and canonical service APIs.
- Reference SQL has not been run against the user's actual development database.
