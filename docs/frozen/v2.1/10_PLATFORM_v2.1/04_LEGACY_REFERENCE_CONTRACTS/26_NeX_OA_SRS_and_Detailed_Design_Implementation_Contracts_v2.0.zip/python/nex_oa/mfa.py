from __future__ import annotations
from datetime import timedelta
from typing import Any, Mapping
import secrets, hashlib

class MFAService:
    def __init__(self, authenticators, secrets_store, channel_provider, webauthn,
                 audit, id_generator, clock, policy):
        self.authenticators=authenticators; self.secret_store=secrets_store
        self.channel_provider=channel_provider; self.webauthn=webauthn
        self.audit=audit; self.ids=id_generator; self.clock=clock; self.policy=policy

    async def create_oob_challenge(self, *, principal:Mapping[str,Any], authenticator:Mapping[str,Any],
                                   purpose:str, correlation_id:str)->dict[str,Any]:
        if authenticator["authenticator_type"] not in {"SMS_OOB","KAKAO_OOB"}:
            raise ValueError("NOT_OOB_AUTHENTICATOR")
        code=f"{secrets.randbelow(1000000):06d}"
        salt=secrets.token_bytes(16)
        challenge_hash=hashlib.sha256(salt+code.encode()).hexdigest()
        now=self.clock.now()
        challenge={
            "challenge_id":self.ids.new_id(),"principal_ref":{"entity_type":"PRINCIPAL","entity_id":principal["principal_id"]},
            "authenticator_ref":{"entity_type":"AUTHENTICATOR","entity_id":authenticator["authenticator_id"]},
            "purpose":purpose,"factor_type":authenticator["authenticator_type"],"status":"CREATED",
            "challenge_hash":challenge_hash,"_salt_b64":salt.hex(),"attempt_count":0,
            "max_attempts":self.policy.oob_max_attempts,
            "expires_at":(now+timedelta(seconds=self.policy.oob_ttl_seconds)).isoformat(),
            "created_at":now.isoformat(),"correlation_id":correlation_id
        }
        delivery=await self.channel_provider.send_challenge(
            channel=authenticator["authenticator_type"],
            destination_ref=authenticator["bound_contact_ref"],
            message_template="NEX_MFA_OTP",secret=code,correlation_id=correlation_id
        )
        challenge["status"]="SENT"; challenge["channel_delivery_ref"]=delivery["delivery_ref"]
        await self.audit.append("MFA_CHALLENGE_SENT",{"principal_id":principal["principal_id"],
                                                       "factor_type":authenticator["authenticator_type"],
                                                       "correlation_id":correlation_id})
        return challenge

    def verify_oob_code(self, challenge:Mapping[str,Any], code:str)->bool:
        if challenge["status"] not in {"CREATED","SENT","PRESENTED"}:
            return False
        salt=bytes.fromhex(challenge["_salt_b64"])
        return secrets.compare_digest(
            hashlib.sha256(salt+code.encode()).hexdigest(),
            challenge["challenge_hash"]
        )
