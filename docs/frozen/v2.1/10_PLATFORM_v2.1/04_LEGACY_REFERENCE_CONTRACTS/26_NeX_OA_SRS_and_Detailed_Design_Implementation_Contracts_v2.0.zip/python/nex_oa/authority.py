from __future__ import annotations
from datetime import timedelta
from typing import Mapping, Any
import hashlib, json

def canonical_hash(v):
    return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(",",":")).encode()).hexdigest()

class EffectiveAuthorityBuilder:
    def __init__(self, roles, capabilities, policy, kill_switch, work_context,
                 project_scope, id_generator, clock):
        self.roles=roles; self.capabilities=capabilities; self.policy=policy
        self.kill_switch=kill_switch; self.work_context=work_context
        self.project_scope=project_scope; self.ids=id_generator; self.clock=clock

    async def build(self, *, principal, business_actor, coworker_profile, role_binding_id,
                    capability_id, work_item_id, auth_context, human_gate_state, correlation_id):
        rb=await self.roles.get(role_binding_id)
        cap=await self.capabilities.get(capability_id)
        now=self.clock.now()
        ctx={
            "schema_version":"2.0","authority_context_id":self.ids.new_id(),
            "authenticated_principal_ref":{"entity_type":"PRINCIPAL","entity_id":principal["principal_id"]},
            "business_actor_ref":business_actor,
            "coworker_profile_ref":coworker_profile,
            "role_binding_ref":{"entity_type":"ROLE_BINDING","entity_id":rb["role_binding_id"],"version":rb["version"],"status":rb["status"]},
            "work_item_ref":{"entity_type":"WORKITEM","entity_id":work_item_id} if work_item_id else None,
            "capability_ref":{"entity_type":"CAPABILITY","entity_id":capability_id,"version":cap.get("version"),"status":cap.get("status")},
            "risk_level":cap["risk_level"],
            "org_scope_refs":rb.get("org_scope_refs",[]),
            "project_scope_refs":list(await self.project_scope.allowed_projects(rb,{"work_item_id":work_item_id})),
            "auth_context":auth_context,
            "autonomy_level":coworker_profile.get("autonomy_level") if coworker_profile else None,
            "human_gate_state":human_gate_state,
            "policy_snapshot_ref":"PENDING","issued_at":now.isoformat(),
            "valid_until":(now+timedelta(minutes=10)).isoformat(),
            "correlation_id":correlation_id,
        }
        policy=await self.policy.get_authorization_policy(ctx)
        ctx["policy_snapshot_ref"]=policy["policy_ref"]
        ctx["context_hash"]=canonical_hash({k:v for k,v in ctx.items() if k!="context_hash"})
        return ctx
