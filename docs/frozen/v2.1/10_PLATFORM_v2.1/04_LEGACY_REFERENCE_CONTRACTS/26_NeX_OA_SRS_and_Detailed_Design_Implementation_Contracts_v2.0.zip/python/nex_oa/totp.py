from __future__ import annotations
import base64, hmac, hashlib, struct, time

def generate_totp(secret:bytes, now:int|None=None, step:int=30, digits:int=6)->str:
    now=int(time.time()) if now is None else int(now)
    counter=now//step
    msg=struct.pack(">Q",counter)
    digest=hmac.new(secret,msg,hashlib.sha1).digest()
    offset=digest[-1]&0x0F
    code=(struct.unpack(">I",digest[offset:offset+4])[0]&0x7fffffff)%(10**digits)
    return str(code).zfill(digits)

def verify_totp(secret:bytes, code:str, now:int|None=None, step:int=30, digits:int=6, window:int=1)->bool:
    now=int(time.time()) if now is None else int(now)
    for w in range(-window,window+1):
        expected=generate_totp(secret,now+w*step,step,digits)
        if hmac.compare_digest(expected,code):
            return True
    return False

def base32_secret(secret:bytes)->str:
    return base64.b32encode(secret).decode("ascii").rstrip("=")
