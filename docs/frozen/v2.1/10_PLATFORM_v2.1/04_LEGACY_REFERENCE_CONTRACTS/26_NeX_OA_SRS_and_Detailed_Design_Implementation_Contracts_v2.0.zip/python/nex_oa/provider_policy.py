# Provider policy reference
# KakaoTalk generic social-message APIs are NOT assumed to be enterprise OTP delivery APIs.
# KAKAO_OOB is enabled only when a contracted/approved provider can prove recipient binding,
# delivery status, privacy requirements and operational support for authentication messages.
# Kakao Login OIDC may be configured as EXTERNAL_OIDC, with issuer/audience/nonce/signature verification.
#
# SMS_OOB is fallback/recovery only by default; a non-PSTN alternative must be available.
# TOTP is the default software possession factor.
# WebAuthn is preferred for privileged/admin/high-risk step-up when available.
#
# Email OTP is intentionally excluded as an out-of-band authentication factor.
