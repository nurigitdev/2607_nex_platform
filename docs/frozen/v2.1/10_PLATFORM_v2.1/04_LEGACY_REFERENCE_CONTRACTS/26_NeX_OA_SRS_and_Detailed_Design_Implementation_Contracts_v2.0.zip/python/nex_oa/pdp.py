from __future__ import annotations
from typing import Mapping,Any

RISK_ORDER={"R0":0,"R1":1,"R2":2,"R3":3,"R4":4,"R5":5}
AUTH_ORDER={"AAL1_EQUIVALENT":1,"AAL2_EQUIVALENT":2,"PHISHING_RESISTANT":3,"SERVICE_STRONG":3}

class AuthorizationPDP:
    def __init__(self, policy_store, kill_switch, id_generator, clock, audit):
        self.policy_store=policy_store; self.kill_switch=kill_switch
        self.ids=id_generator; self.clock=clock; self.audit=audit

    async def decide(self, *, authority_context:Mapping[str,Any], resource_refs:list[Mapping[str,Any]]):
        policy=await self.policy_store.get_authorization_policy({
            "authority_context":authority_context,"resource_refs":resource_refs
        })
        reasons=[]
        rb=authority_context["role_binding_ref"]
        if rb.get("status")!="ACTIVE":
            reasons.append("ROLE_BINDING_NOT_ACTIVE")
        if RISK_ORDER[authority_context["risk_level"]] > RISK_ORDER[policy["risk_ceiling"]]:
            reasons.append("RISK_CEILING_EXCEEDED")
        required=policy["required_auth_level"]
        if AUTH_ORDER[authority_context["auth_context"]["auth_level"]] < AUTH_ORDER[required]:
            reasons.append("AUTH_LEVEL_INSUFFICIENT")
        if policy.get("step_up_required") and not authority_context["auth_context"]["step_up_satisfied"]:
            reasons.append("STEP_UP_REQUIRED")
        ks=await self.kill_switch.check({"capability_ref":authority_context["capability_ref"],
                                         "coworker_profile_ref":authority_context.get("coworker_profile_ref")})
        if ks.get("blocked"):
            reasons.append("KILL_SWITCH_BLOCKED")
        allowed=not reasons
        decision={
            "schema_version":"2.0","decision_id":self.ids.new_id(),"allowed":allowed,
            "reason_codes":reasons,
            "principal_ref":authority_context["authenticated_principal_ref"],
            "business_actor_ref":authority_context["business_actor_ref"],
            "role_binding_ref":authority_context["role_binding_ref"],
            "capability_ref":authority_context["capability_ref"],
            "resource_refs":resource_refs,"risk_level":authority_context["risk_level"],
            "required_auth_level":required,"step_up_required":policy.get("step_up_required",False),
            "human_gate_required":policy.get("human_gate_required","NONE"),
            "policy_ref":policy["policy_ref"],"decided_at":self.clock.now().isoformat(),
            "correlation_id":authority_context["correlation_id"]
        }
        await self.audit.append("AUTHORIZATION_DECISION",decision)
        return decision
