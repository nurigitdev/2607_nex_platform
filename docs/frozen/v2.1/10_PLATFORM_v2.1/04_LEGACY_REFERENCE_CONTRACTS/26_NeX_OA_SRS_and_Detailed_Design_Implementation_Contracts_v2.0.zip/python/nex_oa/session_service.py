from __future__ import annotations
from datetime import timedelta
import secrets, hashlib

class SessionService:
    def __init__(self, sessions, refresh_tokens, signer, audit, id_generator, clock, policy):
        self.sessions=sessions; self.refresh_tokens=refresh_tokens; self.signer=signer
        self.audit=audit; self.ids=id_generator; self.clock=clock; self.policy=policy

    async def issue(self, *, principal, business_actor, coworker_profile, authenticators,
                    auth_level, correlation_id):
        now=self.clock.now()
        family=self.ids.new_id()
        session={
            "schema_version":"2.0","session_id":self.ids.new_id(),
            "principal_ref":{"entity_type":"PRINCIPAL","entity_id":principal["principal_id"]},
            "business_actor_ref":business_actor,
            "coworker_profile_ref":coworker_profile,
            "status":"ACTIVE","auth_level":auth_level,
            "authenticator_refs":[{"entity_type":"AUTHENTICATOR","entity_id":x["authenticator_id"]} for x in authenticators],
            "step_up_valid_until":None,"issued_at":now.isoformat(),"last_activity_at":now.isoformat(),
            "idle_expires_at":(now+timedelta(seconds=self.policy.idle_timeout_seconds(auth_level))).isoformat(),
            "absolute_expires_at":(now+timedelta(seconds=self.policy.absolute_timeout_seconds(auth_level))).isoformat(),
            "token_family_id":family,"correlation_id":correlation_id
        }
        created=await self.sessions.create(session)
        refresh=secrets.token_urlsafe(48)
        refresh_hash=hashlib.sha256(refresh.encode()).hexdigest()
        await self.refresh_tokens.rotate(family,"",refresh_hash,
            now+timedelta(seconds=self.policy.refresh_token_ttl_seconds))
        access=await self.signer.sign_access_token({
            "sid":created["session_id"],"sub":principal["principal_id"],
            "actor":business_actor["entity_id"],"auth_level":auth_level,
            "token_family_id":family
        },self.policy.access_token_ttl_seconds)
        return {"session":created,"access_token":access,"refresh_token":refresh}

    async def revoke_for_security_event(self, session_id, reason):
        s=await self.sessions.get(session_id)
        await self.sessions.revoke_family(s["token_family_id"],reason)
        await self.audit.append("SESSION_REVOKED",{"session_id":session_id,"reason":reason})
