from __future__ import annotations
from enum import StrEnum
from pydantic import BaseModel, ConfigDict

class PrincipalType(StrEnum):
    HUMAN_USER="HUMAN_USER"; SERVICE_ACCOUNT="SERVICE_ACCOUNT"; SYSTEM_JOB="SYSTEM_JOB"
    EXTERNAL_AGENT="EXTERNAL_AGENT"; ADMIN_OPERATOR="ADMIN_OPERATOR"

class AuthenticatorType(StrEnum):
    PASSWORD="PASSWORD"; TOTP="TOTP"; SMS_OOB="SMS_OOB"; KAKAO_OOB="KAKAO_OOB"
    WEBAUTHN="WEBAUTHN"; RECOVERY_CODE="RECOVERY_CODE"; EXTERNAL_OIDC="EXTERNAL_OIDC"

class AuthLevel(StrEnum):
    AAL1_EQUIVALENT="AAL1_EQUIVALENT"
    AAL2_EQUIVALENT="AAL2_EQUIVALENT"
    PHISHING_RESISTANT="PHISHING_RESISTANT"
    SERVICE_STRONG="SERVICE_STRONG"

class EntityRef(BaseModel):
    model_config=ConfigDict(extra="forbid", frozen=True)
    entity_type:str; entity_id:str; version:str|int|None=None; status:str|None=None
