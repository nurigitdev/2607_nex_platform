CREATE TABLE IF NOT EXISTS nex_oa.session (
    session_id              uuid PRIMARY KEY,
    principal_id            uuid NOT NULL REFERENCES nex_oa.principal(principal_id),
    business_actor_ref      varchar(160) NOT NULL,
    coworker_profile_id     uuid REFERENCES nex_oa.coworker_profile(coworker_profile_id),
    status                  varchar(24) NOT NULL,
    auth_level              varchar(32) NOT NULL,
    authenticator_refs_json jsonb NOT NULL,
    step_up_valid_until     timestamptz,
    issued_at               timestamptz NOT NULL,
    last_activity_at        timestamptz NOT NULL,
    idle_expires_at         timestamptz NOT NULL,
    absolute_expires_at     timestamptz NOT NULL,
    token_family_id         uuid NOT NULL,
    correlation_id          varchar(128) NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_session_principal_active
    ON nex_oa.session(principal_id,status,absolute_expires_at);

CREATE TABLE IF NOT EXISTS nex_oa.refresh_token (
    token_family_id         uuid NOT NULL,
    token_id                uuid PRIMARY KEY,
    session_id              uuid NOT NULL REFERENCES nex_oa.session(session_id),
    token_hash              char(64) NOT NULL,
    status                  varchar(24) NOT NULL,
    issued_at               timestamptz NOT NULL,
    expires_at              timestamptz NOT NULL,
    rotated_from_token_id   uuid,
    revoked_at              timestamptz,
    revocation_reason       text
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_active_refresh_token_family
    ON nex_oa.refresh_token(token_family_id)
    WHERE status='ACTIVE';

-- Access tokens are short-lived signed tokens; store audit/JTI only when needed,
-- not raw bearer token values.
