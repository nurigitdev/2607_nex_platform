CREATE SCHEMA IF NOT EXISTS nex_oa;

CREATE TABLE IF NOT EXISTS nex_oa.principal (
    principal_id            uuid PRIMARY KEY,
    principal_type          varchar(32) NOT NULL,
    status                  varchar(24) NOT NULL,
    subject_type            varchar(80) NOT NULL,
    subject_id              varchar(160) NOT NULL,
    auth_source             varchar(32) NOT NULL,
    login_name              varchar(160),
    primary_email           varchar(320),
    mobile_number_ref       varchar(256),
    last_authenticated_at   timestamptz,
    version                 bigint NOT NULL DEFAULT 0,
    created_at              timestamptz NOT NULL DEFAULT now(),
    updated_at              timestamptz NOT NULL DEFAULT now(),
    UNIQUE(login_name),
    UNIQUE(subject_type,subject_id),
    CONSTRAINT ck_principal_type CHECK (
      principal_type IN ('HUMAN_USER','SERVICE_ACCOUNT','SYSTEM_JOB','EXTERNAL_AGENT','ADMIN_OPERATOR')
    ),
    CONSTRAINT ck_principal_status CHECK (
      status IN ('PROVISIONED','ACTIVE','SUSPENDED','LOCKED','DISABLED','TERMINATED')
    )
);

CREATE TABLE IF NOT EXISTS nex_oa.coworker_profile (
    coworker_profile_id     uuid PRIMARY KEY,
    employee_ref            varchar(160) NOT NULL UNIQUE,
    status                  varchar(24) NOT NULL,
    autonomy_level          varchar(32) NOT NULL,
    default_execution_mode  varchar(32) NOT NULL,
    prompt_overlay_ref      varchar(256),
    policy_profile_ref      varchar(256) NOT NULL,
    preferred_model_profile varchar(160),
    version                 bigint NOT NULL DEFAULT 0,
    created_at              timestamptz NOT NULL DEFAULT now(),
    updated_at              timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_oa.role_binding (
    role_binding_id         uuid PRIMARY KEY,
    employee_ref            varchar(160) NOT NULL,
    coworker_profile_id     uuid REFERENCES nex_oa.coworker_profile(coworker_profile_id),
    role_ref                varchar(160) NOT NULL,
    status                  varchar(24) NOT NULL,
    org_scope_refs_json     jsonb NOT NULL DEFAULT '[]'::jsonb,
    project_scope_refs_json jsonb NOT NULL DEFAULT '[]'::jsonb,
    capability_scope_refs_json jsonb NOT NULL DEFAULT '[]'::jsonb,
    risk_ceiling            varchar(8) NOT NULL,
    effective_from          timestamptz NOT NULL,
    effective_to            timestamptz,
    source_type             varchar(32) NOT NULL,
    source_ref              varchar(256),
    version                 bigint NOT NULL DEFAULT 0,
    created_at              timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_role_binding_employee_active
    ON nex_oa.role_binding(employee_ref,status,effective_from,effective_to);
