-- Lifecycle / revocation reference

-- Employee termination/suspension:
-- 1) principal -> DISABLED/TERMINATED
-- 2) coworker_profile -> DISABLED/TERMINATED
-- 3) role_binding -> REVOKED/EXPIRED
-- 4) revoke all OA sessions / refresh-token families
-- 5) future background Effective Authority construction fails closed
-- 6) active background execution Resume reauthorizes and is blocked if authority revoked

-- MFA reset:
-- revoke target authenticator; require strong authenticated recovery/binding flow.
-- SMS/Kakao contact change is binding of a new authenticator contact, not a profile-edit shortcut.

-- Refresh token rotation:
-- each successful refresh revokes/rotates previous token in the family.
-- replay of a revoked refresh token revokes the entire family as suspected compromise.
