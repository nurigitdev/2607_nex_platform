CREATE TABLE IF NOT EXISTS nex_oa.authenticator (
    authenticator_id        uuid PRIMARY KEY,
    principal_id            uuid NOT NULL REFERENCES nex_oa.principal(principal_id),
    authenticator_type      varchar(32) NOT NULL,
    status                  varchar(24) NOT NULL,
    display_name            varchar(200),
    assurance_class         varchar(32) NOT NULL,
    phishing_resistant      boolean NOT NULL DEFAULT false,
    secret_ref              varchar(256),
    external_subject        varchar(512),
    provider_ref            varchar(160),
    bound_contact_ref       varchar(256),
    metadata_json           jsonb NOT NULL DEFAULT '{}'::jsonb,
    bound_at                timestamptz NOT NULL,
    last_used_at            timestamptz,
    version                 bigint NOT NULL DEFAULT 0,
    CONSTRAINT ck_authenticator_type CHECK (
      authenticator_type IN ('PASSWORD','TOTP','SMS_OOB','KAKAO_OOB','WEBAUTHN','RECOVERY_CODE','EXTERNAL_OIDC')
    )
);
CREATE INDEX IF NOT EXISTS ix_authenticator_principal_active
    ON nex_oa.authenticator(principal_id,status,authenticator_type);

CREATE TABLE IF NOT EXISTS nex_oa.mfa_challenge (
    challenge_id            uuid PRIMARY KEY,
    principal_id            uuid NOT NULL REFERENCES nex_oa.principal(principal_id),
    authenticator_id        uuid REFERENCES nex_oa.authenticator(authenticator_id),
    purpose                 varchar(32) NOT NULL,
    factor_type             varchar(32) NOT NULL,
    status                  varchar(24) NOT NULL,
    challenge_hash          char(64) NOT NULL,
    challenge_salt_ref      varchar(256),
    channel_delivery_ref    varchar(256),
    attempt_count           integer NOT NULL DEFAULT 0,
    max_attempts            integer NOT NULL,
    expires_at              timestamptz NOT NULL,
    satisfied_at            timestamptz,
    correlation_id          varchar(128) NOT NULL,
    created_at              timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_mfa_challenge_principal
    ON nex_oa.mfa_challenge(principal_id,status,expires_at);
