CREATE TABLE IF NOT EXISTS nex_oa.service_account (
    service_account_id      uuid PRIMARY KEY,
    principal_id            uuid NOT NULL UNIQUE REFERENCES nex_oa.principal(principal_id),
    service_name            varchar(160) NOT NULL UNIQUE,
    status                  varchar(24) NOT NULL,
    credential_type         varchar(32) NOT NULL,
    secret_ref              varchar(256),
    certificate_thumbprint  varchar(256),
    allowed_audiences_json  jsonb NOT NULL DEFAULT '[]'::jsonb,
    allowed_capability_refs_json jsonb NOT NULL DEFAULT '[]'::jsonb,
    token_ttl_seconds       integer NOT NULL,
    version                 bigint NOT NULL DEFAULT 0,
    created_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_service_ttl CHECK (token_ttl_seconds BETWEEN 60 AND 3600)
);

CREATE TABLE IF NOT EXISTS nex_oa.auth_event (
    auth_event_id           uuid PRIMARY KEY,
    event_name              varchar(128) NOT NULL,
    principal_id            uuid,
    business_actor_ref      varchar(160),
    session_id              uuid,
    authenticator_id        uuid,
    factor_type             varchar(32),
    outcome                 varchar(24) NOT NULL,
    source_ip_hash          char(64),
    user_agent_hash         char(64),
    reason_codes_json       jsonb NOT NULL DEFAULT '[]'::jsonb,
    correlation_id          varchar(128) NOT NULL,
    occurred_at             timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_oa.authorization_decision_audit (
    decision_id             uuid PRIMARY KEY,
    allowed                 boolean NOT NULL,
    principal_ref           varchar(160) NOT NULL,
    business_actor_ref      varchar(160) NOT NULL,
    role_binding_ref        varchar(160) NOT NULL,
    capability_ref          varchar(160) NOT NULL,
    resource_refs_json      jsonb NOT NULL DEFAULT '[]'::jsonb,
    risk_level              varchar(8) NOT NULL,
    required_auth_level     varchar(32) NOT NULL,
    step_up_required        boolean NOT NULL,
    human_gate_required     varchar(32) NOT NULL,
    policy_ref              varchar(256) NOT NULL,
    reason_codes_json       jsonb NOT NULL DEFAULT '[]'::jsonb,
    correlation_id          varchar(128) NOT NULL,
    decided_at              timestamptz NOT NULL DEFAULT now()
);
