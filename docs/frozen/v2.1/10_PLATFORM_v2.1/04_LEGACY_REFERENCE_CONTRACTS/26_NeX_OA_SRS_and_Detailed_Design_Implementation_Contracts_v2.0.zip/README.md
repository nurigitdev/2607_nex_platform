# NeX-OA SRS & Detailed Design v2.0 Reference Package

Core decisions:
1. Authentication Principal != Business Actor != Effective Authority.
2. Employee logically owns exactly one Persistent Coworker Profile; Employee may have RoleBinding 1:N.
3. Background workers authenticate as SERVICE_ACCOUNT and never reuse an Employee browser token.
4. EffectiveAuthorityContext is short-lived, server-built and capability/work/scope bound.
5. Current PDP authorization is evaluated again at Resume and immediately before important side effects.
6. TOTP (RFC 6238) is the default software second factor.
7. WebAuthn/passkey is preferred for privileged/admin/high-risk phishing-resistant authentication.
8. SMS OTP is a fallback/recovery OOB channel, not the sole MFA strategy; an alternative factor must exist.
9. KakaoTalk OOB is a provider adapter. Do not assume the generic Kakao social-message API is an enterprise OTP transport. Kakao Login OIDC is separately modeled as EXTERNAL_OIDC.
10. Email OTP is excluded as an OOB authentication factor.
11. Refresh tokens rotate; replay/reuse revokes the token family.
12. Raw authenticator secrets/tokens are never stored in business/audit objects; only secret_ref or hashes.
13. R4/R5 can require step-up auth in addition to Human Gate. Step-up authentication and business approval are distinct.
14. OA is logical PDP; AG owns policy administration. AE/WC/EOS/WA/adapters are PEPs.
15. Actual production IdP/SMS/Kakao providers and DR details remain deploy-time configuration.

External standards/design references used:
- NIST SP 800-63B-4 (2025): authenticator requirements; PSTN OOB is restricted; alternative authenticators should be available; phishing-resistant option at AAL2.
- RFC 6238: TOTP.
- W3C WebAuthn Level 3 (2026 CR): scoped public-key credentials.
- Kakao Login official docs: OIDC support, ID-token verification.
- KakaoTalk Message official docs: generic message APIs are permission/service-user constrained; this package does not treat them as a universal OTP transport.

All JSON schemas/examples and Python syntax are validated during artifact generation.
