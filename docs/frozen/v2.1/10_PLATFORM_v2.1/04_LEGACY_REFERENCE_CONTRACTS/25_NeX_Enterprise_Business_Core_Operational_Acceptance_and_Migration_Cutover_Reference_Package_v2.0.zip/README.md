# NeX Enterprise Business Core Operational Acceptance / Migration Cutover v2.0

This package accompanies Document 25.

Core rules:
- Phase 2 Exit Gate is CUTOVER_CANDIDATE, not automatic production go-live.
- All HARD gates must PASS. HARD gates cannot be waived.
- SOFT gates may use time-bounded approved exceptions only when allowed.
- Golden/reconciliation/security/recovery/writer-fencing/failback are HARD gates.
- DUAL_RUN_VALIDATION != DUAL_WRITE. Exactly one authoritative writer exists per domain.
- Writer fencing is enforced at canonical routing/adapter/service level, not just UI.
- Cutover is not complete at route switch; production-safe smoke + observation + reconciliation are required.
- Failback is not database rollback. If NeX already committed transactions, freeze writes and reconcile/sync delta before selecting one writer.
- Immutable Ledger facts are never deleted/overwritten to make systems look equal.
- Actual Deployment/DR details are finalized in Phase 4; this is the Phase 2 acceptance/cutover contract baseline.
