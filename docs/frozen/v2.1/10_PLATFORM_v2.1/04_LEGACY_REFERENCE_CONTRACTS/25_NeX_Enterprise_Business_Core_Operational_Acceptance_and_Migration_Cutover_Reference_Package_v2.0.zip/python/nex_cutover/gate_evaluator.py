from __future__ import annotations
from typing import Any, Mapping, Sequence

def evaluate_operational_gates(gates:Sequence[Mapping[str,Any]],
                               valid_exceptions:Mapping[str,Mapping[str,Any]]) -> dict[str,Any]:
    hard_fail=[]
    soft_fail=[]
    soft_exception=[]
    not_evaluated=[]
    for g in gates:
        status=g["status"]
        if status in {"NOT_EVALUATED","IN_PROGRESS"}:
            not_evaluated.append(g["gate_id"])
            continue
        if status=="FAIL":
            (hard_fail if g["severity"]=="HARD" or not g.get("allowed_exception",False) else soft_fail).append(g["gate_id"])
        elif status=="PASS_WITH_APPROVED_EXCEPTION":
            exc=valid_exceptions.get(g.get("exception_ref"))
            if g["severity"]=="HARD" or not g.get("allowed_exception",False):
                hard_fail.append(g["gate_id"])
            elif not exc or exc["status"]!="OPEN":
                soft_fail.append(g["gate_id"])
            else:
                soft_exception.append(g["gate_id"])
    if hard_fail or soft_fail or not_evaluated:
        decision="NO_GO"
    elif soft_exception:
        decision="GO_WITH_APPROVED_EXCEPTIONS"
    else:
        decision="GO"
    return {
        "decision":decision,"hard_fail":hard_fail,"soft_fail":soft_fail,
        "soft_exception":soft_exception,"not_evaluated":not_evaluated
    }
