from __future__ import annotations
ALLOWED={
 "LEGACY":{"READ_SYNC"},
 "READ_SYNC":{"DUAL_RUN_VALIDATION","LEGACY"},
 "DUAL_RUN_VALIDATION":{"NEW_SYSTEM","READ_SYNC"},
 "NEW_SYSTEM":{"LEGACY_READ_ONLY"},
 "LEGACY_READ_ONLY":{"ARCHIVED","NEW_SYSTEM"},
 "ARCHIVED":set(),
}
def assert_sor_transition(current:str,target:str)->None:
    if target not in ALLOWED.get(current,set()):
        raise ValueError(f"INVALID_SOR_TRANSITION:{current}->{target}")

def assert_single_writer(record:dict)->None:
    state=record["state"]; writer=record["authoritative_writer"]
    expected={
      "LEGACY":"LEGACY","READ_SYNC":"LEGACY","DUAL_RUN_VALIDATION":"LEGACY",
      "NEW_SYSTEM":"NEX","LEGACY_READ_ONLY":"NEX","ARCHIVED":"NEX"
    }[state]
    if writer!=expected:
        raise ValueError(f"AUTHORITATIVE_WRITER_MISMATCH:{state}:{writer}")
