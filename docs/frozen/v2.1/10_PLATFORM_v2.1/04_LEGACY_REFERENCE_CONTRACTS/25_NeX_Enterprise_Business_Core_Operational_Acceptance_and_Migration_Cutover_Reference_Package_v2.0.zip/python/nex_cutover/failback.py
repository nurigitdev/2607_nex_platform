from __future__ import annotations
from typing import Any, Mapping

def classify_failback(context:Mapping[str,Any])->dict[str,Any]:
    """Failback is not database rollback."""
    if not context.get("writer_switched",False):
        return {"class":"FB-0","action":"ABORT_BEFORE_SWITCH","requires_delta_reconcile":False}
    committed=int(context.get("nex_committed_transactions_after_switch",0))
    if committed==0:
        return {"class":"FB-1","action":"FENCE_NEX_AND_SWITCH_ROUTE_BACK","requires_delta_reconcile":False}
    return {
        "class":"FB-2",
        "action":"FREEZE_ALL_WRITES_RECONCILE_NEX_DELTA_SYNC_TO_TARGET_THEN_DECIDE_WRITER",
        "requires_delta_reconcile":True,
        "warning":"Never enable both writers and never delete committed financial facts to simulate rollback."
    }
