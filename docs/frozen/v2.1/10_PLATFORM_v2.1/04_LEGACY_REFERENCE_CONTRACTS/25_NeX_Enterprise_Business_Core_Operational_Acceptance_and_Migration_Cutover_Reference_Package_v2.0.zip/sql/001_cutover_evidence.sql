-- Reference operational cutover evidence model (final operational schema belongs to Phase 4)
CREATE SCHEMA IF NOT EXISTS nex_ops;

CREATE TABLE IF NOT EXISTS nex_ops.cutover_run (
    cutover_id              uuid PRIMARY KEY,
    release_ref             varchar(256) NOT NULL,
    state                   varchar(32) NOT NULL,
    target_window_start     timestamptz NOT NULL,
    target_window_end       timestamptz NOT NULL,
    domains_json            jsonb NOT NULL,
    started_at              timestamptz,
    completed_at            timestamptz,
    final_decision          varchar(40),
    created_at              timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_ops.cutover_check (
    check_id                uuid PRIMARY KEY,
    cutover_id              uuid NOT NULL REFERENCES nex_ops.cutover_run(cutover_id),
    gate_id                 varchar(16) NOT NULL,
    status                  varchar(32) NOT NULL,
    blocking                boolean NOT NULL,
    actual_json             jsonb,
    expected_json           jsonb,
    reason_codes_json       jsonb NOT NULL DEFAULT '[]'::jsonb,
    evidence_refs_json      jsonb NOT NULL DEFAULT '[]'::jsonb,
    checked_by_ref          varchar(160),
    checked_at              timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_ops.sor_transition (
    domain                  varchar(80) PRIMARY KEY,
    state                   varchar(32) NOT NULL,
    authoritative_writer    varchar(16) NOT NULL,
    readers_json            jsonb NOT NULL,
    mapping_snapshot_ref    varchar(256),
    reconciliation_ref      varchar(256),
    writer_fence_token_ref  varchar(256),
    version                 bigint NOT NULL DEFAULT 0,
    updated_at              timestamptz NOT NULL DEFAULT now()
);
