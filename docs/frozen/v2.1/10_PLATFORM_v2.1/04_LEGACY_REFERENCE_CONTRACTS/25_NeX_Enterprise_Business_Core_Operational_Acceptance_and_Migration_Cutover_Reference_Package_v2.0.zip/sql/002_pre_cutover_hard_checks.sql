-- Reference pre-cutover hard reconciliation checks
-- 1) No unresolved financial command state in target scope.
SELECT capability_id,idempotency_key,commit_state
FROM nex_eos.command_idempotency
WHERE commit_state='UNKNOWN_COMMIT_STATE';

-- 2) No unpublished outbox backlog older than acceptance threshold.
SELECT count(*) AS overdue_outbox
FROM nex_eos.event_outbox
WHERE state='PENDING' AND available_at < now() - :max_outbox_age;

-- 3) Projection has converged.
SELECT
  (SELECT COALESCE(MAX(posting_seq),0) FROM nex_eos.ledger_posting) AS ledger_seq,
  (SELECT last_posting_seq FROM nex_eos.financial_projection_checkpoint
    WHERE projection_name='PROJECT_PL_PERIOD') AS projection_seq;

-- 4) Labor allocation has no unreconciled frozen-but-unposted batches for cutover period.
SELECT batch_id,state
FROM nex_eos.labor_allocation_batch
WHERE period_ref=:period_ref AND state IN ('CONFIRMED','ADJUSTMENT_REQUIRED');

-- These are hard operational checks; any unexplained row is NO-GO until resolved.
