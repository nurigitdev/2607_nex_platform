-- Writer fencing invariant
-- Never rely only on UI hiding. Canonical command routing and/or legacy write adapter must enforce the fence.
-- A transition record is changed only after external fence/switch action succeeds.

-- Example transition after writer switch:
BEGIN;
SELECT * FROM nex_ops.sor_transition WHERE domain=:domain FOR UPDATE;

UPDATE nex_ops.sor_transition
   SET state='NEW_SYSTEM',
       authoritative_writer='NEX',
       writer_fence_token_ref=:legacy_write_fence_ref,
       reconciliation_ref=:reconciliation_ref,
       version=version+1,
       updated_at=now()
 WHERE domain=:domain
   AND state='DUAL_RUN_VALIDATION'
   AND authoritative_writer='LEGACY'
   AND version=:expected_version;
COMMIT;

-- Legacy remains readable, but all target-domain writes are rejected/fenced.
