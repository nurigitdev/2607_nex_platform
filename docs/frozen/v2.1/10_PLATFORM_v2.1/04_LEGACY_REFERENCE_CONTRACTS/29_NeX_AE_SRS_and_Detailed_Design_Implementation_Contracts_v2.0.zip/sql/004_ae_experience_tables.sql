CREATE SCHEMA IF NOT EXISTS nex_ae;

CREATE TABLE nex_ae.ae_agent_session (
  session_id uuid PRIMARY KEY,
  principal_ref text NOT NULL,
  business_actor_ref text NOT NULL,
  coworker_profile_ref text NOT NULL,
  active_role_context_ref text,
  current_project_ref text,
  current_document_ref text,
  conversation_ref text,
  context_version integer NOT NULL DEFAULT 1,
  ui_state jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE nex_ae.ae_conversation_thread (
  conversation_id uuid PRIMARY KEY,
  session_owner_ref text NOT NULL,
  title text,
  project_ref text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE nex_ae.ae_message (
  message_id uuid PRIMARY KEY,
  conversation_id uuid NOT NULL REFERENCES nex_ae.ae_conversation_thread(conversation_id),
  role text NOT NULL,
  content_text text,
  classified_content_ref text,
  execution_id uuid,
  sequence_no bigint NOT NULL,
  prompt_asset_ref text,
  model_ref text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE nex_ae.ae_interaction (
  interaction_id uuid PRIMARY KEY,
  session_id uuid NOT NULL REFERENCES nex_ae.ae_agent_session(session_id),
  request_message_id uuid,
  response_message_id uuid,
  execution_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
  work_item_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
  artifact_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
  evidence_bundle_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  is_reportable boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE nex_ae.ae_notification (
  notification_id uuid PRIMARY KEY,
  principal_ref text NOT NULL,
  notification_type text NOT NULL,
  target_ref jsonb NOT NULL,
  safe_summary text,
  dedup_key text NOT NULL UNIQUE,
  read_at timestamptz,
  handled_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE nex_ae.ae_artifact_ref (
  artifact_ref_id uuid PRIMARY KEY,
  artifact_ref text NOT NULL,
  source_execution_id uuid,
  source_work_item_ref text,
  evidence_bundle_ref text,
  provenance jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE nex_ae.ae_citation_ref (
  citation_ref_id uuid PRIMARY KEY,
  message_id uuid,
  artifact_ref_id uuid,
  evidence_bundle_ref text NOT NULL,
  citation_label text NOT NULL,
  source_locator jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
