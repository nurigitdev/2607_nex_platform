# NeX-AE Golden Scenarios

1. Interactive evidence-grounded response with inline citation.
2. Interactive request continues as background Coworker after browser close.
3. Parent/Child WC delegation waits and resumes after reauthorization.
4. Confirmation is distinct from formal approval and OA step-up.
5. CX evidence conflict/insufficiency is visible.
6. Graph-lite relation is displayed only with authorized supporting evidence.
7. Stream disconnect does not cancel business execution.
8. Revocation during wait blocks resume side effect.
9. Runtime SUCCEEDED is not rendered as WC CLOSED unless WC is CLOSED.
10. Interaction/work result produces reviewable daily/weekly report draft.
