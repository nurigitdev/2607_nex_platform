# 29_NeX_AE_SRS_and_Detailed_Design_v2.0 Implementation Contracts

Frozen parent baseline: Document 11 Runtime SRS + Document 12 Detailed Design.
This package defines only NeX-AE product surface contracts: AgentSession, Workspace, Stream, Human Gate View, Notification, Interaction and reference persistence/API.
