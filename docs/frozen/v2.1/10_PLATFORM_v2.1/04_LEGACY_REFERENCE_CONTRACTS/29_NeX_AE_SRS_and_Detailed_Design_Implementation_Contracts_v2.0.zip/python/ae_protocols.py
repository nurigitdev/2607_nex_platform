from typing import Protocol, AsyncIterator
from dataclasses import dataclass

class FrozenRuntimeFacade(Protocol):
    async def submit_prompt(self, session_id: str, request: dict) -> str: ...
    async def get_execution_view(self, execution_id: str) -> dict: ...
    async def cancel(self, execution_id: str, reason: str) -> dict: ...

class CXEvidenceClient(Protocol):
    async def get_ae_context(self, evidence_bundle_ref: str, authority_ref: str) -> dict: ...

class MOStreamingClient(Protocol):
    async def stream(self, model_profile: str, request: dict) -> AsyncIterator[dict]: ...

class WCWorkClient(Protocol):
    async def inbox(self, principal_ref: str, filters: dict) -> list[dict]: ...
    async def get_work_item(self, work_item_ref: str) -> dict: ...

class OAClient(Protocol):
    async def current_authority(self, principal_ref: str, role_context_ref: str | None) -> dict: ...

@dataclass(frozen=True)
class RuntimeProjection:
    execution_id: str
    mode: str
    state: str
    current_step_summary: str | None
    wait_reason: str | None
    plan_summary: tuple[str, ...]
