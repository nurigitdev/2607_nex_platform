# 34 Deployment / Operation / Backup / Recovery Reference Package

This package freezes the operational contract for NeX v2.0.

Key rules:
- 33 Acceptance Evidence is a production deployment gate.
- Promote the same immutable artifact digest across environments.
- Service databases remain independent; no global runtime database is introduced.
- Backup is not VERIFIED until an isolated restore test passes.
- Cross-system recovery uses a Recovery Point Manifest plus reconciliation, not distributed 2PC.
- Rollback never erases already committed business transactions.
