# Unknown Commit Recovery
Never blind retry. Resolve operation_ref/idempotency_key against authoritative SoR and classify CONFIRMED_COMMITTED / CONFIRMED_NOT_COMMITTED / STILL_UNKNOWN / CONFLICT.
