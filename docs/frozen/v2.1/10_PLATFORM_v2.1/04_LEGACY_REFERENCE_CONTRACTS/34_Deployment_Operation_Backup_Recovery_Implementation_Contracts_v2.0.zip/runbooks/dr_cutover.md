# DR Cutover
Validate time/config/secrets, restore SoRs, start OA/core services, rebuild CX/MO/AG/WA as needed, run recovery scanners, safe smoke, then staged write enablement.
