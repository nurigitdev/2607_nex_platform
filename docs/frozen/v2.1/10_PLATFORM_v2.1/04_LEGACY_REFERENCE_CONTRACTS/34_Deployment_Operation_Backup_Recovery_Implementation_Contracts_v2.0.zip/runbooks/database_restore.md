# Database Restore
1. Freeze affected writes.
2. Select verified backup + target time.
3. Restore in isolated/staged target.
4. Validate schema/ref/integrity.
5. Reconcile outbox/inbox/open operations.
6. Smoke then staged enablement.
