# Service Down
1. Identify release/instance.
2. Check readiness/dependencies.
3. Drain/restart via typed control.
4. Verify queue/outbox/reconciliation.
5. Smoke and close incident.
