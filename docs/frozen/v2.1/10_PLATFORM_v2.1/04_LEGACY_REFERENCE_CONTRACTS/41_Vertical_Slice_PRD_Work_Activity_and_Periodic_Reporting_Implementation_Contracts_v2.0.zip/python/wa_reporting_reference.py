from dataclasses import dataclass
from typing import Iterable

@dataclass(frozen=True)
class Event:
    source_service: str
    event_id: str
    reportable: bool
    project_ref: str | None
    payload: dict

def dedup_key(e: Event) -> tuple[str,str]:
    return (e.source_service, e.event_id)

def build_fact_set(events: Iterable[Event]) -> dict:
    selected=[e for e in events if e.reportable]
    # authoritative numeric/status values must come from structured payloads;
    # no LLM calculation occurs here.
    by_project={}
    for e in selected:
        key=e.project_ref or 'UNASSIGNED'
        by_project.setdefault(key,0)
        by_project[key]+=1
    return {'activity_count':len(selected),'by_project':by_project}

def performance_evidence_eligible(*, verified_outcome: bool, technical_success: bool) -> bool:
    # Technical success alone is insufficient.
    return bool(verified_outcome)

def automatic_score(*args, **kwargs):
    raise RuntimeError('Automatic employee performance scoring is outside PRD41 and prohibited by policy')
