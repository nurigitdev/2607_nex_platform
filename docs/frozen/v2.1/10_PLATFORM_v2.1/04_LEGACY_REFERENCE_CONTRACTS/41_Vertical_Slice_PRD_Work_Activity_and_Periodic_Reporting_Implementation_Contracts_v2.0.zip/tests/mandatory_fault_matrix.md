# Mandatory Fault Matrix

- duplicate source event -> one WorkActivity
- out-of-order event -> stable Timeline
- late event before submit -> Draft stale/refresh
- late event after submit -> new revision/supersede; no mutation
- WA worker crash -> business flow unaffected + rebuild
- MO unavailable -> fact-only or explicit degraded report
- OA deny -> report/evidence export denied
- source classification upgrade -> permission/stale handling
- Agent runtime duration used as effort -> test must fail
- automatic employee score path -> release blocker
