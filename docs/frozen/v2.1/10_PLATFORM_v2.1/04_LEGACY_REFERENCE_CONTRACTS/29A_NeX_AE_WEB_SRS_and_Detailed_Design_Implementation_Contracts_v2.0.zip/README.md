# 29A NeX-AE-WEB v2.0 Implementation Contracts
Logical UI/ViewModel contracts only. Physical frontend framework, route names and endpoints remain PENDING Repository Evidence.
