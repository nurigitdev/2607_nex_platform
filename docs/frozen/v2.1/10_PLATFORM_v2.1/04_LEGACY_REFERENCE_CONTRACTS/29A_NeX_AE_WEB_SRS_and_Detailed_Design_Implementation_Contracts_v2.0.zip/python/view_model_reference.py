from dataclasses import dataclass

@dataclass(frozen=True)
class SourceState:
    owner: str
    ref: str
    version: str | None

def user_safe_status(runtime_state: str) -> str:
    mapping = {
        'WAITING_INPUT': 'NEED_INPUT',
        'WAITING_CONFIRMATION': 'NEED_CONFIRMATION',
        'WAITING_APPROVAL': 'NEED_APPROVAL',
        'WAITING_DEPENDENCY': 'WAITING_FOR_OTHERS',
        'RECONCILIATION_REQUIRED': 'VERIFYING_RESULT',
    }
    return mapping.get(runtime_state, runtime_state)

def may_show_performance_score() -> bool:
    return False
