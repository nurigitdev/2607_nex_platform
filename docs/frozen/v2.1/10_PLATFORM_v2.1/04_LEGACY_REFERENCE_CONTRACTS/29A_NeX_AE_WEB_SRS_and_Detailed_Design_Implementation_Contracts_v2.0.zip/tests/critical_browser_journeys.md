# Critical Browser Journeys

1. Golden A direct voucher — prompt → plan → confirmation → result; CX unavailable variant.
2. Formal approval — WAITING_APPROVAL → decision → current reauthorization → resume.
3. Golden B — parent/child → coworker progress → duplicate result event → one parent resume → WA timeline.
4. Evidence — sufficient/partial/insufficient/conflict + citation + source preview permission.
5. WA — timeline → weekly report draft → review → submit → performance evidence (no score).
6. Reconciliation — UNKNOWN_COMMIT_STATE shows RECONCILIATION_REQUIRED; no blind retry.
7. Accessibility — keyboard-only prompt, inbox, gate, evidence, report submit.
