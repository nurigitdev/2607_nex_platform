-- Reference NSL runtime transaction semantics

-- A. Begin local execution/idempotency record before provider calls.
BEGIN;

INSERT INTO nex_skill.skill_idempotency(
    skill_id, skill_version, idempotency_key,
    semantic_payload_hash, status, execution_ref
) VALUES (
    :skill_id, :skill_version, :idempotency_key,
    :semantic_payload_hash, 'STARTED', :agent_execution_id
)
ON CONFLICT (skill_id, skill_version, idempotency_key) DO NOTHING;

-- Application reads the row:
-- same key + different semantic_payload_hash => IDEMPOTENCY_CONFLICT
-- same key + completed runtime_result_json => return original result

INSERT INTO nex_skill.skill_execution(
    skill_execution_id, agent_execution_id, work_item_id, plan_step_id,
    skill_id, skill_version, execution_mode, state,
    principal_ref, business_actor_ref, role_binding_ref, policy_snapshot_ref,
    idempotency_key, semantic_payload_hash, input_json,
    correlation_id, causation_id
) VALUES (...);

COMMIT;

-- B. Canonical provider WRITE happens outside the local PostgreSQL transaction.
-- It uses the SAME idempotency_key and explicit expected_version.
-- Provider returns COMMITTED / NOT_COMMITTED / UNKNOWN_COMMIT_STATE.

-- C. Persist write result locally.
BEGIN;

SELECT *
  FROM nex_skill.skill_idempotency
 WHERE skill_id=:skill_id
   AND skill_version=:skill_version
   AND idempotency_key=:idempotency_key
 FOR UPDATE;

UPDATE nex_skill.skill_execution
   SET state=:runtime_state,
       output_json=:output_json::jsonb,
       commit_state=:commit_state,
       write_operation_ref=:write_operation_ref,
       gate_proof_refs=:gate_proof_refs::jsonb,
       verification_json=:verification_json::jsonb,
       error_json=:error_json::jsonb,
       completed_at=now()
 WHERE skill_execution_id=:skill_execution_id;

UPDATE nex_skill.skill_idempotency
   SET status = CASE
        WHEN :runtime_state='RECONCILIATION_REQUIRED' THEN 'RECONCILIATION_REQUIRED'
        WHEN :runtime_state='SUCCEEDED' THEN 'COMPLETED'
        ELSE 'FAILED'
       END,
       commit_state=:commit_state,
       runtime_result_json=:runtime_result_json::jsonb,
       verification_json=:verification_json::jsonb,
       updated_at=now()
 WHERE skill_id=:skill_id
   AND skill_version=:skill_version
   AND idempotency_key=:idempotency_key;

COMMIT;

-- UNKNOWN_COMMIT_STATE:
-- 1) DO NOT call provider again automatically.
-- 2) Return RECONCILIATION_REQUIRED to AE Runtime.
-- 3) AE/Domain reconciliation workflow verifies provider/business SoR using the same operation_ref/key.
