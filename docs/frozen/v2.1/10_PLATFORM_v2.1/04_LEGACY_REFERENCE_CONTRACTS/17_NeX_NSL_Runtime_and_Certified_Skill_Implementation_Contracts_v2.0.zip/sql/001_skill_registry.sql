-- NeX Skill Registry / Certification v2.0 reference PostgreSQL design
CREATE SCHEMA IF NOT EXISTS nex_skill;

CREATE TABLE IF NOT EXISTS nex_skill.publisher_key (
    key_id                  varchar(160) PRIMARY KEY,
    publisher_id            varchar(160) NOT NULL,
    algorithm               varchar(32) NOT NULL DEFAULT 'ED25519',
    public_key_pem          text NOT NULL,
    status                  varchar(24) NOT NULL DEFAULT 'ACTIVE',
    valid_from              timestamptz,
    valid_to                timestamptz,
    created_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_publisher_key_status CHECK (status IN ('ACTIVE','REVOKED','EXPIRED'))
);

CREATE TABLE IF NOT EXISTS nex_skill.skill_version (
    skill_id                varchar(160) NOT NULL,
    skill_version           varchar(64) NOT NULL,
    display_name            varchar(300) NOT NULL,
    description             text,
    language_version        varchar(16) NOT NULL,
    ir_version              varchar(16) NOT NULL,
    profile_id              varchar(80) NOT NULL,
    status                  varchar(40) NOT NULL,
    risk_level              varchar(8) NOT NULL,
    required_gate_type      varchar(32) NOT NULL,
    write_capability_id     varchar(160),
    source_ref              varchar(512),
    source_hash             char(64) NOT NULL,
    nso_json                jsonb NOT NULL,
    nso_hash                char(64) NOT NULL,
    manifest_json           jsonb NOT NULL,
    manifest_hash           char(64) NOT NULL,
    contract_set_hash       char(64),
    package_hash            char(64),
    publisher_id            varchar(160) NOT NULL,
    signing_key_id          varchar(160) NOT NULL REFERENCES nex_skill.publisher_key(key_id),
    signature_algorithm     varchar(32) NOT NULL,
    signature_b64           text NOT NULL,
    signed_digest           char(64) NOT NULL,
    certification_owner_ref varchar(160) NOT NULL,
    certified_by_ref        varchar(160),
    certified_at            timestamptz,
    revalidation_reason     text,
    created_at              timestamptz NOT NULL DEFAULT now(),
    updated_at              timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY(skill_id, skill_version),
    CONSTRAINT ck_skill_status CHECK (
        status IN ('DRAFT','COMPILED','TESTING','READY_FOR_CERTIFICATION','CERTIFIED',
                   'REVALIDATION_REQUIRED','SUSPENDED','DEPRECATED','RETIRED')
    )
);
CREATE INDEX IF NOT EXISTS ix_skill_status_risk
    ON nex_skill.skill_version(status, risk_level, skill_id);

CREATE TABLE IF NOT EXISTS nex_skill.skill_contract_dependency (
    skill_id                varchar(160) NOT NULL,
    skill_version           varchar(64) NOT NULL,
    capability_id           varchar(160) NOT NULL,
    operation_kind          varchar(16) NOT NULL,
    contract_version        varchar(64) NOT NULL,
    contract_hash           varchar(128) NOT NULL,
    PRIMARY KEY(skill_id, skill_version, capability_id, operation_kind),
    FOREIGN KEY(skill_id, skill_version)
        REFERENCES nex_skill.skill_version(skill_id, skill_version)
);

CREATE TABLE IF NOT EXISTS nex_skill.skill_test_evidence (
    evidence_id             uuid PRIMARY KEY,
    skill_id                varchar(160) NOT NULL,
    skill_version           varchar(64) NOT NULL,
    test_type               varchar(32) NOT NULL,
    test_id                 varchar(160) NOT NULL,
    result                  varchar(16) NOT NULL,
    report_json             jsonb,
    artifact_ref            varchar(512),
    executed_by_ref         varchar(160),
    executed_at             timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY(skill_id, skill_version)
        REFERENCES nex_skill.skill_version(skill_id, skill_version)
);
CREATE INDEX IF NOT EXISTS ix_skill_test_evidence
    ON nex_skill.skill_test_evidence(skill_id, skill_version, test_type, result);

CREATE TABLE IF NOT EXISTS nex_skill.skill_certification_decision (
    decision_id             uuid PRIMARY KEY,
    skill_id                varchar(160) NOT NULL,
    skill_version           varchar(64) NOT NULL,
    from_status             varchar(40) NOT NULL,
    to_status               varchar(40) NOT NULL,
    decision_type           varchar(32) NOT NULL,
    actor_ref               varchar(160) NOT NULL,
    reason                  text,
    evidence_refs           jsonb,
    policy_version          varchar(64),
    created_at              timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY(skill_id, skill_version)
        REFERENCES nex_skill.skill_version(skill_id, skill_version)
);
