-- Skill certification lifecycle reference transitions

-- Automated test system may promote TESTING -> READY_FOR_CERTIFICATION when policy eligibility passes.
UPDATE nex_skill.skill_version
   SET status='READY_FOR_CERTIFICATION',
       updated_at=now()
 WHERE skill_id=:skill_id
   AND skill_version=:skill_version
   AND status='TESTING';

INSERT INTO nex_skill.skill_certification_decision(
    decision_id, skill_id, skill_version, from_status, to_status,
    decision_type, actor_ref, reason, evidence_refs, policy_version
) VALUES (
    :decision_id, :skill_id, :skill_version, 'TESTING','READY_FOR_CERTIFICATION',
    'SYSTEM_ELIGIBILITY', :system_actor_ref, :reason, :evidence_refs::jsonb, :policy_version
);

-- Human governance owner explicitly certifies.
UPDATE nex_skill.skill_version
   SET status='CERTIFIED',
       certified_by_ref=:certifier_ref,
       certified_at=now(),
       updated_at=now()
 WHERE skill_id=:skill_id
   AND skill_version=:skill_version
   AND status='READY_FOR_CERTIFICATION';

-- Contract hash/security/test degradation may require revalidation.
UPDATE nex_skill.skill_version
   SET status='REVALIDATION_REQUIRED',
       revalidation_reason=:reason,
       updated_at=now()
 WHERE skill_id=:skill_id
   AND skill_version=:skill_version
   AND status='CERTIFIED';

-- Emergency disable.
UPDATE nex_skill.skill_version
   SET status='SUSPENDED',
       revalidation_reason=:reason,
       updated_at=now()
 WHERE skill_id=:skill_id
   AND skill_version=:skill_version
   AND status IN ('CERTIFIED','READY_FOR_CERTIFICATION','REVALIDATION_REQUIRED','TESTING');
