-- NSL Runtime execution / idempotency / replay evidence
CREATE TABLE IF NOT EXISTS nex_skill.skill_execution (
    skill_execution_id      uuid PRIMARY KEY,
    agent_execution_id      uuid NOT NULL,
    work_item_id            uuid,
    plan_step_id            varchar(64) NOT NULL,
    skill_id                varchar(160) NOT NULL,
    skill_version           varchar(64) NOT NULL,
    execution_mode          varchar(16) NOT NULL,
    state                   varchar(40) NOT NULL,
    principal_ref           varchar(160) NOT NULL,
    business_actor_ref      varchar(160) NOT NULL,
    role_binding_ref        varchar(160),
    policy_snapshot_ref     varchar(256) NOT NULL,
    idempotency_key         varchar(256) NOT NULL,
    semantic_payload_hash   char(64) NOT NULL,
    input_json              jsonb NOT NULL,
    output_json             jsonb,
    commit_state            varchar(40) NOT NULL DEFAULT 'NONE',
    write_operation_ref     varchar(256),
    gate_proof_refs         jsonb,
    verification_json       jsonb,
    error_json              jsonb,
    correlation_id          varchar(128) NOT NULL,
    causation_id            varchar(128),
    started_at              timestamptz NOT NULL DEFAULT now(),
    completed_at            timestamptz,
    FOREIGN KEY(skill_id, skill_version)
        REFERENCES nex_skill.skill_version(skill_id, skill_version),
    CONSTRAINT ck_skill_execution_mode CHECK (execution_mode IN ('LIVE','REPLAY')),
    CONSTRAINT ck_skill_execution_state CHECK (
        state IN ('RUNNING','SUCCEEDED','VALIDATION_FAILED','GATE_REQUIRED',
                  'POLICY_DENIED','RECONCILIATION_REQUIRED','FAILED')
    ),
    CONSTRAINT ck_skill_commit_state CHECK (
        commit_state IN ('NONE','COMMITTED','NOT_COMMITTED','UNKNOWN_COMMIT_STATE')
    )
);
CREATE INDEX IF NOT EXISTS ix_skill_execution_trace
    ON nex_skill.skill_execution(agent_execution_id, plan_step_id, started_at);
CREATE INDEX IF NOT EXISTS ix_skill_execution_corr
    ON nex_skill.skill_execution(correlation_id, started_at);

CREATE TABLE IF NOT EXISTS nex_skill.skill_idempotency (
    skill_id                varchar(160) NOT NULL,
    skill_version           varchar(64) NOT NULL,
    idempotency_key         varchar(256) NOT NULL,
    semantic_payload_hash   char(64) NOT NULL,
    status                  varchar(24) NOT NULL,
    execution_ref           varchar(160),
    commit_state            varchar(40) NOT NULL DEFAULT 'NONE',
    runtime_result_json     jsonb,
    verification_json       jsonb,
    created_at              timestamptz NOT NULL DEFAULT now(),
    updated_at              timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY(skill_id, skill_version, idempotency_key),
    CONSTRAINT ck_skill_idem_status CHECK (status IN ('STARTED','COMPLETED','RECONCILIATION_REQUIRED','FAILED'))
);

CREATE TABLE IF NOT EXISTS nex_skill.skill_node_event (
    node_event_id           uuid PRIMARY KEY,
    skill_execution_id      uuid NOT NULL REFERENCES nex_skill.skill_execution(skill_execution_id),
    sequence_no             integer NOT NULL,
    node_id                 varchar(32) NOT NULL,
    node_type               varchar(40) NOT NULL,
    capability_id           varchar(160),
    input_hash              char(64),
    result_json             jsonb,
    commit_state            varchar(40),
    evidence_refs           jsonb,
    occurred_at             timestamptz NOT NULL DEFAULT now(),
    UNIQUE(skill_execution_id, sequence_no)
);

CREATE TABLE IF NOT EXISTS nex_skill.skill_replay_bundle (
    replay_bundle_id        uuid PRIMARY KEY,
    source_skill_execution_id uuid NOT NULL REFERENCES nex_skill.skill_execution(skill_execution_id),
    bundle_json             jsonb NOT NULL,
    bundle_hash             char(64) NOT NULL,
    created_by_ref          varchar(160),
    created_at              timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nex_skill.skill_execution_statistics (
    skill_id                varchar(160) NOT NULL,
    skill_version           varchar(64) NOT NULL,
    window_start            timestamptz NOT NULL,
    window_end              timestamptz NOT NULL,
    execution_count         bigint NOT NULL DEFAULT 0,
    verified_success_count  bigint NOT NULL DEFAULT 0,
    validation_fail_count   bigint NOT NULL DEFAULT 0,
    policy_denied_count     bigint NOT NULL DEFAULT 0,
    reconciliation_count    bigint NOT NULL DEFAULT 0,
    failure_count           bigint NOT NULL DEFAULT 0,
    PRIMARY KEY(skill_id, skill_version, window_start, window_end)
);
