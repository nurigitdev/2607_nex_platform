# NeX NSL Runtime & Certified Skill v2.0 Reference Package

Accompanies `17_NeX_NSL_Runtime_and_Certified_Skill_Detailed_Design_v2.0`.

## Schemas
- nso-ir-v1.1.schema.json
- skill-manifest-v2.schema.json
- execution-context-v1.schema.json
- human-gate-proof-v1.schema.json
- skill-golden-test-v1.schema.json
- runtime-result-v1.schema.json

## Python
- models.py: Pydantic runtime contracts
- protocols.py: dependency-inversion interfaces
- compiler.py: compiler pipeline orchestrator
- preflight.py: signature/status/contract/PDP checks
- gate.py: gate proof/write-intent/payload binding
- runtime.py: deterministic NSO execution skeleton
- hashing.py / signature.py: canonical SHA-256 + Ed25519 reference
- registry.py: certification lifecycle/policy
- golden.py: golden-test runner skeleton

## PostgreSQL
- 001_skill_registry.sql
- 002_runtime_execution.sql
- 003_runtime_idempotency_transactions.sql
- 004_certification_lifecycle.sql

## Important
- Ed25519 is a concrete v2 reference choice for package signatures. Production private keys should stay in a secret/HSM/signing service; the runtime needs public keys only.
- Human gate waiting belongs to Unified Agent Runtime; NSL verifies proof at write time.
- Provider commands execute outside the local NSL DB transaction and use the same idempotency key.
- UNKNOWN_COMMIT_STATE returns RECONCILIATION_REQUIRED; never auto-retry.
- REPLAY mode never calls the real write provider.
- Certified skill versions are immutable; changes create a new version.
