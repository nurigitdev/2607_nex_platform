from __future__ import annotations
from datetime import datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

class RuntimeMode(StrEnum):
    LIVE = "LIVE"
    REPLAY = "REPLAY"

class CommitState(StrEnum):
    COMMITTED = "COMMITTED"
    NOT_COMMITTED = "NOT_COMMITTED"
    UNKNOWN_COMMIT_STATE = "UNKNOWN_COMMIT_STATE"
    NONE = "NONE"

class RuntimeState(StrEnum):
    SUCCEEDED = "SUCCEEDED"
    VALIDATION_FAILED = "VALIDATION_FAILED"
    GATE_REQUIRED = "GATE_REQUIRED"
    POLICY_DENIED = "POLICY_DENIED"
    RECONCILIATION_REQUIRED = "RECONCILIATION_REQUIRED"
    FAILED = "FAILED"

class Money(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    amount: Decimal
    currency: str = Field(min_length=3, max_length=3)

class EntityRef(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    entity_type: str
    entity_id: str
    version: str | int | None = None
    status: str | None = None

class SkillRef(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    skill_id: str
    skill_version: str

class HumanGateProof(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    proof_version: str = "1.0"
    proof_id: str
    gate_id: str
    gate_type: str
    status: str
    actor_ref: str
    skill_id: str
    skill_version: str
    agent_execution_id: str
    plan_step_id: str
    approval_instance_ref: str | None = None
    write_intent_hash: str
    payload_hash: str
    policy_ref: str | None = None
    issued_at: datetime
    expires_at: datetime
    proof_source: str
    proof_signature: str | None = None

class ExecutionContext(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    execution_context_version: str = "1.0"
    mode: RuntimeMode
    skill_ref: SkillRef
    agent_execution_id: str
    work_item_id: str | None = None
    plan_step_id: str
    principal_ref: str
    business_actor_ref: str
    coworker_profile_ref: str | None = None
    role_binding_ref: str | None = None
    org_scope_refs: tuple[str, ...] = ()
    project_scope_refs: tuple[str, ...] = ()
    correlation_id: str
    causation_id: str | None = None
    request_id: str | None = None
    policy_snapshot_ref: str
    idempotency_key: str
    expected_version: str | int | None = None
    inputs: dict[str, Any]
    gate_proof_refs: tuple[str, ...] = ()
    replay_bundle_ref: str | None = None
    secret_refs: tuple[str, ...] = ()

class RuntimeResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    result_version: str = "1.0"
    skill_id: str
    skill_version: str
    runtime_state: RuntimeState
    execution_id: str
    output: Any = None
    entity_refs: list[EntityRef] = []
    commit_state: CommitState = CommitState.NONE
    write_operation_ref: str | None = None
    verification: Any = None
    error: dict[str, Any] | None = None
    trace: dict[str, Any]
