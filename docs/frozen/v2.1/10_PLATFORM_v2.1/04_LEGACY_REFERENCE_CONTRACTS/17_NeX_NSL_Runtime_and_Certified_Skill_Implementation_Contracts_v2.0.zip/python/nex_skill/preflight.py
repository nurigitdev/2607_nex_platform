from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from .models import ExecutionContext
from .hashing import sha256_hex

@dataclass(frozen=True)
class PreflightResult:
    allowed: bool
    reason_codes: tuple[str, ...]
    manifest: dict[str, Any]
    nso: dict[str, Any]
    policy_decision: dict[str, Any] | None = None

class RuntimePreflight:
    def __init__(
        self, skill_registry, signature_verifier, capability_registry,
        authorization_pdp, runtime_version: str
    ):
        self.skill_registry = skill_registry
        self.signature_verifier = signature_verifier
        self.capability_registry = capability_registry
        self.authorization_pdp = authorization_pdp
        self.runtime_version = runtime_version

    async def check(self, context: ExecutionContext) -> PreflightResult:
        manifest = await self.skill_registry.get_manifest(
            context.skill_ref.skill_id, context.skill_ref.skill_version
        )
        nso = await self.skill_registry.get_nso(
            context.skill_ref.skill_id, context.skill_ref.skill_version
        )

        reasons: list[str] = []
        if manifest["status"] != "CERTIFIED" and context.mode.value == "LIVE":
            reasons.append("SKILL_NOT_CERTIFIED")
        if manifest["nso_hash"] != nso["nso_hash"]:
            reasons.append("NSO_HASH_MISMATCH")
        if not await self.signature_verifier.verify_manifest_and_nso(manifest, nso):
            reasons.append("SIGNATURE_INVALID")
        if manifest["profile_id"] != nso["profile_id"]:
            reasons.append("PROFILE_MISMATCH")
        if manifest["ir_version"] != nso["ir_version"]:
            reasons.append("IR_VERSION_MISMATCH")

        for dep in manifest["capabilities"]:
            current = await self.capability_registry.get(dep["capability_id"])
            if current["contract_hash"] != dep["contract_hash"]:
                reasons.append(f"CAPABILITY_CONTRACT_HASH_MISMATCH:{dep['capability_id']}")
            if not current.get("active", True):
                reasons.append(f"CAPABILITY_DISABLED:{dep['capability_id']}")

        policy = await self.authorization_pdp.authorize_skill(
            manifest=manifest, nso=nso, context=context
        )
        if not policy.get("allowed", False):
            reasons.extend(policy.get("reason_codes", ["POLICY_DENIED"]))

        return PreflightResult(
            allowed=not reasons,
            reason_codes=tuple(reasons),
            manifest=manifest,
            nso=nso,
            policy_decision=policy,
        )
