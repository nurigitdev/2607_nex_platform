from __future__ import annotations
from typing import Any

ALLOWED_TRANSITIONS = {
    "DRAFT": {"COMPILED","RETIRED"},
    "COMPILED": {"TESTING","DRAFT","RETIRED"},
    "TESTING": {"READY_FOR_CERTIFICATION","COMPILED","SUSPENDED"},
    "READY_FOR_CERTIFICATION": {"CERTIFIED","TESTING","SUSPENDED"},
    "CERTIFIED": {"REVALIDATION_REQUIRED","SUSPENDED","DEPRECATED"},
    "REVALIDATION_REQUIRED": {"TESTING","SUSPENDED","DEPRECATED"},
    "SUSPENDED": {"TESTING","REVALIDATION_REQUIRED","RETIRED"},
    "DEPRECATED": {"RETIRED","SUSPENDED"},
    "RETIRED": set(),
}

def assert_skill_transition(current: str, target: str) -> None:
    if target not in ALLOWED_TRANSITIONS.get(current, set()):
        raise ValueError(f"INVALID_SKILL_STATUS_TRANSITION:{current}->{target}")

class CertificationPolicy:
    """System may make READY_FOR_CERTIFICATION automatic; CERTIFIED requires governance actor."""

    REQUIRED_TEST_TYPES = {
        "UNIT","GOLDEN","NEGATIVE","SECURITY","REPLAY","COMPATIBILITY"
    }

    def eligibility(self, evidence: list[dict[str, Any]], signature_valid: bool, contracts_valid: bool) -> dict:
        passed = {e["test_type"] for e in evidence if e.get("result") == "PASS"}
        missing = sorted(self.REQUIRED_TEST_TYPES - passed)
        reasons = []
        if missing:
            reasons.append("MISSING_TEST_TYPES:" + ",".join(missing))
        if not signature_valid:
            reasons.append("SIGNATURE_INVALID")
        if not contracts_valid:
            reasons.append("CONTRACT_COMPATIBILITY_FAILED")
        return {
            "eligible": not reasons,
            "reason_codes": reasons,
            "next_status": "READY_FOR_CERTIFICATION" if not reasons else "TESTING",
        }
