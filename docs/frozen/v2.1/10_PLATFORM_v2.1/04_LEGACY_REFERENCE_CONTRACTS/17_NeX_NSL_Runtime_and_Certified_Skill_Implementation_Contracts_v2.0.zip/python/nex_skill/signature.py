from __future__ import annotations
import base64
from typing import Any

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey, Ed25519PublicKey
)

from .hashing import manifest_signing_digest

ALGORITHM = "ED25519"

def sign_for_build(
    manifest_without_signature: dict[str, Any],
    nso_hash: str,
    private_key: Ed25519PrivateKey,
) -> dict[str, str]:
    """Build/certification helper only. Production private keys should live in a secret/HSM service."""
    digest = manifest_signing_digest(manifest_without_signature, nso_hash)
    signature = private_key.sign(bytes.fromhex(digest))
    return {
        "algorithm": ALGORITHM,
        "signature_b64": base64.b64encode(signature).decode("ascii"),
        "signed_digest": digest,
    }

def verify_signature(
    manifest_without_signature: dict[str, Any],
    nso_hash: str,
    signature_block: dict[str, str],
    public_key: Ed25519PublicKey,
) -> bool:
    if signature_block.get("algorithm") != ALGORITHM:
        return False
    digest = manifest_signing_digest(manifest_without_signature, nso_hash)
    if digest != signature_block.get("signed_digest"):
        return False
    try:
        public_key.verify(
            base64.b64decode(signature_block["signature_b64"]),
            bytes.fromhex(digest),
        )
        return True
    except Exception:
        return False
