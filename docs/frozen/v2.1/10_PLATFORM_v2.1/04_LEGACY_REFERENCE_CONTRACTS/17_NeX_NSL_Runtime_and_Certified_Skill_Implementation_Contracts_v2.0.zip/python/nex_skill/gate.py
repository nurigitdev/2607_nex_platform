from __future__ import annotations
from datetime import datetime, timezone
from typing import Any

from .hashing import sha256_hex
from .models import ExecutionContext, HumanGateProof

class GateProofVerifier:
    def __init__(self, proof_provider):
        self.proof_provider = proof_provider

    async def verify(
        self, *, gate_requirement: dict[str, Any], write_payload: dict[str, Any],
        write_intent: dict[str, Any], context: ExecutionContext
    ) -> HumanGateProof:
        expected_payload_hash = sha256_hex(write_payload)
        expected_intent_hash = sha256_hex(write_intent)

        candidates: list[HumanGateProof] = []
        for ref in context.gate_proof_refs:
            proof = await self.proof_provider.get(ref)
            if proof.gate_id == gate_requirement["gate_id"]:
                candidates.append(proof)

        if len(candidates) != 1:
            raise ValueError("GATE_PROOF_REQUIRED_OR_AMBIGUOUS")
        proof = candidates[0]

        now = datetime.now(timezone.utc)
        if proof.status != "SATISFIED":
            raise ValueError("GATE_PROOF_NOT_SATISFIED")
        if proof.expires_at <= now:
            raise ValueError("GATE_PROOF_EXPIRED")
        if proof.skill_id != context.skill_ref.skill_id or proof.skill_version != context.skill_ref.skill_version:
            raise ValueError("GATE_SKILL_BINDING_MISMATCH")
        if proof.agent_execution_id != context.agent_execution_id or proof.plan_step_id != context.plan_step_id:
            raise ValueError("GATE_EXECUTION_BINDING_MISMATCH")
        if proof.payload_hash != expected_payload_hash:
            raise ValueError("GATE_PAYLOAD_HASH_MISMATCH")
        if proof.write_intent_hash != expected_intent_hash:
            raise ValueError("GATE_WRITE_INTENT_HASH_MISMATCH")
        if proof.gate_type != gate_requirement["gate_type"]:
            raise ValueError("GATE_TYPE_MISMATCH")
        return proof
