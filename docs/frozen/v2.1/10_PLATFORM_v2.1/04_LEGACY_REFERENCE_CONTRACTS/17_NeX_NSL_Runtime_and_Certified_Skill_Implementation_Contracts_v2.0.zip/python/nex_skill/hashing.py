from __future__ import annotations
import hashlib
import json
from typing import Any

def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")

def sha256_hex(value: Any) -> str:
    if isinstance(value, bytes):
        data = value
    elif isinstance(value, str):
        data = value.encode("utf-8")
    else:
        data = canonical_json_bytes(value)
    return hashlib.sha256(data).hexdigest()

def manifest_signing_digest(manifest_without_signature: dict, nso_hash: str) -> str:
    payload = {
        "manifest": manifest_without_signature,
        "nso_hash": nso_hash,
    }
    return sha256_hex(payload)
