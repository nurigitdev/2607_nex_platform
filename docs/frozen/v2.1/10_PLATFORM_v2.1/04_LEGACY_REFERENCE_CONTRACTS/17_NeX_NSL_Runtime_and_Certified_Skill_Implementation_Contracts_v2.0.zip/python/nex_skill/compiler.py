from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping

from .hashing import sha256_hex

Json = Mapping[str, Any]

@dataclass(frozen=True)
class CompileResult:
    nso: dict[str, Any]
    warnings: tuple[dict[str, Any], ...]
    dependency_hashes: Mapping[str, str]

class CompilerPipeline:
    def __init__(
        self, parser, include_resolver, type_checker, safety_checker,
        capability_registry, nso_emitter, compiler_version: str
    ):
        self.parser = parser
        self.include_resolver = include_resolver
        self.type_checker = type_checker
        self.safety_checker = safety_checker
        self.capability_registry = capability_registry
        self.nso_emitter = nso_emitter
        self.compiler_version = compiler_version

    async def compile(
        self, *, source_text: str, source_ref: str, strict_profile: Json
    ) -> CompileResult:
        ast = self.parser.parse(source_text, source_ref)
        expanded_ast, dependency_hashes = self.include_resolver.resolve(ast, source_ref)

        issues = list(self.type_checker.check(expanded_ast))
        issues.extend(self.safety_checker.check(expanded_ast, strict_profile))
        errors = [i for i in issues if i.get("severity") == "ERROR"]
        if errors:
            raise ValueError({"code": "NSL_STATIC_VALIDATION_FAILED", "issues": errors})

        contracts: list[dict[str, Any]] = []
        for capability_id in expanded_ast["requires"]:
            contracts.append(await self.capability_registry.get(capability_id))

        nso = self.nso_emitter.emit(
            ast=expanded_ast,
            contracts=contracts,
            profile=strict_profile,
            compiler_version=self.compiler_version,
            source_integrity={
                "root_source_hash": sha256_hex(source_text),
                "dependency_hashes": dict(dependency_hashes),
            },
        )
        nso["nso_hash"] = sha256_hex({k: v for k, v in nso.items() if k != "nso_hash"})
        return CompileResult(
            nso=nso,
            warnings=tuple(i for i in issues if i.get("severity") != "ERROR"),
            dependency_hashes=dependency_hashes,
        )
