from __future__ import annotations
from typing import Any, Mapping

from .hashing import sha256_hex
from .models import CommitState, ExecutionContext, RuntimeResult, RuntimeState

class NSLRuntime:
    """Reference deterministic runtime skeleton for NSO IR 1.1."""

    def __init__(
        self, preflight, invoker, gate_verifier, idempotency_store,
        replay_provider, evaluator, audit_sink
    ):
        self.preflight = preflight
        self.invoker = invoker
        self.gate_verifier = gate_verifier
        self.idempotency_store = idempotency_store
        self.replay_provider = replay_provider
        self.evaluator = evaluator
        self.audit_sink = audit_sink

    async def execute(self, context: ExecutionContext) -> RuntimeResult:
        pf = await self.preflight.check(context)
        if not pf.allowed:
            return self._result(
                context, RuntimeState.POLICY_DENIED, CommitState.NONE,
                error={"code":"NSL_PREFLIGHT_DENIED","reasons":list(pf.reason_codes)}
            )

        nso = pf.nso
        symbols: dict[str, Any] = dict(context.inputs)
        output: dict[str, Any] = {}
        write_seen = False
        write_result: dict[str, Any] | None = None
        verification: dict[str, Any] | None = None
        final_commit = CommitState.NONE

        semantic_payload_hash = sha256_hex(context.inputs)
        previous = await self.idempotency_store.get(
            context.skill_ref.skill_id, context.skill_ref.skill_version,
            context.idempotency_key
        )
        if previous and context.mode.value == "LIVE":
            if previous["semantic_payload_hash"] != semantic_payload_hash:
                return self._result(
                    context, RuntimeState.FAILED, CommitState.NONE,
                    error={"code":"IDEMPOTENCY_CONFLICT"}
                )
            if previous.get("runtime_result"):
                return RuntimeResult.model_validate(previous["runtime_result"])

        await self.idempotency_store.begin(
            skill_id=context.skill_ref.skill_id,
            skill_version=context.skill_ref.skill_version,
            idempotency_key=context.idempotency_key,
            semantic_payload_hash=semantic_payload_hash,
            execution_ref=context.agent_execution_id,
        )

        for node in nso["nodes"]:
            ntype = node["node_type"]
            node_id = node["node_id"]

            if context.mode.value == "REPLAY":
                replayed = await self.replay_provider.node_result(
                    context.replay_bundle_ref, node_id
                )
                self._apply_replay_node(node, replayed, symbols, output)
                if ntype == "WRITE":
                    write_seen = True
                    write_result = replayed
                    final_commit = CommitState(replayed.get("commit_state","COMMITTED"))
                continue

            if ntype == "READ":
                payload = self._bind_payload(node, symbols)
                result = await self.invoker.query(node["capability_id"], payload, context)
                symbols[node["bind"]] = result

            elif ntype == "BIND":
                symbols[node["bind"]] = self.evaluator.evaluate(node["expression"], symbols)

            elif ntype == "CHECK":
                value = self.evaluator.evaluate(node["expression"], symbols)
                if value is not True:
                    state = RuntimeState.VALIDATION_FAILED
                    error_code = "CHECK_FAIL" if value is False else "CHECK_UNKNOWN"
                    return self._result(
                        context, state, CommitState.NONE,
                        error={"code":error_code,"node_id":node_id}
                    )

            elif ntype == "HUMAN_GATE_REQUIREMENT":
                # Proof is verified when the bound write payload is known.
                symbols[f"__gate_req__:{node['gate_id']}"] = node

            elif ntype == "WRITE":
                if write_seen:
                    return self._result(
                        context, RuntimeState.FAILED, CommitState.NONE,
                        error={"code":"MULTIPLE_WRITE_RUNTIME_GUARD"}
                    )
                write_seen = True
                payload = self._bind_payload(node, symbols)
                intent = {
                    "skill_id": context.skill_ref.skill_id,
                    "skill_version": context.skill_ref.skill_version,
                    "capability_id": node["capability_id"],
                    "operation_key": node.get("operation_key"),
                }
                gate_req = symbols.get(f"__gate_req__:{node['gate_id']}")
                if gate_req is None:
                    return self._result(
                        context, RuntimeState.GATE_REQUIRED, CommitState.NONE,
                        error={"code":"GATE_REQUIREMENT_MISSING"}
                    )
                await self.gate_verifier.verify(
                    gate_requirement=gate_req, write_payload=payload,
                    write_intent=intent, context=context
                )
                write_result = await self.invoker.command(
                    node["capability_id"], payload, context,
                    context.idempotency_key, context.expected_version
                )
                final_commit = CommitState(write_result["commit"]["state"])
                if final_commit == CommitState.UNKNOWN_COMMIT_STATE:
                    result = self._result(
                        context, RuntimeState.RECONCILIATION_REQUIRED,
                        final_commit, output=output,
                        write_operation_ref=write_result.get("operation_ref"),
                        error={"code":"UNKNOWN_COMMIT_STATE"}
                    )
                    await self.idempotency_store.complete(
                        skill_id=context.skill_ref.skill_id,
                        skill_version=context.skill_ref.skill_version,
                        idempotency_key=context.idempotency_key,
                        commit_state=final_commit.value,
                        result=result.model_dump(mode="json"),
                        verification=None,
                    )
                    return result
                if final_commit == CommitState.COMMITTED:
                    verification = await self.invoker.verify(
                        node["capability_id"], write_result, context
                    )
                symbols[node["bind"]] = write_result

            elif ntype == "EMIT":
                output[node["name"]] = self.evaluator.evaluate(node["expression"], symbols)

            elif ntype == "FOREACH_BOUNDED":
                raise NotImplementedError("Reference skeleton delegates bounded foreach to a deterministic node executor")

            else:
                return self._result(
                    context, RuntimeState.FAILED, final_commit,
                    error={"code":"UNKNOWN_NSO_NODE","node_type":ntype}
                )

        result = self._result(
            context, RuntimeState.SUCCEEDED, final_commit,
            output=output, verification=verification,
            write_operation_ref=(write_result or {}).get("operation_ref")
        )
        await self.idempotency_store.complete(
            skill_id=context.skill_ref.skill_id,
            skill_version=context.skill_ref.skill_version,
            idempotency_key=context.idempotency_key,
            commit_state=final_commit.value,
            result=result.model_dump(mode="json"),
            verification=verification,
        )
        return result

    def _bind_payload(self, node: Mapping[str, Any], symbols: Mapping[str, Any]) -> dict[str, Any]:
        # Reference placeholder: production implementation uses typed binding/expression objects.
        return {
            k: self.evaluator.evaluate(v, symbols)
            for k, v in node.get("arguments", {}).items()
        }

    def _apply_replay_node(self, node, replayed, symbols, output):
        if node["node_type"] in {"READ","BIND","WRITE"} and node.get("bind"):
            symbols[node["bind"]] = replayed
        if node["node_type"] == "EMIT":
            output[node["name"]] = replayed.get("value")

    def _result(
        self, context, runtime_state, commit_state, *,
        output=None, verification=None, write_operation_ref=None, error=None
    ):
        return RuntimeResult(
            skill_id=context.skill_ref.skill_id,
            skill_version=context.skill_ref.skill_version,
            runtime_state=runtime_state,
            execution_id=context.agent_execution_id,
            output=output,
            commit_state=commit_state,
            write_operation_ref=write_operation_ref,
            verification=verification,
            error=error,
            trace={
                "correlation_id":context.correlation_id,
                "causation_id":context.causation_id,
                "plan_step_id":context.plan_step_id,
            }
        )
