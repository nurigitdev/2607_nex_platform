from __future__ import annotations
from typing import Any

class GoldenTestRunner:
    def __init__(self, compiler, runtime_factory):
        self.compiler = compiler
        self.runtime_factory = runtime_factory

    async def run_runtime_fixture(self, fixture: dict[str, Any], context, manifest, nso) -> dict:
        runtime, spies = self.runtime_factory.for_fixture(fixture, manifest, nso)
        result = await runtime.execute(context)
        expected = fixture["expected"]
        failures: list[str] = []
        if result.runtime_state.value != expected["runtime_state"]:
            failures.append("RUNTIME_STATE_MISMATCH")
        if spies.write_call_count != expected["provider_write_call_count"]:
            failures.append("WRITE_CALL_COUNT_MISMATCH")
        if result.commit_state.value != expected.get("commit_state","NONE"):
            failures.append("COMMIT_STATE_MISMATCH")
        if expected.get("error_code") and (result.error or {}).get("code") != expected["error_code"]:
            failures.append("ERROR_CODE_MISMATCH")
        return {"result":"PASS" if not failures else "FAIL","failures":failures}
