from __future__ import annotations
from typing import Any, Mapping, Protocol, Sequence

from .models import ExecutionContext, HumanGateProof

Json = Mapping[str, Any]

class SourceParser(Protocol):
    def parse(self, source_text: str, source_ref: str) -> Json: ...

class IncludeResolver(Protocol):
    def resolve(self, ast: Json, source_ref: str) -> tuple[Json, Mapping[str, str]]: ...

class TypeChecker(Protocol):
    def check(self, ast: Json) -> Sequence[Json]: ...

class StaticSafetyChecker(Protocol):
    def check(self, ast: Json, profile: Json) -> Sequence[Json]: ...

class CapabilityRegistry(Protocol):
    async def get(self, capability_id: str) -> Json: ...

class AuthorizationPDP(Protocol):
    async def authorize_skill(
        self, *, manifest: Json, nso: Json, context: ExecutionContext
    ) -> Json: ...

class GateProofProvider(Protocol):
    async def get(self, proof_ref: str) -> HumanGateProof: ...

class SignatureVerifier(Protocol):
    async def verify_manifest_and_nso(self, manifest: Json, nso: Json) -> bool: ...

class SkillRegistry(Protocol):
    async def get_manifest(self, skill_id: str, version: str) -> Json: ...
    async def get_nso(self, skill_id: str, version: str) -> Json: ...

class CapabilityInvoker(Protocol):
    async def query(self, capability_id: str, payload: Json, context: ExecutionContext) -> Json: ...
    async def command(
        self, capability_id: str, payload: Json, context: ExecutionContext,
        idempotency_key: str, expected_version: str | int | None
    ) -> Json: ...
    async def verify(self, capability_id: str, command_result: Json, context: ExecutionContext) -> Json: ...

class IdempotencyStore(Protocol):
    async def get(self, skill_id: str, skill_version: str, idempotency_key: str) -> Json | None: ...
    async def begin(
        self, *, skill_id: str, skill_version: str, idempotency_key: str,
        semantic_payload_hash: str, execution_ref: str
    ) -> Json: ...
    async def complete(
        self, *, skill_id: str, skill_version: str, idempotency_key: str,
        commit_state: str, result: Json, verification: Json | None
    ) -> None: ...

class ReplayProvider(Protocol):
    async def node_result(self, replay_bundle_ref: str, node_id: str) -> Json: ...

class AuditSink(Protocol):
    async def append(self, event_name: str, detail: Json, context: ExecutionContext) -> None: ...

class ExpressionEvaluator(Protocol):
    def evaluate(self, expression: Json, symbols: Mapping[str, Any]) -> Any: ...
