PROJECT_TRANSITIONS = {
    "DRAFT":{"ACTIVE","CANCELLED"},
    "ACTIVE":{"ON_HOLD","CLOSED","CANCELLED"},
    "ON_HOLD":{"ACTIVE","CLOSED","CANCELLED"},
    "CLOSED":set(),
    "CANCELLED":set(),
}
ACCOUNT_TRANSITIONS = {
    "DRAFT":{"ACTIVE","RETIRED"},
    "ACTIVE":{"INACTIVE","RETIRED"},
    "INACTIVE":{"ACTIVE","RETIRED"},
    "RETIRED":set(),
}
VOUCHER_TRANSITIONS = {
    "DRAFT":{"SUBMITTED","CANCELLED"},
    "SUBMITTED":{"APPROVAL_PENDING","APPROVED","REJECTED","CANCELLED"},
    "APPROVAL_PENDING":{"APPROVED","REJECTED","CANCELLED"},
    "APPROVED":{"POSTING","CANCELLED"},
    "POSTING":{"POSTED"},
    "POSTED":{"REVERSED"},
    "REJECTED":set(),
    "REVERSED":set(),
    "CANCELLED":set(),
}
FISCAL_PERIOD_TRANSITIONS = {
    "OPEN":{"SOFT_CLOSED","CLOSED"},
    "SOFT_CLOSED":{"OPEN","CLOSED"},
    "CLOSED":{"OPEN"},  # reopen requires explicit privileged domain command/audit
}

def assert_transition(table:dict[str,set[str]],current:str,target:str,code:str)->None:
    if target not in table.get(current,set()):
        raise ValueError(f"{code}:{current}->{target}")
