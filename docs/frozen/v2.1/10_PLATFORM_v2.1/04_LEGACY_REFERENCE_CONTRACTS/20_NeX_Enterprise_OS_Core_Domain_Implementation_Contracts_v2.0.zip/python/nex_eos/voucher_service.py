from __future__ import annotations
from .invariants import validate_voucher, assert_project_postable, assert_account_usable
from .state_machines import VOUCHER_TRANSITIONS, assert_transition

class VoucherService:
    def __init__(self, vouchers, projects, accounts, periods, approvals, pdp, gate_verifier, outbox):
        self.vouchers=vouchers; self.projects=projects; self.accounts=accounts; self.periods=periods
        self.approvals=approvals; self.pdp=pdp; self.gate_verifier=gate_verifier; self.outbox=outbox

    async def create_draft(self, voucher, *, context, confirmation_proof_ref, idempotency_key):
        validate_voucher(voucher)
        project=await self.projects.get(voucher.project_ref.entity_id)
        assert_project_postable(project)
        for line in voucher.lines:
            account=await self.accounts.get(line.account_ref.entity_id)
            assert_account_usable(account,voucher.transaction_date)
        decision=await self.pdp.authorize("FINANCE.CREATE_VOUCHER_DRAFT",context,[voucher.project_ref.model_dump()])
        if not decision.get("allowed",False):
            raise PermissionError("VOUCHER_CREATE_DENIED")
        # Gate verification is delegated to HumanGateVerifier using the same frozen payload/intention.
        await self.gate_verifier.verify(
            confirmation_proof_ref,
            protected_payload=voucher.model_dump(mode="json"),
            write_intent={"capability_id":"FINANCE.CREATE_VOUCHER_DRAFT","operation_key":"CREATE_VOUCHER_DRAFT"},
            context=context,
        )
        created=await self.vouchers.create_draft(voucher,idempotency_key)
        await self.outbox.append({
            "event_name":"VOUCHER_DRAFT_CREATED",
            "voucher_id":created.voucher_id,
            "correlation_id":context["correlation_id"],
        })
        return created

    async def submit(self, voucher_id, *, context):
        v=await self.vouchers.get(voucher_id)
        assert_transition(VOUCHER_TRANSITIONS,v.state.value,"SUBMITTED","INVALID_VOUCHER_TRANSITION")
        return await self.vouchers.update_state(voucher_id,v.version,"SUBMITTED",{})

    async def mark_approval_pending(self, voucher_id, approval_instance_ref, *, context):
        v=await self.vouchers.get(voucher_id)
        assert_transition(VOUCHER_TRANSITIONS,v.state.value,"APPROVAL_PENDING","INVALID_VOUCHER_TRANSITION")
        return await self.vouchers.update_state(voucher_id,v.version,"APPROVAL_PENDING",{"approval_instance_ref":approval_instance_ref})
