from __future__ import annotations
from .invariants import validate_project_shape
from .state_machines import PROJECT_TRANSITIONS, assert_transition

class ProjectService:
    def __init__(self, projects, pdp, outbox):
        self.projects=projects
        self.pdp=pdp
        self.outbox=outbox

    async def create(self, project, *, context, idempotency_key):
        validate_project_shape(project)
        decision=await self.pdp.authorize("PROJECT.CREATE",context,[])
        if not decision.get("allowed",False):
            raise PermissionError("PROJECT_CREATE_DENIED")
        created=await self.projects.create(project,idempotency_key)
        await self.outbox.append({
            "event_name":"PROJECT_CREATED",
            "project_id":created.project_id,
            "project_type":created.project_type.value,
            "correlation_id":context["correlation_id"],
        })
        return created

    async def change_state(self, project_id, target_state, *, context, reason=None):
        project=await self.projects.get(project_id)
        assert_transition(PROJECT_TRANSITIONS,project.status.value,target_state,"INVALID_PROJECT_TRANSITION")
        decision=await self.pdp.authorize("PROJECT.CHANGE_STATE",context,[{"entity_type":"PROJECT","entity_id":project_id}])
        if not decision.get("allowed",False):
            raise PermissionError("PROJECT_STATE_DENIED")
        return await self.projects.update_state(project_id,project.version,target_state,context["business_actor_ref"],reason)
