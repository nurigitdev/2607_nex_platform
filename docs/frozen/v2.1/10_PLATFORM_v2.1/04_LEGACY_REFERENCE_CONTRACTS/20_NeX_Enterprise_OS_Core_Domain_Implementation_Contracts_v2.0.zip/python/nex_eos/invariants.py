from __future__ import annotations
from collections import defaultdict
from decimal import Decimal
from .models import Project, ProjectType, ProjectState, Account, AccountState, Voucher, VoucherState, FiscalPeriod, FiscalPeriodState

def validate_project_shape(project: Project) -> None:
    t=project.project_type
    if t in {ProjectType.NVT, ProjectType.COMMON}:
        if project.parent_project_ref is not None:
            raise ValueError("PROJECT_PARENT_FORBIDDEN")
    elif t == ProjectType.MOTHER:
        if project.parent_project_ref is None or project.parent_project_ref.entity_type!="PROJECT":
            raise ValueError("MOTHER_REQUIRES_NVT_PARENT")
    elif t == ProjectType.CHILD:
        if project.parent_project_ref is None or project.parent_project_ref.entity_type!="PROJECT":
            raise ValueError("CHILD_REQUIRES_MOTHER_PARENT")
    if project.end_date and project.end_date < project.start_date:
        raise ValueError("PROJECT_DATE_RANGE_INVALID")

def assert_project_postable(project: Project) -> None:
    if project.status != ProjectState.ACTIVE:
        raise ValueError("PROJECT_NOT_ACTIVE_FOR_POSTING")
    if project.project_type == ProjectType.NVT:
        raise ValueError("NVT_PROJECT_NOT_DIRECT_TRANSACTION_TARGET")

def assert_account_usable(account: Account, transaction_date) -> None:
    if account.status != AccountState.ACTIVE:
        raise ValueError("ACCOUNT_NOT_ACTIVE")
    if transaction_date < account.effective_from:
        raise ValueError("ACCOUNT_NOT_EFFECTIVE_YET")
    if account.effective_to and transaction_date > account.effective_to:
        raise ValueError("ACCOUNT_EXPIRED")

def validate_voucher(voucher: Voucher) -> None:
    if len(voucher.lines) < 2:
        raise ValueError("VOUCHER_MIN_TWO_LINES")
    line_nos=[x.line_no for x in voucher.lines]
    if len(set(line_nos)) != len(line_nos):
        raise ValueError("VOUCHER_DUPLICATE_LINE_NO")
    currencies={x.amount.currency for x in voucher.lines}
    if currencies != {voucher.currency}:
        raise ValueError("VOUCHER_CURRENCY_MISMATCH")
    debit=sum((x.amount.amount for x in voucher.lines if x.side.value=="DEBIT"),Decimal("0"))
    credit=sum((x.amount.amount for x in voucher.lines if x.side.value=="CREDIT"),Decimal("0"))
    if debit != credit:
        raise ValueError("VOUCHER_NOT_BALANCED")
    if any(x.amount.amount <= 0 for x in voucher.lines):
        raise ValueError("VOUCHER_LINE_AMOUNT_MUST_BE_POSITIVE")

def assert_voucher_editable(voucher: Voucher) -> None:
    if voucher.state != VoucherState.DRAFT:
        raise ValueError("VOUCHER_IMMUTABLE_AFTER_SUBMIT")

def assert_period_postable(period: FiscalPeriod, privileged_reopen: bool=False) -> None:
    if period.status == FiscalPeriodState.CLOSED and not privileged_reopen:
        raise ValueError("FISCAL_PERIOD_CLOSED")
    if period.status == FiscalPeriodState.SOFT_CLOSED and not privileged_reopen:
        raise ValueError("FISCAL_PERIOD_SOFT_CLOSED")
