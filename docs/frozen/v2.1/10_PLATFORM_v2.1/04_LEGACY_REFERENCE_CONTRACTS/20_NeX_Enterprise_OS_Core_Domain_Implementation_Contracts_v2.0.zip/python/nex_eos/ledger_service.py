from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from .models import LedgerEntry, EntityRef, Money, LedgerCategory, EntrySide
from .invariants import validate_voucher, assert_project_postable, assert_account_usable, assert_period_postable
from .state_machines import VOUCHER_TRANSITIONS, assert_transition

class LedgerPostingService:
    def __init__(self, vouchers, projects, accounts, periods, approvals, ledger,
                 pdp, gate_verifier, id_generator, clock, outbox):
        self.vouchers=vouchers; self.projects=projects; self.accounts=accounts; self.periods=periods
        self.approvals=approvals; self.ledger=ledger; self.pdp=pdp; self.gate_verifier=gate_verifier
        self.id_generator=id_generator; self.clock=clock; self.outbox=outbox

    async def post_voucher(self, voucher_id:str, *, context, approval_proof_ref:str|None,
                           idempotency_key:str, posting_date):
        existing=await self.ledger.find_posting_by_idempotency(idempotency_key)
        if existing:
            return existing

        voucher=await self.vouchers.get(voucher_id)
        validate_voucher(voucher)
        if voucher.state.value!="APPROVED":
            raise ValueError("VOUCHER_NOT_APPROVED")
        project=await self.projects.get(voucher.project_ref.entity_id)
        assert_project_postable(project)
        period=await self.periods.get_for_date(posting_date)
        assert_period_postable(period)

        decision=await self.pdp.authorize("LEDGER.POST_FROM_VOUCHER",context,[voucher.project_ref.model_dump()])
        if not decision.get("allowed",False):
            raise PermissionError("LEDGER_POST_DENIED")
        if approval_proof_ref:
            await self.gate_verifier.verify(
                approval_proof_ref,
                protected_payload=voucher.model_dump(mode="json"),
                write_intent={"capability_id":"LEDGER.POST_FROM_VOUCHER","operation_key":"POST_VOUCHER"},
                context=context,
            )

        posting_id=self.id_generator.new_id()
        entries=[]
        for line in voucher.lines:
            account=await self.accounts.get(line.account_ref.entity_id)
            assert_account_usable(account,posting_date)
            category = line.economic_category if line.economic_category!="NONE" else account.management_category
            if category=="NONE":
                raise ValueError("LEDGER_CATEGORY_REQUIRED")
            entries.append(LedgerEntry(
                ledger_entry_id=self.id_generator.new_id(),
                posting_id=posting_id,
                project_ref=voucher.project_ref,
                account_ref=line.account_ref,
                source_transaction_ref=EntityRef(entity_type="VOUCHER",entity_id=voucher.voucher_id,version=voucher.version),
                source_transaction_line_ref=EntityRef(entity_type="VOUCHER_LINE",entity_id=line.line_id),
                category=LedgerCategory(category),
                side=line.side,
                amount=line.amount,
                posting_date=posting_date,
                period_ref=EntityRef(entity_type="FISCAL_PERIOD",entity_id=period.period_id,version=period.version),
                description=line.description,
            ))
        result=await self.ledger.append_posting({
            "posting_id":posting_id,
            "source_transaction_ref":{"entity_type":"VOUCHER","entity_id":voucher.voucher_id},
            "posting_date":str(posting_date),
            "period_ref":{"entity_type":"FISCAL_PERIOD","entity_id":period.period_id},
            "currency":voucher.currency,
            "idempotency_key":idempotency_key,
        },entries)
        await self.vouchers.update_state(voucher.voucher_id,voucher.version,"POSTED",{"posting_date":str(posting_date)})
        await self.outbox.append({
            "event_name":"LEDGER_ENTRY_POSTED",
            "posting_id":posting_id,
            "voucher_id":voucher.voucher_id,
            "project_id":voucher.project_ref.entity_id,
            "correlation_id":context["correlation_id"],
        })
        return result
