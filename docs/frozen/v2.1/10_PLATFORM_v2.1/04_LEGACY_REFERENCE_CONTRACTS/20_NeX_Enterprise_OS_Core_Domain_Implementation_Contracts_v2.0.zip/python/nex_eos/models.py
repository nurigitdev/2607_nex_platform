from __future__ import annotations
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any
from pydantic import BaseModel, ConfigDict, Field, field_validator

class ProjectType(StrEnum):
    NVT="NVT"; MOTHER="MOTHER"; CHILD="CHILD"; COMMON="COMMON"

class ProjectState(StrEnum):
    DRAFT="DRAFT"; ACTIVE="ACTIVE"; ON_HOLD="ON_HOLD"; CLOSED="CLOSED"; CANCELLED="CANCELLED"

class AccountState(StrEnum):
    DRAFT="DRAFT"; ACTIVE="ACTIVE"; INACTIVE="INACTIVE"; RETIRED="RETIRED"

class VoucherState(StrEnum):
    DRAFT="DRAFT"; SUBMITTED="SUBMITTED"; APPROVAL_PENDING="APPROVAL_PENDING"
    APPROVED="APPROVED"; REJECTED="REJECTED"; POSTING="POSTING"
    POSTED="POSTED"; REVERSED="REVERSED"; CANCELLED="CANCELLED"

class FiscalPeriodState(StrEnum):
    OPEN="OPEN"; SOFT_CLOSED="SOFT_CLOSED"; CLOSED="CLOSED"

class LedgerCategory(StrEnum):
    REVENUE="REVENUE"; LABOR="LABOR"; MATERIAL="MATERIAL"
    DIRECT_EXPENSE="DIRECT_EXPENSE"; COMMON_COST="COMMON_COST"; ADJUSTMENT="ADJUSTMENT"

class EntrySide(StrEnum):
    DEBIT="DEBIT"; CREDIT="CREDIT"

class Money(BaseModel):
    model_config=ConfigDict(extra="forbid", frozen=True)
    amount: Decimal
    currency: str = Field(min_length=3,max_length=3)

    @field_validator("currency")
    @classmethod
    def upper_currency(cls,v:str)->str:
        if v.upper()!=v:
            raise ValueError("CURRENCY_MUST_BE_UPPERCASE")
        return v

class EntityRef(BaseModel):
    model_config=ConfigDict(extra="forbid", frozen=True)
    entity_type: str
    entity_id: str
    version: str|int|None=None
    status: str|None=None

class Project(BaseModel):
    model_config=ConfigDict(extra="forbid")
    project_id: str
    project_code: str
    name: str
    project_type: ProjectType
    status: ProjectState
    parent_project_ref: EntityRef|None=None
    nvt_project_ref: EntityRef|None=None
    owner_ref: EntityRef
    organization_ref: EntityRef|None=None
    currency: str
    start_date: date
    end_date: date|None=None
    version: int=0

class Account(BaseModel):
    model_config=ConfigDict(extra="forbid")
    account_id: str
    account_code: str
    name: str
    account_type: str
    status: AccountState
    management_category: str
    normal_balance: str
    effective_from: date
    effective_to: date|None=None
    version: int=0

class VoucherLine(BaseModel):
    model_config=ConfigDict(extra="forbid", frozen=True)
    line_id: str
    line_no: int
    account_ref: EntityRef
    side: EntrySide
    amount: Money
    economic_category: str
    description: str|None=None
    artifact_refs: tuple[EntityRef,...]=()
    evidence_refs: tuple[EntityRef,...]=()

class Voucher(BaseModel):
    model_config=ConfigDict(extra="forbid")
    voucher_id: str
    voucher_no: str
    voucher_type: str
    state: VoucherState
    project_ref: EntityRef
    currency: str
    transaction_date: date
    posting_date: date|None=None
    requester_ref: EntityRef
    approval_instance_ref: EntityRef|None=None
    reversal_of_voucher_ref: EntityRef|None=None
    lines: tuple[VoucherLine,...]
    payload_hash: str|None=None
    write_intent_hash: str|None=None
    version: int=0

class FiscalPeriod(BaseModel):
    model_config=ConfigDict(extra="forbid")
    period_id: str
    fiscal_year: int
    period_no: int
    start_date: date
    end_date: date
    status: FiscalPeriodState
    currency: str
    version: int=0

class LedgerEntry(BaseModel):
    model_config=ConfigDict(extra="forbid", frozen=True)
    ledger_entry_id: str
    posting_id: str
    project_ref: EntityRef
    account_ref: EntityRef
    source_transaction_ref: EntityRef
    source_transaction_line_ref: EntityRef|None=None
    category: LedgerCategory
    side: EntrySide
    amount: Money
    posting_date: date
    period_ref: EntityRef
    reversal_of_entry_ref: EntityRef|None=None
    description: str|None=None
    dimensions: dict[str,Any]={}
