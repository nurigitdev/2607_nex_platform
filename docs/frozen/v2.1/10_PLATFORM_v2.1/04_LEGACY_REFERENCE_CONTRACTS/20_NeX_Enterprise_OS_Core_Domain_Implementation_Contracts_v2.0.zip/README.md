# NeX Enterprise OS Core Domain v2.0 Reference Package

Accompanies `20_NeX_Enterprise_OS_Core_Domain_Detailed_Design_v2.0`.

## Aggregate design
- Project aggregate family: NVT / MOTHER / CHILD / COMMON typed Project root.
- Account aggregate: canonical posting/account master.
- Voucher aggregate: Voucher root owns immutable-after-submit VoucherLine children.
- Approval aggregate: reused from Document 18 Enterprise OS Approval Engine; referenced by voucher.
- Ledger Posting aggregate: one atomic posting batch owns immutable LedgerEntry facts.
- FiscalPeriod aggregate: posting-open/soft-close/close governance.

## Safety/integrity
1. NVT and COMMON projects cannot be direct transaction targets; MOTHER/CHILD hierarchy is validated by domain rules.
2. Voucher financial amounts use Decimal/Money semantics, never Float.
3. Voucher must balance before posting.
4. Submitted voucher values become immutable; corrections use reversal/adjustment.
5. LedgerEntry has no update/delete business API. Reversal is another immutable entry/posting.
6. P/L is a query/projection over Project Financial Ledger facts.
7. Approval proof and current authorization are required where policy says so.
8. Posting is idempotent and period/project/account state is revalidated inside transaction.
9. Cross-service work/identity/artifact refs are logical stable refs; no cross-DB direct write.
10. SQL is a reference physical design; actual Alembic migrations should be aligned after repository inspection.

All six JSON schemas/examples and Python syntax are validated during artifact generation.
