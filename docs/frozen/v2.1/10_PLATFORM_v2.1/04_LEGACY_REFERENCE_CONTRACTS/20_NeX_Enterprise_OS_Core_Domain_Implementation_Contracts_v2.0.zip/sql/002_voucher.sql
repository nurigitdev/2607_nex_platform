-- Voucher Aggregate
CREATE TABLE IF NOT EXISTS nex_eos.voucher (
    voucher_id              uuid PRIMARY KEY,
    voucher_no              varchar(80) NOT NULL UNIQUE,
    voucher_type            varchar(32) NOT NULL,
    state                   varchar(32) NOT NULL,
    project_id              uuid NOT NULL REFERENCES nex_eos.project(project_id),
    currency                char(3) NOT NULL,
    transaction_date        date NOT NULL,
    posting_date            date,
    description             text,
    requester_ref           varchar(160) NOT NULL,
    approval_instance_id    uuid,
    reversal_of_voucher_id  uuid REFERENCES nex_eos.voucher(voucher_id),
    artifact_refs_json      jsonb NOT NULL DEFAULT '[]'::jsonb,
    evidence_refs_json      jsonb NOT NULL DEFAULT '[]'::jsonb,
    payload_hash            char(64),
    write_intent_hash       char(64),
    source_work_item_id     varchar(128),
    source_agent_execution_id varchar(128),
    source_plan_step_id     varchar(64),
    source_skill_ref        varchar(256),
    correlation_id          varchar(128) NOT NULL,
    causation_id            varchar(128),
    idempotency_key         varchar(256) NOT NULL UNIQUE,
    version                 bigint NOT NULL DEFAULT 0,
    created_at              timestamptz NOT NULL DEFAULT now(),
    updated_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_voucher_type CHECK (voucher_type IN ('EXPENSE','REVENUE','PURCHASE','ADJUSTMENT','REVERSAL','GENERAL')),
    CONSTRAINT ck_voucher_state CHECK (
      state IN ('DRAFT','SUBMITTED','APPROVAL_PENDING','APPROVED','REJECTED','POSTING','POSTED','REVERSED','CANCELLED')
    )
);
CREATE INDEX IF NOT EXISTS ix_voucher_project_state ON nex_eos.voucher(project_id,state,transaction_date);
CREATE INDEX IF NOT EXISTS ix_voucher_approval ON nex_eos.voucher(approval_instance_id);

CREATE TABLE IF NOT EXISTS nex_eos.voucher_line (
    line_id                 uuid PRIMARY KEY,
    voucher_id              uuid NOT NULL REFERENCES nex_eos.voucher(voucher_id) ON DELETE RESTRICT,
    line_no                 integer NOT NULL,
    account_id              uuid NOT NULL REFERENCES nex_eos.account(account_id),
    side                    varchar(8) NOT NULL,
    amount                  numeric(38,12) NOT NULL,
    currency                char(3) NOT NULL,
    economic_category       varchar(32) NOT NULL,
    description             text,
    artifact_refs_json      jsonb NOT NULL DEFAULT '[]'::jsonb,
    evidence_refs_json      jsonb NOT NULL DEFAULT '[]'::jsonb,
    dimensions_json         jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at              timestamptz NOT NULL DEFAULT now(),
    UNIQUE(voucher_id,line_no),
    CONSTRAINT ck_voucher_line_side CHECK (side IN ('DEBIT','CREDIT')),
    CONSTRAINT ck_voucher_line_amount CHECK (amount > 0),
    CONSTRAINT ck_voucher_line_category CHECK (
      economic_category IN ('REVENUE','LABOR','MATERIAL','DIRECT_EXPENSE','COMMON_COST','ADJUSTMENT','NONE')
    )
);

-- Voucher balance and account/project effective validation belong to domain service
-- and should also be protected by database-side posting procedure/transaction checks.
