-- Voucher approval -> ledger posting transaction boundary reference

-- PRECONDITIONS in application/domain:
-- 1) voucher state APPROVED
-- 2) exact Approval/HumanGate proof valid for the protected operation/payload
-- 3) project ACTIVE and direct transaction target
-- 4) accounts ACTIVE/effective
-- 5) fiscal period OPEN
-- 6) voucher balanced
-- 7) current authorization/PDP allows LEDGER.POST_FROM_VOUCHER

BEGIN;

SELECT *
  FROM nex_eos.voucher
 WHERE voucher_id=:voucher_id
 FOR UPDATE;

SELECT *
  FROM nex_eos.fiscal_period
 WHERE period_id=:period_id
 FOR UPDATE;

-- Check expected voucher version and period status again inside transaction.

INSERT INTO nex_eos.ledger_posting(
    posting_id, source_transaction_type, source_transaction_id,
    posting_date, period_id, currency, entry_count, entries_hash,
    idempotency_key, correlation_id, causation_id, created_by_ref
) VALUES (
    :posting_id, 'VOUCHER', :voucher_id,
    :posting_date, :period_id, :currency, :entry_count, :entries_hash,
    :idempotency_key, :correlation_id, :causation_id, :actor_ref
)
ON CONFLICT (idempotency_key) DO NOTHING;

-- If conflict occurred, application returns original posting; do not append duplicate entries.

INSERT INTO nex_eos.ledger_entry(
    ledger_entry_id, posting_id, project_id, account_id,
    source_transaction_type, source_transaction_id, source_transaction_line_id,
    category, side, amount, currency, posting_date, period_id,
    description, dimensions_json, source_work_item_id,
    source_agent_execution_id, correlation_id, causation_id
)
SELECT * FROM jsonb_to_recordset(:entries_json::jsonb) AS x(
    ledger_entry_id uuid, posting_id uuid, project_id uuid, account_id uuid,
    source_transaction_type varchar, source_transaction_id varchar, source_transaction_line_id varchar,
    category varchar, side varchar, amount numeric, currency char(3), posting_date date, period_id uuid,
    description text, dimensions_json jsonb, source_work_item_id varchar,
    source_agent_execution_id varchar, correlation_id varchar, causation_id varchar
);

UPDATE nex_eos.voucher
   SET state='POSTED',
       posting_date=:posting_date,
       version=version+1,
       updated_at=now()
 WHERE voucher_id=:voucher_id
   AND state='APPROVED'
   AND version=:expected_voucher_version;

-- Transactional outbox table is reused from Enterprise OS event infrastructure.
INSERT INTO nex_eos.event_outbox(
    outbox_id,event_id,event_name,aggregate_ref,payload_json,
    correlation_id,causation_id
) VALUES (
    :outbox_id,:event_id,'LEDGER_ENTRY_POSTED','VOUCHER:'||:voucher_id,
    :event_payload::jsonb,:correlation_id,:causation_id
);

COMMIT;

-- Reversal: create a NEW reversal voucher/posting/entries with negated economic effect.
-- Never UPDATE/DELETE original ledger entries.
