-- Project Financial Ledger
CREATE TABLE IF NOT EXISTS nex_eos.ledger_posting (
    posting_id              uuid PRIMARY KEY,
    source_transaction_type varchar(40) NOT NULL,
    source_transaction_id   varchar(160) NOT NULL,
    posting_date            date NOT NULL,
    period_id               uuid NOT NULL REFERENCES nex_eos.fiscal_period(period_id),
    currency                char(3) NOT NULL,
    entry_count             integer NOT NULL,
    entries_hash            char(64) NOT NULL,
    idempotency_key         varchar(256) NOT NULL UNIQUE,
    reversal_of_posting_id  uuid REFERENCES nex_eos.ledger_posting(posting_id),
    correlation_id          varchar(128) NOT NULL,
    causation_id            varchar(128),
    created_by_ref          varchar(160) NOT NULL,
    created_at              timestamptz NOT NULL DEFAULT now(),
    UNIQUE(source_transaction_type,source_transaction_id,posting_id)
);

CREATE TABLE IF NOT EXISTS nex_eos.ledger_entry (
    ledger_entry_id         uuid PRIMARY KEY,
    posting_id              uuid NOT NULL REFERENCES nex_eos.ledger_posting(posting_id) ON DELETE RESTRICT,
    project_id              uuid NOT NULL REFERENCES nex_eos.project(project_id),
    account_id              uuid NOT NULL REFERENCES nex_eos.account(account_id),
    source_transaction_type varchar(40) NOT NULL,
    source_transaction_id   varchar(160) NOT NULL,
    source_transaction_line_id varchar(160),
    category                varchar(32) NOT NULL,
    side                    varchar(8) NOT NULL,
    amount                  numeric(38,12) NOT NULL,
    currency                char(3) NOT NULL,
    posting_date            date NOT NULL,
    period_id               uuid NOT NULL REFERENCES nex_eos.fiscal_period(period_id),
    reversal_of_entry_id    uuid REFERENCES nex_eos.ledger_entry(ledger_entry_id),
    description             text,
    dimensions_json         jsonb NOT NULL DEFAULT '{}'::jsonb,
    source_work_item_id     varchar(128),
    source_agent_execution_id varchar(128),
    correlation_id          varchar(128) NOT NULL,
    causation_id            varchar(128),
    created_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_ledger_category CHECK (
      category IN ('REVENUE','LABOR','MATERIAL','DIRECT_EXPENSE','COMMON_COST','ADJUSTMENT')
    ),
    CONSTRAINT ck_ledger_side CHECK (side IN ('DEBIT','CREDIT')),
    CONSTRAINT ck_ledger_amount CHECK (amount > 0)
);
CREATE INDEX IF NOT EXISTS ix_ledger_project_period ON nex_eos.ledger_entry(project_id,period_id,category,posting_date);
CREATE INDEX IF NOT EXISTS ix_ledger_source ON nex_eos.ledger_entry(source_transaction_type,source_transaction_id);

-- No UPDATE/DELETE API is defined for ledger_entry.
-- Corrections append reversal/adjustment entries in a new posting.
