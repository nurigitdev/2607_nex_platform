-- Project / Account / Fiscal Period
CREATE SCHEMA IF NOT EXISTS nex_eos;

CREATE TABLE IF NOT EXISTS nex_eos.project (
    project_id              uuid PRIMARY KEY,
    project_code            varchar(80) NOT NULL UNIQUE,
    name                    varchar(300) NOT NULL,
    project_type            varchar(16) NOT NULL,
    status                  varchar(24) NOT NULL,
    parent_project_id       uuid REFERENCES nex_eos.project(project_id),
    nvt_project_id          uuid REFERENCES nex_eos.project(project_id),
    owner_ref               varchar(160) NOT NULL,
    organization_ref        varchar(160),
    currency                char(3) NOT NULL,
    start_date              date NOT NULL,
    end_date                date,
    financial_scope_json    jsonb NOT NULL DEFAULT '{}'::jsonb,
    metadata_json           jsonb NOT NULL DEFAULT '{}'::jsonb,
    correlation_id          varchar(128) NOT NULL,
    source_work_item_id     varchar(128),
    source_agent_execution_id varchar(128),
    version                 bigint NOT NULL DEFAULT 0,
    created_at              timestamptz NOT NULL DEFAULT now(),
    updated_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_project_type CHECK (project_type IN ('NVT','MOTHER','CHILD','COMMON')),
    CONSTRAINT ck_project_status CHECK (status IN ('DRAFT','ACTIVE','ON_HOLD','CLOSED','CANCELLED')),
    CONSTRAINT ck_project_dates CHECK (end_date IS NULL OR end_date >= start_date),
    CONSTRAINT ck_project_parent_shape CHECK (
        (project_type IN ('NVT','COMMON') AND parent_project_id IS NULL)
        OR (project_type IN ('MOTHER','CHILD') AND parent_project_id IS NOT NULL)
    )
);
CREATE INDEX IF NOT EXISTS ix_project_parent ON nex_eos.project(parent_project_id);
CREATE INDEX IF NOT EXISTS ix_project_nvt ON nex_eos.project(nvt_project_id);
CREATE INDEX IF NOT EXISTS ix_project_status_type ON nex_eos.project(status,project_type);

CREATE TABLE IF NOT EXISTS nex_eos.account (
    account_id              uuid PRIMARY KEY,
    account_code            varchar(64) NOT NULL UNIQUE,
    name                    varchar(300) NOT NULL,
    account_type            varchar(24) NOT NULL,
    status                  varchar(24) NOT NULL,
    management_category     varchar(32) NOT NULL,
    normal_balance          varchar(16) NOT NULL,
    allowed_transaction_types_json jsonb NOT NULL DEFAULT '[]'::jsonb,
    effective_from          date NOT NULL,
    effective_to            date,
    metadata_json           jsonb NOT NULL DEFAULT '{}'::jsonb,
    version                 bigint NOT NULL DEFAULT 0,
    created_at              timestamptz NOT NULL DEFAULT now(),
    updated_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_account_status CHECK (status IN ('DRAFT','ACTIVE','INACTIVE','RETIRED')),
    CONSTRAINT ck_account_category CHECK (
      management_category IN ('REVENUE','LABOR','MATERIAL','DIRECT_EXPENSE','COMMON_COST','ADJUSTMENT','NONE')
    ),
    CONSTRAINT ck_account_effective CHECK (effective_to IS NULL OR effective_to >= effective_from)
);

CREATE TABLE IF NOT EXISTS nex_eos.fiscal_period (
    period_id               uuid PRIMARY KEY,
    fiscal_year             integer NOT NULL,
    period_no               integer NOT NULL,
    start_date              date NOT NULL,
    end_date                date NOT NULL,
    status                  varchar(24) NOT NULL,
    currency                char(3) NOT NULL,
    closed_by_ref           varchar(160),
    closed_at               timestamptz,
    close_reason            text,
    version                 bigint NOT NULL DEFAULT 0,
    created_at              timestamptz NOT NULL DEFAULT now(),
    updated_at              timestamptz NOT NULL DEFAULT now(),
    UNIQUE(fiscal_year,period_no,currency),
    CONSTRAINT ck_period_status CHECK (status IN ('OPEN','SOFT_CLOSED','CLOSED')),
    CONSTRAINT ck_period_dates CHECK (end_date >= start_date)
);
CREATE INDEX IF NOT EXISTS ix_period_date ON nex_eos.fiscal_period(start_date,end_date,status);
