-- Enterprise OS common idempotency/outbox/audit structures

CREATE TABLE IF NOT EXISTS nex_eos.command_idempotency (
    capability_id           varchar(160) NOT NULL,
    idempotency_key         varchar(256) NOT NULL,
    semantic_payload_hash   char(64) NOT NULL,
    commit_state            varchar(40) NOT NULL,
    result_json             jsonb,
    created_at              timestamptz NOT NULL DEFAULT now(),
    updated_at              timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY(capability_id,idempotency_key),
    CONSTRAINT ck_eos_commit_state CHECK (
      commit_state IN ('STARTED','COMMITTED','NOT_COMMITTED','UNKNOWN_COMMIT_STATE','RECONCILED')
    )
);

CREATE TABLE IF NOT EXISTS nex_eos.event_outbox (
    outbox_id               uuid PRIMARY KEY,
    event_id                varchar(128) NOT NULL UNIQUE,
    event_name              varchar(128) NOT NULL,
    aggregate_ref           varchar(256) NOT NULL,
    payload_json            jsonb NOT NULL,
    correlation_id          varchar(128),
    causation_id            varchar(128),
    state                   varchar(24) NOT NULL DEFAULT 'PENDING',
    attempts                integer NOT NULL DEFAULT 0,
    available_at            timestamptz NOT NULL DEFAULT now(),
    published_at            timestamptz,
    created_at              timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_eos_outbox_publish
    ON nex_eos.event_outbox(state,available_at,created_at);

CREATE TABLE IF NOT EXISTS nex_eos.domain_audit_event (
    audit_event_id          uuid PRIMARY KEY,
    aggregate_type          varchar(80) NOT NULL,
    aggregate_id            varchar(160) NOT NULL,
    event_name              varchar(128) NOT NULL,
    actor_ref               varchar(160),
    principal_ref           varchar(160),
    policy_ref              varchar(256),
    detail_json             jsonb,
    correlation_id          varchar(128),
    causation_id            varchar(128),
    occurred_at             timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_eos_audit_aggregate
    ON nex_eos.domain_audit_event(aggregate_type,aggregate_id,occurred_at);
