# Reference pseudo-test
# Spawn >=10 workers against an isolated PostgreSQL DB.
# Assert one active lease/claim per job and stale lease token cannot complete it.
