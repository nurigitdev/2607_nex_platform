"""Reference only: isolated PostgreSQL test DB + deterministic clock/IDs."""
import pytest

@pytest.fixture
def canonical_context():
    return {"employee_id":"E-001","project_id":"P-A","correlation_id":"C-001"}

def test_retry_classifier_unknown_commit_never_retries():
    outcome = classify_retry(operation_kind="WRITE", commit_state="UNKNOWN_COMMIT_STATE")
    assert outcome == "RECONCILE_FIRST"

def classify_retry(operation_kind, commit_state):
    if operation_kind == "WRITE" and commit_state == "UNKNOWN_COMMIT_STATE":
        return "RECONCILE_FIRST"
    return "DO_NOT_RETRY"
