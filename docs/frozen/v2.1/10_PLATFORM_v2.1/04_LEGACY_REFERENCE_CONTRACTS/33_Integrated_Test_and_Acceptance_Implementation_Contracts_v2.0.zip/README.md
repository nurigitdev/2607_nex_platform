# 33 Integrated Test & Acceptance Reference Package

This package freezes the proof model for NeX v2.0: Unit → Contract → Integration → Fault Injection → E2E → Golden Slice → Acceptance → Regression Gate.

Important clarifications:
- Golden Slice A direct voucher flow must pass without CX; CX is optional evidence support.
- Golden Slice B requires Canonical Plan, WC Work SoR, current OA reauthorization, event dedup/resume, and WA Work Activity trace.
- UNKNOWN_COMMIT_STATE never blind-retries.
