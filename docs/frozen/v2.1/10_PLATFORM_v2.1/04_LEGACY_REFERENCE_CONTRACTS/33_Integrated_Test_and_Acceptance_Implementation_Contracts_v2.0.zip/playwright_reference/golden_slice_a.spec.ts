// Reference only
// Verify direct voucher path does not require CX, gate UI is explicit, and success only follows authoritative commit/result.
