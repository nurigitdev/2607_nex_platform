// Reference only
// Verify Parent/Child WorkItem, current reauthorization, one resume after duplicate event, WA activity visibility, and human closure.
