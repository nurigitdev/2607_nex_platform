# Golden Slice A
Mandatory injection: ambiguous project; evidence insufficient; permission deny; gate expiry; duplicate write; provider commit timeout/unknown; ledger projection delay.
