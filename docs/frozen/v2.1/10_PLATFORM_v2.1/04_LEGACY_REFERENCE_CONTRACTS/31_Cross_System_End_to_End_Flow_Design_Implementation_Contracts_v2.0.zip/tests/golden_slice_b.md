# Golden Slice B
Mandatory injection: unroutable child; claim expiry; role revoke; duplicate WORK_RESULT_SUBMITTED; child reject/cancel; result schema mismatch; parent resume dedup.
