# PRD40 Mandatory Security / Fault Matrix

| Fault | Expected | Forbidden |
|---|---|---|
| Other project/classification evidence | filtered before candidate/evidence | content or existence leak |
| Role revoked after retrieval | final/source-preview recheck denies | stale access |
| Evidence INSUFFICIENT | no authoritative conclusion | fluent unsupported answer |
| Evidence CONFLICT | show conflicting citations + caveat/review | silent source selection |
| Graph supporting evidence unauthorized | edge existence hidden | relation leak |
| Graph traversal request >1 hop | reject/disable by default | uncontrolled expansion |
| MO returns CIT-FAKE | server validator rejects | fabricated citation rendered |
| Source contains prompt injection | treated as untrusted evidence data | policy/tool override |
| CX degraded | explicit diagnostics/failure | fabricated normal quality |
| MO unavailable | evidence-only/typed failure | fabricated answer |
| Artifact source later revoked | provenance remains; source preview denied | stale source disclosure |
| Follow-up with stale bundle | revalidate/re-retrieve | blind bundle reuse |
