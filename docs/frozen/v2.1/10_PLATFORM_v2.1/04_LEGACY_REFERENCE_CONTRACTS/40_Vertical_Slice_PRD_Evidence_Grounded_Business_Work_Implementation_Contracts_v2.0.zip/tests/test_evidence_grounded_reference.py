import pytest
from evidence_grounded_reference import decide_quality, validate_citations

def test_insufficient_blocks_authoritative_generation():
    d = decide_quality("INSUFFICIENT")
    assert d.allow_generation is False

def test_conflict_requires_human_review():
    d = decide_quality("CONFLICT")
    assert d.require_caveat and d.require_human_review

def test_unknown_citation_is_rejected():
    with pytest.raises(ValueError):
        validate_citations([{"citation_ids":["CIT-FAKE"]}], {"CIT-1","CIT-2"})

def test_allowed_citations_pass():
    validate_citations([{"citation_ids":["CIT-1"]}], {"CIT-1","CIT-2"})
