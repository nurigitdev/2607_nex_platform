from dataclasses import dataclass
from typing import Iterable

@dataclass(frozen=True)
class QualityDecision:
    allow_generation: bool
    require_caveat: bool
    require_human_review: bool

def decide_quality(quality: str) -> QualityDecision:
    table = {
        "SUFFICIENT": QualityDecision(True, False, False),
        "PARTIAL": QualityDecision(True, True, False),
        "INSUFFICIENT": QualityDecision(False, True, False),
        "CONFLICT": QualityDecision(True, True, True),
    }
    if quality not in table:
        raise ValueError("unknown evidence quality")
    return table[quality]

def validate_citations(sections: Iterable[dict], allowed_ids: set[str]) -> None:
    for section in sections:
        for cid in section.get("citation_ids", []):
            if cid not in allowed_ids:
                raise ValueError(f"unknown/fabricated citation: {cid}")

def build_artifact_provenance(*, artifact_id, version, request_ref, execution_ref, bundle, prompt_version, model_version, citation_ids):
    return {
        "artifact_id": artifact_id, "artifact_version": version,
        "request_ref": request_ref, "execution_ref": execution_ref,
        "evidence_bundle_ref": bundle["bundle_id"], "bundle_hash": bundle["bundle_hash"],
        "retrieval_profile": bundle["retrieval_profile"], "policy_version": bundle["policy_version"],
        "prompt_version": prompt_version, "model_version": model_version,
        "evidence_quality": bundle["evidence_quality"], "citation_ids": sorted(set(citation_ids)),
    }
