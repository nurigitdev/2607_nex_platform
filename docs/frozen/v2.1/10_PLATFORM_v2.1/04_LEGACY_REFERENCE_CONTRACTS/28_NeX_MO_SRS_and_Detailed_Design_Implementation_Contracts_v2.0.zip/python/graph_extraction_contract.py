from dataclasses import dataclass

@dataclass
class RelationCandidate:
    subject: str
    predicate: str
    object: str
    confidence: float
    evidence_start: int
    evidence_end: int

# This output is a candidate only. CX validates source evidence, permission and provenance
# before persisting an authoritative Graph-lite relation.
