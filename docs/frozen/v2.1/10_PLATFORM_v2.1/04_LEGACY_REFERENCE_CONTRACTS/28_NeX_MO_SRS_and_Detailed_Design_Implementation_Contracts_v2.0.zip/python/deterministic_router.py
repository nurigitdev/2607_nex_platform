from dataclasses import dataclass
from typing import Iterable

@dataclass(frozen=True)
class RouteRequest:
    capability: str
    classification_rank: int
    compatibility_key: str | None
    schema_version: str | None

@dataclass(frozen=True)
class Deployment:
    deployment_id: str
    capability: str
    security_ceiling: int
    egress_mode: str
    compatibility_key: str | None
    schema_version: str | None
    health: str
    capacity_ok: bool

def eligible(req: RouteRequest, d: Deployment) -> bool:
    if d.capability != req.capability or d.health != "READY" or not d.capacity_ok:
        return False
    if req.classification_rank > d.security_ceiling:
        return False
    if req.capability == "EMBEDDING" and req.compatibility_key != d.compatibility_key:
        return False
    if req.capability == "ENTITY_RELATION_EXTRACTION" and req.schema_version and d.schema_version != req.schema_version:
        return False
    return True

def select(req: RouteRequest, deployments: Iterable[Deployment]):
    candidates=[d for d in deployments if eligible(req,d)]
    if not candidates:
        return None
    return sorted(candidates,key=lambda d:d.deployment_id)[0]
