def validate_embedding_compatibility(requested_key: str, deployment_key: str) -> None:
    if requested_key != deployment_key:
        raise ValueError("Embedding compatibility mismatch: do not fallback across vector spaces")
