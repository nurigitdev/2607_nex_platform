# NeX-MO v2.0 Implementation Contracts

Reference package for Model Registry, Provider Adapter, vLLM serving, Embedding/Reranker/Extraction, deterministic Routing, Health, Capacity, Versioning and Model Security. Graph-lite storage/permission/evidence remains owned by NeX-CX.
