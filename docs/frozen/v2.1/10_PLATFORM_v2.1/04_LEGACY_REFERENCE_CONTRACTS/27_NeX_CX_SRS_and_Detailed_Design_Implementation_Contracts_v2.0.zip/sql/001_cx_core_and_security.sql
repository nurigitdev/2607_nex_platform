CREATE TABLE cx_document (
  document_id uuid PRIMARY KEY,
  source_uri text,
  title text,
  status text NOT NULL,
  org_scope_ref text NOT NULL,
  project_scope_ref text,
  classification_code text NOT NULL,
  classification_rank integer NOT NULL,
  classification_policy_version text NOT NULL,
  security_source text NOT NULL,
  security_envelope_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE cx_chunk (
  chunk_id uuid PRIMARY KEY,
  document_id uuid NOT NULL REFERENCES cx_document(document_id),
  chunk_index integer NOT NULL,
  text_content text NOT NULL,
  heading_path text,
  source_locator jsonb,
  prev_chunk_id uuid,
  next_chunk_id uuid,
  status text NOT NULL DEFAULT 'READY',
  org_scope_ref text NOT NULL,
  project_scope_ref text,
  classification_code text NOT NULL,
  classification_rank integer NOT NULL,
  classification_policy_version text NOT NULL,
  security_envelope_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX ix_chunk_security
ON cx_chunk(status, org_scope_ref, project_scope_ref, classification_rank);
