CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE cx_embedding_2560 (
  chunk_id uuid NOT NULL REFERENCES cx_chunk(chunk_id),
  model_id text NOT NULL,
  model_version text NOT NULL,
  profile text NOT NULL,
  embedding vector(2560) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(chunk_id, profile)
);

CREATE TABLE cx_retrieval_query (
  query_id uuid PRIMARY KEY,
  query_hash text NOT NULL,
  authority_hash text NOT NULL,
  policy_version text NOT NULL,
  retrieval_profile text NOT NULL,
  diagnostics jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE cx_evidence_bundle (
  bundle_id uuid PRIMARY KEY,
  query_id uuid NOT NULL REFERENCES cx_retrieval_query(query_id),
  authority_hash text NOT NULL,
  policy_version text NOT NULL,
  evidence_quality text NOT NULL,
  bundle_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE cx_evidence_item (
  bundle_id uuid NOT NULL REFERENCES cx_evidence_bundle(bundle_id),
  ordinal integer NOT NULL,
  document_id uuid NOT NULL,
  chunk_id uuid NOT NULL,
  citation_label text NOT NULL,
  source_locator jsonb,
  scores jsonb,
  security_envelope_hash text NOT NULL,
  PRIMARY KEY(bundle_id, ordinal)
);
