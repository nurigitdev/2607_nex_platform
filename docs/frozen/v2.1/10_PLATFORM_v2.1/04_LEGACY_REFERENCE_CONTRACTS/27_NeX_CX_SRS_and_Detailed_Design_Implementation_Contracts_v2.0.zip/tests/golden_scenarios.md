# NeX-CX Golden Security Scenarios

1. Other-project semantic match never appears in BM25/vector/fusion/evidence.
2. Classification rank boundary is enforced at candidate and final recheck.
3. Multi-role privilege amplification is rejected: one binding must satisfy the full predicate.
4. RoleBinding revoked after candidate retrieval causes final evidence recheck denial.
5. Stale cache authority_hash or policy_version mismatch forces revalidation.
6. LLM metadata enrichment cannot lower authoritative classification.
7. Prev/next adjacency expansion performs permission check for every added chunk.
8. Vector provider failure returns explicit lexical-only degraded mode when policy allows.
9. Evidence Bundle hash and citation locator reproduce source evidence.
10. AE follow-up revalidates current authority before reusing prior evidence.
