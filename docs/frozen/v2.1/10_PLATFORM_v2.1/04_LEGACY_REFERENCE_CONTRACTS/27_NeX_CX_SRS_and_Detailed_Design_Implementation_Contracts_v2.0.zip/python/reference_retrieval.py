def retrieve(query, authority, bm25_repo, vector_repo, reranker, final_recheck, evidence_builder):
    predicate = authority.to_permission_predicate()
    lexical = bm25_repo.search(query, predicate=predicate)
    dense = vector_repo.search(query, predicate=predicate)
    permitted_candidates = fuse(lexical, dense)
    ranked = reranker.rerank(query, permitted_candidates)
    final_items = [c for c in ranked if final_recheck(authority, c.resource)]
    return evidence_builder.build(query=query, authority=authority, candidates=final_items)

def fuse(lexical, dense):
    # Placeholder: use versioned RRF/weighted fusion implementation.
    by_id = {}
    for c in lexical + dense:
        by_id[c.chunk_id] = c
    return list(by_id.values())
