from dataclasses import dataclass
from typing import Iterable

@dataclass(frozen=True)
class Binding:
    role_binding_id: str
    org_scopes: frozenset[str]
    project_scopes: frozenset[str]
    classification_ceiling: int
    capabilities: frozenset[str]

@dataclass(frozen=True)
class Resource:
    org_scope_ref: str
    project_scope_ref: str | None
    classification_rank: int
    status: str

def binding_allows(binding: Binding, resource: Resource) -> bool:
    if resource.status != "READY":
        return False
    if "context.read" not in binding.capabilities:
        return False
    if resource.org_scope_ref not in binding.org_scopes:
        return False
    if resource.project_scope_ref and resource.project_scope_ref not in binding.project_scopes:
        return False
    if resource.classification_rank > binding.classification_ceiling:
        return False
    return True

def authority_allows(bindings: Iterable[Binding], resource: Resource) -> bool:
    # Important: one binding must satisfy the whole predicate.
    # Do not combine org scope from one binding with classification ceiling from another.
    return any(binding_allows(b, resource) for b in bindings)
