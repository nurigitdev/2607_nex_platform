# 27_NeX_CX_SRS_and_Detailed_Design_v2.0 Implementation Contracts

Generated 2026-09-02.

This package is an implementation reference for NeX-CX v2.0:
- security metadata propagation
- permission-aware BM25/pgvector retrieval
- hybrid fusion
- Evidence Bundle
- AE Context

Important invariant: OA is the authority root. CX never grants permission using LLM inference.
