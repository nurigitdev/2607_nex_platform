# Vertical Slice Definition of Done

- Business value demonstrated end-to-end
- Frozen Requirement/ADR/Contract refs linked
- No cross-service DB write
- Current OA authorization enforced
- Failure/boundary/robustness variants automated
- Unit/Contract/Integration/E2E/Golden tests pass
- Critical security/reliability blockers = 0
- Traceability chain complete
- Acceptance Evidence Package generated
- Deployment/rollback/observability ready
- Migration/SoR gate passed if applicable
- Baseline tag recorded
