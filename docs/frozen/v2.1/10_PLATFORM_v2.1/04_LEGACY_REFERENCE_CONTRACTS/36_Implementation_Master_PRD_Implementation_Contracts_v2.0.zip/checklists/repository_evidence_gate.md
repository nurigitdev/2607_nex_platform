# Repository Evidence Gate

Before final KEEP/REFACTOR/REPLACE or effort baseline:

- [ ] repo/path/branch/commit frozen
- [ ] package/module tree inspected
- [ ] PostgreSQL schema/Alembic/grants inspected
- [ ] OpenAPI/JSON Schema/Event contracts exported
- [ ] runtime/deployment/job-worker behavior inspected
- [ ] auth/secret/permission/kill-switch inspected
- [ ] unit/integration/E2E/Playwright and coverage inspected
- [ ] logs/metrics/backup/runbook inspected where applicable
- [ ] Document 10 D1~D8 scored
- [ ] HG-01~08 hard gates reviewed
- [ ] disposition reviewed/approved

Until complete: disposition = NOT ASSESSED.
