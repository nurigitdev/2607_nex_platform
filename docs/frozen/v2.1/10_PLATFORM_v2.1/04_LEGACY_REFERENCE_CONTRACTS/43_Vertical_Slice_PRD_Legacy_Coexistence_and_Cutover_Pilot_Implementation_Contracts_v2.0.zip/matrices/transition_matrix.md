# Transition Matrix

| State | Authoritative Write | Read | Shadow | Legacy Mode |
|---|---|---|---|---|
| LEGACY | Legacy | Legacy | None | RW |
| READ_SYNC | Legacy | Legacy + Target ref | Optional | RW |
| DUAL_RUN_VALIDATION | Legacy | Policy | Target dry-run | RW |
| NEW_SYSTEM | Target | Target | Optional compare | no new write |
| LEGACY_READ_ONLY | Target | Target + historical Legacy | None | RO |
| ARCHIVED | Target | Target + archive path | None | archived |
