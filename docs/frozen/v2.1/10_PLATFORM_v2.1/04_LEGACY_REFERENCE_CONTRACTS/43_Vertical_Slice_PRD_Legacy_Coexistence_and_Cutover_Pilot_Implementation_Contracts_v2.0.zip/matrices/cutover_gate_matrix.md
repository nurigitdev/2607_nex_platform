# Cutover Gate Matrix

- Repository/Data inventory evidence present
- Critical stable-ID mapping blockers = 0
- Critical unexplained compare diff = 0
- Critical reconciliation blockers = 0
- Verified backup/restore evidence present
- Golden A selected transaction passes Target route
- Legacy write-disable mechanism prepared
- Rollback/forward-fix decision policy prepared
- OA/AG operator authorization and sign-off present
