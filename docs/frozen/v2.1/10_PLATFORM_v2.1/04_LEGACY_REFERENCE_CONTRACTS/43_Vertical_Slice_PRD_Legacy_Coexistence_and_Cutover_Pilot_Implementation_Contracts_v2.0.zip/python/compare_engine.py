def classify_compare(legacy: dict, target: dict, critical_fields: list[str]):
    diffs = {f:(legacy.get(f), target.get(f)) for f in critical_fields if legacy.get(f) != target.get(f)}
    return "MATCH" if not diffs else "UNEXPLAINED_DIFF", diffs
