def decide_rollback(target_only_delta: int, reconciled: bool, legacy_ready: bool):
    if target_only_delta > 0 or not reconciled or not legacy_ready:
        return "FORWARD_FIX"
    return "ROLLBACK_ALLOWED"
