from dataclasses import dataclass

@dataclass(frozen=True)
class TransitionPolicy:
    scope_id: str
    state: str
    read_target: str
    write_target: str
    policy_version: str

def resolve_write_target(policy: TransitionPolicy) -> str:
    if policy.write_target not in {"LEGACY", "TARGET"}:
        raise RuntimeError("ambiguous write authority")
    return policy.write_target

def safe_write(policy: TransitionPolicy, legacy_call, target_call, command):
    target = resolve_write_target(policy)
    if target == "LEGACY":
        return legacy_call(command)
    return target_call(command)

# Never fallback a failed TARGET write to LEGACY automatically.
