# Golden Migration Scenarios

1. READ_SYNC keeps Legacy as sole writer.
2. Shadow compare produces no Target business effect.
3. Critical diff blocks cutover.
4. Limited coexistence routes write deterministically.
5. Target write failure never falls back to Legacy write.
6. Cutover changes authority only after gate evidence.
7. Legacy write is blocked immediately after cutover.
8. Unsafe target-only delta blocks authority rollback.
9. Retirement is impossible with active hidden dependency.
10. Archive/retention evidence exists before delete.
