# Pilot Rollback / Forward-fix Runbook

1. Stop new protected writes if required.
2. Measure target-only delta.
3. Reconcile Legacy/Target and verify Legacy readiness.
4. If delta cannot be safely restored, choose FORWARD_FIX.
5. If rollback is allowed, create a NEW versioned transition decision.
6. Verify routing and no duplicate business effect.
7. Record rollback decision/evidence.
