# Pilot Cutover Runbook

1. Freeze final gate evidence.
2. Verify backup/restore.
3. Drain/freeze if required.
4. Apply versioned Transition Policy.
5. Reload/verify Router.
6. Execute post-cutover smoke and Golden transaction.
7. Verify Legacy no-new-write.
8. Start rollback window monitoring.
9. Record CutoverRecord and operator sign-off.
