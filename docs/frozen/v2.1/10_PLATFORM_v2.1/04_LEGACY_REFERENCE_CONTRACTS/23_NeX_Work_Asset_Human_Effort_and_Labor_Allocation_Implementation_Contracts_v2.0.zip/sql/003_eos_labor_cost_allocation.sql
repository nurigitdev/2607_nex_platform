-- EOS labor cost pool and allocation
CREATE TABLE IF NOT EXISTS nex_eos.labor_cost_pool (
    labor_cost_pool_id        uuid PRIMARY KEY,
    employee_ref              varchar(160) NOT NULL,
    period_ref                varchar(160) NOT NULL,
    cost_amount               numeric(38,12) NOT NULL,
    currency                  char(3) NOT NULL,
    source_type               varchar(32) NOT NULL,
    source_ref                varchar(256) NOT NULL,
    source_snapshot_hash      char(64) NOT NULL,
    components_json           jsonb NOT NULL DEFAULT '{}'::jsonb,
    state                     varchar(24) NOT NULL,
    created_at                timestamptz NOT NULL DEFAULT now(),
    UNIQUE(employee_ref,period_ref),
    CONSTRAINT ck_labor_cost_pool_state CHECK (state IN ('DRAFT','VALIDATED','FROZEN','POSTED','ADJUSTED')),
    CONSTRAINT ck_labor_cost_pool_amount CHECK (cost_amount >= 0)
);

CREATE TABLE IF NOT EXISTS nex_eos.labor_allocation_batch (
    batch_id                  uuid PRIMARY KEY,
    employee_ref              varchar(160) NOT NULL,
    period_ref                varchar(160) NOT NULL,
    labor_cost_pool_id        uuid NOT NULL REFERENCES nex_eos.labor_cost_pool(labor_cost_pool_id),
    effort_statement_ref      varchar(160) NOT NULL,
    state                     varchar(32) NOT NULL,
    standard_work_minutes     integer NOT NULL,
    allocation_base_minutes   integer NOT NULL,
    coverage_ratio            numeric(12,6) NOT NULL,
    total_cost                numeric(38,12) NOT NULL,
    currency                  char(3) NOT NULL,
    rounding_adjustment       numeric(38,12) NOT NULL DEFAULT 0,
    ledger_posting_id         uuid REFERENCES nex_eos.ledger_posting(posting_id),
    version                   bigint NOT NULL DEFAULT 0,
    created_at                timestamptz NOT NULL DEFAULT now(),
    updated_at                timestamptz NOT NULL DEFAULT now(),
    UNIQUE(employee_ref,period_ref),
    CONSTRAINT ck_labor_batch_state CHECK (
      state IN ('DRAFT','REVIEW_REQUIRED','CONFIRMED','POSTED','ADJUSTMENT_REQUIRED','ADJUSTED')
    ),
    CONSTRAINT ck_labor_allocation_base CHECK (allocation_base_minutes > 0)
);

CREATE TABLE IF NOT EXISTS nex_eos.labor_allocation_item (
    allocation_item_id        uuid PRIMARY KEY,
    batch_id                  uuid NOT NULL REFERENCES nex_eos.labor_allocation_batch(batch_id),
    employee_ref              varchar(160) NOT NULL,
    period_ref                varchar(160) NOT NULL,
    project_id                uuid NOT NULL REFERENCES nex_eos.project(project_id),
    role_ref                  varchar(160),
    labor_nature              varchar(32) NOT NULL,
    confirmed_effort_minutes  integer NOT NULL,
    standard_work_minutes     integer NOT NULL,
    mm                        numeric(18,8) NOT NULL,
    allocation_ratio          numeric(18,10) NOT NULL,
    allocated_cost            numeric(38,12) NOT NULL,
    currency                  char(3) NOT NULL,
    evidence_snapshot_hash    char(64) NOT NULL,
    source_effort_refs_json   jsonb NOT NULL,
    state                     varchar(24) NOT NULL,
    adjustment_of_item_id     uuid REFERENCES nex_eos.labor_allocation_item(allocation_item_id),
    created_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_labor_item_nature CHECK (labor_nature IN ('DIRECT','SHARED_SERVICE','CORPORATE_COMMON')),
    CONSTRAINT ck_labor_item_state CHECK (state IN ('DRAFT','CONFIRMED','POSTED','ADJUSTED')),
    CONSTRAINT ck_labor_item_ratio CHECK (allocation_ratio >= 0 AND allocation_ratio <= 1),
    CONSTRAINT ck_labor_item_minutes CHECK (confirmed_effort_minutes >= 0)
);
CREATE INDEX IF NOT EXISTS ix_labor_allocation_project_period
    ON nex_eos.labor_allocation_item(project_id,period_ref,labor_nature);
