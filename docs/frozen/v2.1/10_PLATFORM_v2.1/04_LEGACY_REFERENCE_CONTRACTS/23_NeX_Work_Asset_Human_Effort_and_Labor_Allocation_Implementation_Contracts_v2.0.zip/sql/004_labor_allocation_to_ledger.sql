-- LaborAllocation -> Project Financial Ledger LABOR posting

-- Preconditions:
-- MonthlyEffortStatement FROZEN
-- LaborCostPool FROZEN
-- LaborAllocationBatch CONFIRMED
-- no unresolved/unattributed project attribution according to period policy
-- sum(allocation_item.allocated_cost) == labor_cost_pool.cost_amount
-- current authorization allows LEDGER.POST_LABOR_ALLOCATION

BEGIN;

SELECT *
  FROM nex_eos.labor_allocation_batch
 WHERE batch_id=:batch_id
 FOR UPDATE;

SELECT *
  FROM nex_eos.labor_cost_pool
 WHERE labor_cost_pool_id=:labor_cost_pool_id
 FOR UPDATE;

-- one LedgerPosting per Employee/Period batch
INSERT INTO nex_eos.ledger_posting(
    posting_id, source_transaction_type, source_transaction_id,
    posting_date, period_id, currency, entry_count, entries_hash,
    idempotency_key, correlation_id, causation_id, created_by_ref
) VALUES (
    :posting_id, 'LABOR_ALLOCATION', :batch_id,
    :posting_date, :period_id, :currency, :entry_count, :entries_hash,
    :idempotency_key, :correlation_id, :causation_id, :actor_ref
)
ON CONFLICT (idempotency_key) DO NOTHING;

-- Project Financial Ledger is a management P/L subledger.
-- Each allocation item produces a LABOR economic fact.
INSERT INTO nex_eos.ledger_entry(
    ledger_entry_id, posting_id, project_id, account_id,
    source_transaction_type, source_transaction_id, source_transaction_line_id,
    category, side, amount, currency, posting_date, period_id,
    description, dimensions_json, correlation_id, causation_id
)
SELECT
    gen_random_uuid(), :posting_id, lai.project_id, :labor_expense_account_id,
    'LABOR_ALLOCATION', :batch_id, lai.allocation_item_id::varchar,
    'LABOR', 'DEBIT', lai.allocated_cost, lai.currency, :posting_date, :period_id,
    'Monthly labor allocation',
    jsonb_build_object(
      'employee_ref',lai.employee_ref,
      'labor_nature',lai.labor_nature,
      'mm',lai.mm,
      'confirmed_effort_minutes',lai.confirmed_effort_minutes,
      'evidence_snapshot_hash',lai.evidence_snapshot_hash
    ),
    :correlation_id, :causation_id
FROM nex_eos.labor_allocation_item lai
WHERE lai.batch_id=:batch_id;

UPDATE nex_eos.labor_allocation_batch
   SET state='POSTED', ledger_posting_id=:posting_id,
       version=version+1, updated_at=now()
 WHERE batch_id=:batch_id AND state='CONFIRMED' AND version=:expected_version;

UPDATE nex_eos.labor_cost_pool
   SET state='POSTED'
 WHERE labor_cost_pool_id=:labor_cost_pool_id AND state='FROZEN';

INSERT INTO nex_eos.event_outbox(... 'LABOR_ALLOCATION_POSTED' ...);
COMMIT;

-- NOTE:
-- If a statutory GL needs salary expense / payroll payable balanced entries,
-- that remains accounting/payroll domain responsibility.
-- Project Financial Ledger receives the P/L labor economic facts only.
