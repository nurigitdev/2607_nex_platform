-- Event ingestion / WA projection checkpoints
CREATE TABLE IF NOT EXISTS nex_wa.activity_event_inbox (
    event_id                  varchar(128) PRIMARY KEY,
    event_name                varchar(128) NOT NULL,
    source_type               varchar(32) NOT NULL,
    payload_json              jsonb NOT NULL,
    correlation_id            varchar(128),
    received_at               timestamptz NOT NULL DEFAULT now(),
    handled_at                timestamptz
);

CREATE TABLE IF NOT EXISTS nex_wa.activity_projection_checkpoint (
    source_name               varchar(160) PRIMARY KEY,
    source_watermark          varchar(256) NOT NULL,
    updated_at                timestamptz NOT NULL DEFAULT now()
);

-- At-least-once source events are deduplicated by event_id/dedup_key.
-- WorkActivity remains append-oriented; source correction creates VOIDED/SUPERSEDED activity.
-- Never convert AgentExecution elapsed time directly into human effort.
