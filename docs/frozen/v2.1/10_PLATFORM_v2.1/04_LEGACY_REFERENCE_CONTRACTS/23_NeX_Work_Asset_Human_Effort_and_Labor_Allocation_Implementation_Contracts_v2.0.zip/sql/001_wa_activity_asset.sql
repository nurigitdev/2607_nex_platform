-- NeX-WA observable work evidence and WorkAsset
CREATE SCHEMA IF NOT EXISTS nex_wa;

CREATE TABLE IF NOT EXISTS nex_wa.work_activity (
    activity_id               uuid PRIMARY KEY,
    employee_ref              varchar(160) NOT NULL,
    activity_type             varchar(40) NOT NULL,
    source_type               varchar(32) NOT NULL,
    source_event_ref          varchar(256) NOT NULL,
    source_object_refs_json   jsonb NOT NULL DEFAULT '[]'::jsonb,
    project_ref               varchar(160),
    project_attribution_ref   varchar(160),
    observed_at               timestamptz NOT NULL,
    started_at                timestamptz,
    ended_at                  timestamptz,
    observed_active_seconds   integer,
    elapsed_seconds           integer,
    agent_execution_seconds   integer,
    evidence_refs_json        jsonb NOT NULL DEFAULT '[]'::jsonb,
    activity_status           varchar(24) NOT NULL DEFAULT 'VALID',
    dedup_key                 varchar(256) NOT NULL UNIQUE,
    correlation_id            varchar(128) NOT NULL,
    causation_id              varchar(128),
    work_item_id              varchar(128),
    agent_execution_id        varchar(128),
    created_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_wa_activity_status CHECK (activity_status IN ('VALID','VOIDED','SUPERSEDED')),
    CONSTRAINT ck_wa_activity_seconds CHECK (
      (observed_active_seconds IS NULL OR observed_active_seconds >= 0)
      AND (elapsed_seconds IS NULL OR elapsed_seconds >= 0)
      AND (agent_execution_seconds IS NULL OR agent_execution_seconds >= 0)
    )
);
CREATE INDEX IF NOT EXISTS ix_wa_activity_employee_time
    ON nex_wa.work_activity(employee_ref,observed_at,activity_status);
CREATE INDEX IF NOT EXISTS ix_wa_activity_work
    ON nex_wa.work_activity(work_item_id,employee_ref);

CREATE TABLE IF NOT EXISTS nex_wa.work_asset (
    work_asset_id             uuid PRIMARY KEY,
    employee_ref              varchar(160) NOT NULL,
    asset_type                varchar(32) NOT NULL,
    title                     varchar(500) NOT NULL,
    state                     varchar(32) NOT NULL,
    work_item_ref             varchar(160),
    project_ref               varchar(160),
    project_attribution_status varchar(32) NOT NULL,
    activity_refs_json        jsonb NOT NULL,
    result_refs_json          jsonb NOT NULL DEFAULT '[]'::jsonb,
    business_object_refs_json jsonb NOT NULL DEFAULT '[]'::jsonb,
    evidence_refs_json        jsonb NOT NULL DEFAULT '[]'::jsonb,
    period_ref                varchar(160),
    correlation_id            varchar(128) NOT NULL,
    causation_id              varchar(128),
    version                   bigint NOT NULL DEFAULT 0,
    created_at                timestamptz NOT NULL DEFAULT now(),
    updated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_wa_asset_state CHECK (
      state IN ('DRAFT','ASSEMBLED','ATTRIBUTION_PENDING','EFFORT_PENDING','READY_FOR_REVIEW',
                'CONFIRMED','FROZEN','ADJUSTED','VOIDED')
    )
);
CREATE INDEX IF NOT EXISTS ix_wa_asset_employee_period
    ON nex_wa.work_asset(employee_ref,period_ref,state);
