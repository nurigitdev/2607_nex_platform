-- Adjustment / reconciliation after labor posting

CREATE TABLE IF NOT EXISTS nex_eos.labor_allocation_adjustment (
    adjustment_id             uuid PRIMARY KEY,
    original_batch_id         uuid NOT NULL REFERENCES nex_eos.labor_allocation_batch(batch_id),
    reason_code               varchar(64) NOT NULL,
    reason                    text NOT NULL,
    requested_by_ref          varchar(160) NOT NULL,
    replacement_batch_id      uuid REFERENCES nex_eos.labor_allocation_batch(batch_id),
    reversal_posting_id       uuid REFERENCES nex_eos.ledger_posting(posting_id),
    replacement_posting_id    uuid REFERENCES nex_eos.ledger_posting(posting_id),
    status                    varchar(24) NOT NULL,
    created_at                timestamptz NOT NULL DEFAULT now(),
    completed_at              timestamptz,
    CONSTRAINT ck_labor_adjustment_status CHECK (
      status IN ('REQUESTED','APPROVED','REVERSAL_POSTED','REPLACEMENT_POSTED','COMPLETED','REJECTED')
    )
);

-- Posted allocation is never edited in place.
-- Correction path:
-- 1) create adjustment request;
-- 2) governance approval if policy requires;
-- 3) reverse original LaborAllocation LedgerPosting;
-- 4) create replacement frozen effort statement/allocation batch version;
-- 5) post replacement LaborAllocation;
-- 6) link both postings and preserve original evidence.
