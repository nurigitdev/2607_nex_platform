-- Effort estimates, confirmations and monthly effort statement
CREATE TABLE IF NOT EXISTS nex_wa.effort_estimate (
    estimate_id               uuid PRIMARY KEY,
    work_asset_id             uuid NOT NULL REFERENCES nex_wa.work_asset(work_asset_id),
    employee_ref              varchar(160) NOT NULL,
    estimated_minutes         integer NOT NULL,
    estimator_type            varchar(32) NOT NULL,
    estimator_ref             varchar(160) NOT NULL,
    rule_version              varchar(64),
    confidence                numeric(8,6) NOT NULL,
    evidence_summary_json     jsonb NOT NULL,
    overlap_removed_minutes   integer NOT NULL DEFAULT 0,
    agent_minutes_excluded    integer NOT NULL DEFAULT 0,
    requires_human_review     boolean NOT NULL DEFAULT true,
    created_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_effort_estimate_minutes CHECK (estimated_minutes >= 0),
    CONSTRAINT ck_effort_confidence CHECK (confidence >= 0 AND confidence <= 1)
);

CREATE TABLE IF NOT EXISTS nex_wa.human_effort_confirmation (
    confirmation_id           uuid PRIMARY KEY,
    work_asset_id             uuid NOT NULL REFERENCES nex_wa.work_asset(work_asset_id),
    employee_ref              varchar(160) NOT NULL,
    project_ref               varchar(160) NOT NULL,
    role_ref                  varchar(160),
    labor_nature              varchar(32) NOT NULL,
    estimated_minutes         integer NOT NULL,
    confirmed_minutes         integer NOT NULL,
    state                     varchar(32) NOT NULL,
    employee_decision         varchar(32) NOT NULL,
    employee_comment          text,
    employee_confirmed_at     timestamptz,
    reviewer_ref              varchar(160),
    review_decision           varchar(32) NOT NULL,
    review_comment            text,
    reviewed_at               timestamptz,
    evidence_snapshot_hash    char(64) NOT NULL,
    correlation_id            varchar(128) NOT NULL,
    causation_id              varchar(128),
    version                   bigint NOT NULL DEFAULT 0,
    created_at                timestamptz NOT NULL DEFAULT now(),
    updated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_effort_confirm_state CHECK (
      state IN ('DRAFT','EMPLOYEE_CONFIRMED','REVIEW_REQUIRED','TEAM_CONFIRMED','FROZEN','ADJUSTED','REJECTED')
    ),
    CONSTRAINT ck_labor_nature CHECK (labor_nature IN ('DIRECT','SHARED_SERVICE','CORPORATE_COMMON')),
    CONSTRAINT ck_effort_confirm_minutes CHECK (estimated_minutes >= 0 AND confirmed_minutes >= 0)
);
CREATE INDEX IF NOT EXISTS ix_effort_confirm_employee_period
    ON nex_wa.human_effort_confirmation(employee_ref,state,project_ref);

CREATE TABLE IF NOT EXISTS nex_wa.monthly_effort_statement (
    statement_id              uuid PRIMARY KEY,
    employee_ref              varchar(160) NOT NULL,
    period_ref                varchar(160) NOT NULL,
    state                     varchar(32) NOT NULL,
    standard_work_minutes     integer NOT NULL,
    confirmed_effort_minutes  integer NOT NULL,
    coverage_ratio            numeric(12,6) NOT NULL,
    confirmation_refs_json    jsonb NOT NULL,
    unresolved_asset_count    integer NOT NULL DEFAULT 0,
    unattributed_minutes      integer NOT NULL DEFAULT 0,
    policy_ref                varchar(256) NOT NULL,
    employee_reviewed_at      timestamptz,
    team_reviewed_at          timestamptz,
    frozen_at                 timestamptz,
    version                   bigint NOT NULL DEFAULT 0,
    created_at                timestamptz NOT NULL DEFAULT now(),
    updated_at                timestamptz NOT NULL DEFAULT now(),
    UNIQUE(employee_ref,period_ref),
    CONSTRAINT ck_statement_state CHECK (
      state IN ('DRAFT','EMPLOYEE_REVIEWED','TEAM_REVIEWED','FROZEN','POSTED','ADJUSTMENT_REQUIRED','ADJUSTED')
    )
);
