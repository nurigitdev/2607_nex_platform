# NeX Work Asset / Human Effort / Labor Allocation v2.0 Reference Package

Accompanies `23_NeX_Work_Asset_Human_Effort_and_Labor_Allocation_Design_v2.0`.

## Ownership
- NeX-WA owns WorkActivity, WorkAsset, EffortEstimate, HumanEffortConfirmation and MonthlyEffortStatement.
- Enterprise OS owns LaborCostPool, LaborAllocationBatch/Item and Project Financial Ledger LABOR posting.
- NeX-OA/HR calendar provides employee/role/schedule references.
- Project Attribution reuses the Enterprise OS / Document 21 resolution policy.

## Core rules
1. AgentExecution duration is NEVER human effort.
2. WorkItem elapsed time is NEVER human effort.
3. Transaction count alone is evidence, not a labor basis.
4. EffortEstimate is advisory. Only Confirmed/FROZEN human effort may feed labor allocation.
5. Human review starts from auto-generated evidence/estimate; users do not maintain manual timesheets by default.
6. MM = ConfirmedEffortMinutes / StandardWorkMinutes.
7. Payroll cost allocation uses a DIFFERENT denominator:
   AllocationRatio = ConfirmedProjectEffortMinutes / FinalAllocationBaseMinutes.
8. AllocatedCost = LaborCostPool × AllocationRatio. Largest-remainder rounding guarantees item costs sum exactly to the cost pool.
9. CoverageRatio = FinalAllocationBaseMinutes / StandardWorkMinutes is a quality/reconciliation indicator, not the payroll allocation denominator.
10. Project attribution follows Project Attribution First. True Corporate Common uses an explicit Common Work Project; missing Project never silently becomes Common.
11. DIRECT, SHARED_SERVICE and CORPORATE_COMMON remain dimensions. Shared-service work can post to the actual supported Project.
12. Posted LaborAllocation is immutable. Correction uses reversal + replacement allocation/posting.
13. Project profitability is management accounting evidence, not an automatic employee performance score.
14. Raw telemetry and WorkActivity must not be converted directly into performance ratings.

All 8 schemas, examples and Python modules are validated during artifact generation.
