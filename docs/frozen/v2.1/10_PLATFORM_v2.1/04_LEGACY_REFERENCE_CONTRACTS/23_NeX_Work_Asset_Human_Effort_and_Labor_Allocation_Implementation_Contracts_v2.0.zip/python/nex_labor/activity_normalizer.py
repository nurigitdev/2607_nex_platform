from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Mapping

class ActivityNormalizer:
    """Normalizes source events into append-oriented WorkActivity evidence."""

    def normalize(self, event:Mapping[str,Any]) -> dict[str,Any]|None:
        if not event.get("employee_ref"):
            return None
        # Background agent runtime is evidence of automation, not human labor duration.
        agent_seconds=event.get("agent_execution_seconds")
        human_active=event.get("observed_active_seconds")
        if event["source_type"]=="AE" and event.get("execution_mode") in {
            "BACKGROUND_COWORKER","BACKGROUND_EXPERT","SYSTEM"
        }:
            human_active=0 if human_active is None else human_active

        dedup=f"{event['source_type']}:{event['event_id']}"
        return {
            "schema_version":"1.0",
            "activity_id":event.get("activity_id",event["event_id"]),
            "employee_ref":event["employee_ref"],
            "activity_type":event["activity_type"],
            "source_type":event["source_type"],
            "source_event_ref":event["event_id"],
            "source_object_refs":event.get("source_object_refs",[]),
            "project_ref":event.get("project_ref"),
            "project_attribution_ref":event.get("project_attribution_ref"),
            "observed_at":event["occurred_at"],
            "started_at":event.get("started_at"),
            "ended_at":event.get("ended_at"),
            "observed_active_seconds":human_active,
            "elapsed_seconds":event.get("elapsed_seconds"),
            "agent_execution_seconds":agent_seconds,
            "evidence_refs":event.get("evidence_refs",[]),
            "activity_status":"VALID",
            "dedup_key":dedup,
            "trace":event["trace"],
            "created_at":datetime.now(timezone.utc).isoformat(),
        }
