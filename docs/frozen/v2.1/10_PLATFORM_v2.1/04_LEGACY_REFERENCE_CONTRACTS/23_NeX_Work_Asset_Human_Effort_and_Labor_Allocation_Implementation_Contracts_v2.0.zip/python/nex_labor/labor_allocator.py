from __future__ import annotations
from decimal import Decimal, ROUND_FLOOR
from typing import Any, Mapping, Sequence

class LaborAllocator:
    """MM and payroll cost allocation intentionally use different denominators."""

    def __init__(self, id_generator, clock):
        self.id_generator=id_generator; self.clock=clock

    def allocate(self, *, statement:Mapping[str,Any], confirmations:Sequence[Mapping[str,Any]],
                 cost_pool:Mapping[str,Any], currency_minor_unit:int=0) -> Mapping[str,Any]:
        if statement["state"]!="FROZEN":
            raise ValueError("EFFORT_STATEMENT_NOT_FROZEN")
        if cost_pool["state"]!="FROZEN":
            raise ValueError("LABOR_COST_POOL_NOT_FROZEN")

        final=[c for c in confirmations if c["state"]=="FROZEN" and int(c["confirmed_minutes"])>0]
        base=sum(int(c["confirmed_minutes"]) for c in final)
        if base<=0:
            raise ValueError("ALLOCATION_BASE_MINUTES_ZERO")
        std=int(statement["standard_work_minutes"])
        total=Decimal(cost_pool["cost_amount"]["amount"])
        quantum=Decimal(1).scaleb(-currency_minor_unit)

        raw=[]
        for c in final:
            minutes=int(c["confirmed_minutes"])
            mm=(Decimal(minutes)/Decimal(std)) if std else Decimal("0")
            ratio=Decimal(minutes)/Decimal(base)
            exact=total*ratio
            floored=(exact/quantum).to_integral_value(rounding=ROUND_FLOOR)*quantum
            raw.append({"confirmation":c,"minutes":minutes,"mm":mm,"ratio":ratio,
                        "exact":exact,"allocated":floored,"remainder":exact-floored})

        remainder=total-sum(x["allocated"] for x in raw)
        units=int((remainder/quantum).to_integral_value()) if quantum else 0
        for x in sorted(raw,key=lambda z:(-z["remainder"],z["confirmation"]["project_ref"]["entity_id"]))[:units]:
            x["allocated"]+=quantum

        items=[]
        for x in raw:
            c=x["confirmation"]
            items.append({
                "schema_version":"1.0","allocation_item_id":self.id_generator.new_id(),
                "employee_ref":statement["employee_ref"],"period_ref":statement["period_ref"],
                "project_ref":c["project_ref"],"role_ref":c.get("role_ref"),
                "labor_nature":c["labor_nature"],"confirmed_effort_minutes":x["minutes"],
                "standard_work_minutes":std,
                "mm":str(x["mm"].quantize(Decimal("0.000001"))),
                "allocation_ratio":str(x["ratio"].quantize(Decimal("0.000001"))),
                "allocated_cost":{"amount":str(x["allocated"]),"currency":cost_pool["cost_amount"]["currency"]},
                "evidence_snapshot_hash":c["evidence_snapshot_hash"],
                "source_effort_confirmation_refs":[{"entity_type":"EFFORT_CONFIRMATION","entity_id":c["confirmation_id"]}],
                "state":"DRAFT","adjustment_of_item_ref":None,
            })
        if sum(Decimal(i["allocated_cost"]["amount"]) for i in items)!=total:
            raise ValueError("LABOR_COST_ALLOCATION_NOT_BALANCED")
        coverage=Decimal(statement["coverage_ratio"])
        return {
            "schema_version":"1.0","batch_id":self.id_generator.new_id(),
            "employee_ref":statement["employee_ref"],"period_ref":statement["period_ref"],
            "labor_cost_pool_ref":{"entity_type":"LABOR_COST_POOL","entity_id":cost_pool["labor_cost_pool_id"]},
            "effort_statement_ref":{"entity_type":"MONTHLY_EFFORT_STATEMENT","entity_id":statement["statement_id"]},
            "state":"DRAFT","standard_work_minutes":std,"allocation_base_minutes":base,
            "coverage_ratio":str(coverage),"total_cost":cost_pool["cost_amount"],
            "items":items,"rounding_adjustment":{"amount":"0","currency":cost_pool["cost_amount"]["currency"]},
            "ledger_posting_ref":None,"created_at":self.clock.now().isoformat(),"version":0,
        }
