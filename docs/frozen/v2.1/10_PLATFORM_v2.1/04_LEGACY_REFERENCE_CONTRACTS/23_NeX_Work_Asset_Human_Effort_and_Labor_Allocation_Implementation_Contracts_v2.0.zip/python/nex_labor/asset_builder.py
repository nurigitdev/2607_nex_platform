from __future__ import annotations
from typing import Any, Mapping, Sequence

class WorkAssetBuilder:
    """Groups related observed activities/results/evidence into a business WorkAsset."""

    def __init__(self, assets, attribution, id_generator, clock):
        self.assets=assets; self.attribution=attribution
        self.id_generator=id_generator; self.clock=clock

    async def build(self, *, employee_ref:Mapping[str,Any], activities:Sequence[Mapping[str,Any]],
                    work_item_ref:Mapping[str,Any]|None, result_refs:list[Mapping[str,Any]],
                    evidence_refs:list[Mapping[str,Any]], title:str, asset_type:str,
                    context:Mapping[str,Any]) -> Mapping[str,Any]:
        if not activities:
            raise ValueError("WORK_ASSET_REQUIRES_ACTIVITY")
        attr=await self.attribution.resolve({
            **context,
            "work_item_id":work_item_ref["entity_id"] if work_item_ref else None,
        })
        project_ref=None
        status=attr.get("status","UNRESOLVED")
        if status=="RESOLVED":
            project_ref=attr["selected_projects"][0]["project_ref"]
        asset={
            "schema_version":"1.0","work_asset_id":self.id_generator.new_id(),
            "employee_ref":employee_ref,"asset_type":asset_type,"title":title,
            "state":"EFFORT_PENDING" if status=="RESOLVED" else "ATTRIBUTION_PENDING",
            "work_item_ref":work_item_ref,"project_ref":project_ref,
            "project_attribution_status":status,
            "activity_refs":[{"entity_type":"WORK_ACTIVITY","entity_id":a["activity_id"]} for a in activities],
            "result_refs":result_refs,"business_object_refs":context.get("business_object_refs",[]),
            "evidence_refs":evidence_refs,"period_ref":context.get("period_ref"),
            "trace":context["trace"],"version":0,
            "created_at":self.clock.now().isoformat(),"updated_at":None,
        }
        return await self.assets.create_or_update(asset)
