from __future__ import annotations
from decimal import Decimal
from typing import Any, Mapping, Sequence

class MonthlyEffortStatementService:
    def __init__(self, confirmations, assets, calendar, policy_repo, id_generator, clock):
        self.confirmations=confirmations; self.assets=assets; self.calendar=calendar
        self.policy_repo=policy_repo; self.id_generator=id_generator; self.clock=clock

    async def build(self, *, employee_ref:str, period_ref:str) -> Mapping[str,Any]:
        policy=await self.policy_repo.get_policy(employee_ref,period_ref)
        std=await self.calendar.get_standard_work_minutes(employee_ref,period_ref)
        confs=list(await self.confirmations.list_for_employee_period(employee_ref,period_ref))
        assets=list(await self.assets.list_for_employee_period(employee_ref,period_ref))
        final_states={"EMPLOYEE_CONFIRMED","TEAM_CONFIRMED","FROZEN"}
        confirmed=sum(int(c["confirmed_minutes"]) for c in confs if c["state"] in final_states)
        unresolved=sum(1 for a in assets if a["project_attribution_status"] in {"UNRESOLVED","CONFIRMATION_REQUIRED","SPLIT_REQUIRED"})
        coverage=(Decimal(confirmed)/Decimal(std)) if std else Decimal("0")
        return {
            "schema_version":"1.0","statement_id":self.id_generator.new_id(),
            "employee_ref":{"entity_type":"EMPLOYEE","entity_id":employee_ref},
            "period_ref":{"entity_type":"FISCAL_PERIOD","entity_id":period_ref},
            "state":"DRAFT","standard_work_minutes":std,
            "confirmed_effort_minutes":confirmed,"coverage_ratio":str(coverage.quantize(Decimal("0.000001"))),
            "confirmation_refs":[{"entity_type":"EFFORT_CONFIRMATION","entity_id":c["confirmation_id"]} for c in confs],
            "unresolved_asset_count":unresolved,
            "unattributed_minutes":max(0,std-confirmed),
            "policy_ref":policy["policy_ref"],"employee_reviewed_at":None,
            "team_reviewed_at":None,"frozen_at":None,
            "created_at":self.clock.now().isoformat(),"version":0,
        }

    def can_freeze(self, statement:Mapping[str,Any], policy:Mapping[str,Any]) -> tuple[bool,list[str]]:
        reasons=[]
        if statement["unresolved_asset_count"]>0:
            reasons.append("UNRESOLVED_WORK_ASSETS")
        coverage=Decimal(statement["coverage_ratio"])
        if coverage < Decimal(str(policy["min_coverage_ratio"])):
            reasons.append("EFFORT_COVERAGE_TOO_LOW")
        if coverage > Decimal(str(policy["max_coverage_ratio"])):
            reasons.append("EFFORT_COVERAGE_TOO_HIGH")
        return (not reasons,reasons)
