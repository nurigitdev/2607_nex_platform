from __future__ import annotations
from decimal import Decimal
from enum import StrEnum
from typing import Any
from pydantic import BaseModel, ConfigDict

class LaborNature(StrEnum):
    DIRECT="DIRECT"
    SHARED_SERVICE="SHARED_SERVICE"
    CORPORATE_COMMON="CORPORATE_COMMON"

class Money(BaseModel):
    model_config=ConfigDict(extra="forbid",frozen=True)
    amount: Decimal
    currency: str

class EntityRef(BaseModel):
    model_config=ConfigDict(extra="forbid",frozen=True)
    entity_type: str
    entity_id: str
    version: str|int|None=None
    status: str|None=None
