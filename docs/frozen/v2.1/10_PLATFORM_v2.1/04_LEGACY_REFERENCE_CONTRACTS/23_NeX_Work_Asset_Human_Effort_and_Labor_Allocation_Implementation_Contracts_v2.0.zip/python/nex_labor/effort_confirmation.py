from __future__ import annotations
from typing import Any, Mapping

class EffortConfirmationService:
    def __init__(self, confirmations, pdp, policy, clock):
        self.confirmations=confirmations; self.pdp=pdp; self.policy=policy; self.clock=clock

    async def employee_confirm(self, *, confirmation:Mapping[str,Any], confirmed_minutes:int,
                               decision:str, comment:str|None, context:Mapping[str,Any]) -> Mapping[str,Any]:
        if context["business_actor_ref"] != confirmation["employee_ref"]["entity_id"]:
            raise PermissionError("EFFORT_CONFIRM_EMPLOYEE_MISMATCH")
        if confirmed_minutes < 0:
            raise ValueError("CONFIRMED_MINUTES_NEGATIVE")
        updated=dict(confirmation)
        updated["confirmed_minutes"]=confirmed_minutes
        updated["employee_decision"]=decision
        updated["employee_comment"]=comment
        updated["employee_confirmed_at"]=self.clock.now().isoformat()
        delta=abs(confirmed_minutes-confirmation["estimated_minutes"])
        if self.policy.requires_team_review(confirmation,delta,context):
            updated["state"]="REVIEW_REQUIRED"
            updated["review_decision"]="PENDING"
        else:
            updated["state"]="EMPLOYEE_CONFIRMED"
            updated["review_decision"]="NOT_REQUIRED"
        return await self.confirmations.create_or_update(updated,confirmation["version"])

    async def team_confirm(self, *, confirmation:Mapping[str,Any], reviewer_ref:Mapping[str,Any],
                           decision:str, override_minutes:int|None, comment:str|None,
                           context:Mapping[str,Any]) -> Mapping[str,Any]:
        auth=await self.pdp.authorize("WA.REVIEW_HUMAN_EFFORT",context,[confirmation["work_asset_ref"]])
        if not auth.get("allowed",False):
            raise PermissionError("EFFORT_REVIEW_DENIED")
        updated=dict(confirmation)
        updated["reviewer_ref"]=reviewer_ref
        updated["review_decision"]=decision
        updated["review_comment"]=comment
        updated["reviewed_at"]=self.clock.now().isoformat()
        if decision=="OVERRIDE":
            if override_minutes is None or override_minutes < 0:
                raise ValueError("OVERRIDE_MINUTES_REQUIRED")
            updated["confirmed_minutes"]=override_minutes
            updated["state"]="TEAM_CONFIRMED"
        elif decision=="CONFIRM":
            updated["state"]="TEAM_CONFIRMED"
        elif decision=="REQUEST_REVISION":
            updated["state"]="DRAFT"
        else:
            raise ValueError("UNKNOWN_REVIEW_DECISION")
        return await self.confirmations.create_or_update(updated,confirmation["version"])
