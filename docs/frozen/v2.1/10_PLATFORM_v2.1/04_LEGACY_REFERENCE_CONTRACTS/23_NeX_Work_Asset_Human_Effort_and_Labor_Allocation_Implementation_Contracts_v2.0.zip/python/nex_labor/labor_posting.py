from __future__ import annotations
from typing import Any, Mapping

class LaborPostingService:
    def __init__(self, allocations, ledger, pdp, outbox):
        self.allocations=allocations; self.ledger=ledger; self.pdp=pdp; self.outbox=outbox

    async def post(self, batch:Mapping[str,Any], *, context:Mapping[str,Any]) -> Mapping[str,Any]:
        if batch["state"]!="CONFIRMED":
            raise ValueError("LABOR_ALLOCATION_NOT_CONFIRMED")
        auth=await self.pdp.authorize("LEDGER.POST_LABOR_ALLOCATION",context,[batch["employee_ref"],batch["period_ref"]])
        if not auth.get("allowed",False):
            raise PermissionError("LABOR_POST_DENIED")
        # Each allocation item becomes one Project Financial Ledger LABOR fact.
        posting=await self.ledger.post_labor_allocation(
            batch,idempotency_key=f"labor:{batch['employee_ref']['entity_id']}:{batch['period_ref']['entity_id']}",
            context=context
        )
        updated=await self.allocations.mark_posted(batch["batch_id"],posting["posting_ref"],batch["version"])
        await self.outbox.append({
            "event_name":"LABOR_ALLOCATION_POSTED","batch_id":batch["batch_id"],
            "employee_id":batch["employee_ref"]["entity_id"],
            "period_id":batch["period_ref"]["entity_id"],
            "posting_ref":posting["posting_ref"],"correlation_id":context["correlation_id"]
        })
        return updated
