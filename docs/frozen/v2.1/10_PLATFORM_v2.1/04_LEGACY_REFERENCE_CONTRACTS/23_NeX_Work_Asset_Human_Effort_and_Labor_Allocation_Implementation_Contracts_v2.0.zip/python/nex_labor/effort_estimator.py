from __future__ import annotations
from datetime import datetime
from typing import Any, Mapping, Sequence

def _parse(s):
    return datetime.fromisoformat(s.replace("Z","+00:00"))

class EffortEstimator:
    """Produces advisory estimated human effort, never a financial posting basis."""

    def __init__(self, policy, id_generator, clock):
        self.policy=policy; self.id_generator=id_generator; self.clock=clock

    def estimate(self, *, work_asset:Mapping[str,Any], activities:Sequence[Mapping[str,Any]]) -> Mapping[str,Any]:
        # High-confidence contribution: explicit observed human-active seconds.
        active_seconds=sum(int(a.get("observed_active_seconds") or 0) for a in activities)

        # Interval contribution: union overlapping intervals, but only for activity types/policies
        # explicitly allowed as human-work evidence.
        intervals=[]
        for a in activities:
            if a.get("started_at") and a.get("ended_at") and self.policy.interval_eligible(a):
                intervals.append((_parse(a["started_at"]),_parse(a["ended_at"])))
        intervals.sort()
        merged=[]
        for start,end in intervals:
            if end <= start:
                continue
            if not merged or start > merged[-1][1]:
                merged.append([start,end])
            elif end > merged[-1][1]:
                merged[-1][1]=end
        union_seconds=sum(int((e-s).total_seconds()) for s,e in merged)

        raw_seconds=max(active_seconds,union_seconds)
        agent_seconds=sum(int(a.get("agent_execution_seconds") or 0) for a in activities)
        # Agent time is explicitly never added to human effort.
        minutes=max(0,round(raw_seconds/60))
        confidence=self.policy.confidence(activities,minutes)
        return {
            "schema_version":"1.0","estimate_id":self.id_generator.new_id(),
            "work_asset_ref":{"entity_type":"WORK_ASSET","entity_id":work_asset["work_asset_id"]},
            "employee_ref":work_asset["employee_ref"],"estimated_minutes":minutes,
            "estimator_type":"INTERVAL_UNION","estimator_ref":self.policy.estimator_ref,
            "rule_version":self.policy.version,"confidence":confidence,
            "evidence_summary":{"active_seconds":active_seconds,"interval_union_seconds":union_seconds,
                                "activity_count":len(activities)},
            "overlap_removed_minutes":max(0,round((sum(max(0,int((e-s).total_seconds())) for s,e in intervals)-union_seconds)/60)),
            "agent_execution_minutes_excluded":round(agent_seconds/60),
            "requires_human_review":True,
            "created_at":self.clock.now().isoformat(),
        }
